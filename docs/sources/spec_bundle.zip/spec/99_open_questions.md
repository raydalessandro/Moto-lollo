# 99 -- Open Questions

**Scopo:** tracker vivo delle domande aperte, decisioni proposte in attesa di conferma, e punti da portare all'altro dev (Lollo) o da rivalutare in fasi successive.

**Regole:**

- Ogni item ha uno **stato**: `[OPEN]` (aperta) | `[DECIDED]` (decisa) | `[PROPOSED]` (proposta, attende conferma) | `[DEFERRED]` (rinviata).
- Ogni item ha un **owner**: chi deve rispondere o decidere.
- Quando una item passa a `[DECIDED]`, va migrata nella spec pertinente e archiviata in Sezione D con riferimento.
- Non si risolvono qui. Qui si tracciano. Le decisioni vere vivono nelle spec di dominio.

**Ultimo aggiornamento:** 18 aprile 2026 (consolidamento post-spec 00-05, promozione 12 item TEC-CHIUDIBILE a D)

---

## Sezione A -- Proposte da validare con Lollo o Ray

Scelte che richiedono interazione umana (UX, prodotto, tuning in campo). I numeri non sono contigui perche' mantengono la numerazione originale anche dopo la promozione di alcuni item a Sezione D (evita rotture di riferimenti in altri doc).

---

### A.3 -- UX dialog recovery al riavvio  [PROPOSED]

**Contesto:** meccanismo tecnico fissato in `00_overview.md` Sezione 5.11 e `04_tracking/state_machine.md` Sezione 3.9. Rimane da definire il dialog UX.

**Proposta UX:**

- Dialog modal non dismissibile con tap esterno.
- Mini-mappa del tratto registrato + dati riassuntivi (ora inizio, durata, km, moto).
- 3 opzioni: *Salva come completata* / *Salva come incompleta* (flag `was_recovered = true`) / *Scarta*.

**Sub-decisione aperta:** offrire 4a opzione "Riprendi tracciamento"?

- Opzione X (offrire): tecnicamente fattibile, ma introduce gap GPS tra crash e riavvio.
- Opzione Y (non offrire): piu' semplice, evita dati ingannevoli. **Raccomandazione Claude: Y.**

**Owner:** Ray (scelta UX) + Lollo (fattibilita').

---

### A.4 -- Soglia auto-pause detection  [PROPOSED]

**Contesto:** in `04_tracking/state_machine.md` Sezione 3.3 il filtro GPS rileva sosta e transiziona a `recording_auto_paused`.

**Proposta:** velocita' `< 1 km/h` per durata `>= 30 secondi`.

**Razionale:** per moto scelta conservativa. Strava usa 2 km/h per 10s, Komoot 0.5 km/h per 20s. Agli stop semaforici 10 secondi passano spesso; 30s evita auto-pause ad ogni rosso.

**Perche' resta aperta:** Lollo ha probabilmente esperienza diretta con app di tracking moto. Il tuning va validato sul campo. Valori attuali sono operativi come default.

**Owner:** Lollo (conferma numerica + eventuale tuning dopo test in campo).

---

### A.7 -- MAX_ACTIVITIES_REHYDRATION  [PROPOSED]

**Contesto:** in `05_sync/queue_design.md` Sezione 6 la rehydration al primo login scarica ultime N activity.

**Proposta:** `50` activity.

**Razionale:** utente con 500 activity storiche vede le ultime 50 al nuovo device; le altre restano sul server e arrivano on-demand via scroll infinito del feed personale.

**Alternativa:** scaricare TUTTE le activity alla rehydration. Svantaggio: primo login lento, traffico grande. Scartata.

**Owner:** Ray (scelta prodotto) + Lollo (fattibilita' scroll infinito).

---

### A.8 -- Intervallo auto-retry orario per `failed`  [PROPOSED]

**Contesto:** in `05_sync/queue_design.md` Sezione 4.4 item sync che sono andati in `failed` vengono ri-tentati periodicamente.

**Proposta base:** ritenta tutti i `failed` ogni **1 ora**. Se falliscono di nuovo, tornano `failed` per un'altra ora. Cicli infiniti fino a successo o cancellazione utente.

**Alternativa piu' realistica:** cadenze crescenti 1h -> 4h -> 24h poi stop. Se una Activity e' `failed` da 24h e' probabile che il problema sia permanente (bug, non outage).

**Perche' resta aperta:** differenza non irrilevante su experience. Lollo ha probabilmente opinione informata dalla produzione precedente.

**Owner:** Lollo.

---

### A.10 -- Policy `route_likes_select`: chi vede i likers?  [PROPOSED]

**Contesto:** in `02_database_schema.md` Sezione 5.8 la policy attuale consente a qualunque utente autenticato di vedere l'elenco di chi ha likato una PublishedRoute.

**Proposta (base):** mantenere cosi'. Standard Instagram / Strava: i like sono pubblici tra chi vede la route.

**Alternativa:** restringere a solo owner della route + autore del like. Piu' privacy-friendly ma meno social.

**Owner:** Ray (scelta prodotto).

---

### A.12 -- Username modificabile: enforcement "entro 7 giorni"  [PROPOSED]

**Contesto:** in `00_overview.md` Sezione 3 detta "username immutabile dopo la prima settimana" come policy prodotto. In `02_database_schema.md` Sezione 3.1 il CHECK non impone il limite temporale.

**Opzioni:**

- (a) Solo UI: app disabilita modifica dopo 7 giorni. Utente tecnico che chiama API direttamente puo' aggirare.
- (b) Trigger Postgres: enforcement duro. Piu' sicuro ma aggiunge codice.
- (c) Edge Function: update username solo via Edge Function che verifica eta' account. Complica il flow.

**Raccomandazione Claude:** (a) per MVP. Utente tecnico che aggira non e' una classe di minaccia prioritaria. Se servira' hardening, si aggiunge trigger in una migration successiva.

**Owner:** Ray (tolleranza rischio) + Lollo.

---

### A.18 -- Foto `failed` in UI: mantenere o auto-nascondere dopo 7 giorni?  [PROPOSED]

**Contesto:** il principio "code indipendenti Activity vs ActivityMedia" e' stato chiuso (vedi D.43). Resta da decidere solo il comportamento UI per foto `failed` permanentemente.

**Sub-decisione aperta:**

- Opzione X: mostrare sempre con icona "errore, tocca per riprovare". Utente decide se ritentare o cancellare manualmente.
- Opzione Y: dopo 7 giorni, auto-purge delle foto `failed` dalla UI (record resta in drift per debug ma non appare piu' nel feed).

**Raccomandazione Claude:** X per MVP. Non nascondiamo dati all'utente senza che lui abbia scelto. Se poi il feed diventa sporco, si rivaluta Y in iterazione successiva.

**Owner:** Ray (scelta UX).

---

### A.20 -- Auto-stop tracking per batteria critica  [PROPOSED]

**Contesto:** in `04_tracking/edge_cases.md` Sezione 6.2 batteria sotto 3% puo' causare spegnimento device.

**Opzioni:**

- (a) **Solo warning**: notifiche al 10%, 5%, 3%. Mai auto-stop. Utente sovrano.
- (b) **Auto-stop al 3%**: al 10% soft warning, al 5% strong warning, al 3% auto-stop con salvataggio Activity. "Prendo decisione per te in caso limite".

**Raccomandazione Claude:** **(b)**. Al 3% il device sta per spegnersi hard -- meglio che l'Activity venga chiusa pulitamente dal modulo piuttosto che dal power-off. La Activity viene salvata; recovery non serve.

**Tradeoff:** se l'utente sta per raggiungere una presa di ricarica e vuole continuare, l'auto-stop lo blocca. Ma al 3% il tempo utile e' comunque cortissimo.

**Owner:** Ray (scelta UX).

---

### A.21 -- UX per accuracy GPS costantemente scadente  [PROPOSED]

**Contesto:** in `04_tracking/gps_filters.md` Sezione 2.1 punti con `accuracy > 50m` vengono droppati. Se per 5+ minuti consecutivi tutti i punti sono droppati, l'utente registra un "vuoto" senza saperlo.

**Proposta:** se `_consecutiveDropsForAccuracy >= 300` (5 minuti a 1Hz), notifica UI non intrusiva: "GPS scadente, riposiziona il telefono o attendi cielo piu' aperto".

**Alternative:** silenzio totale (utente si accorge solo a fine giro), oppure piu' aggressivo (auto-pause temporaneo).

**Raccomandazione Claude:** notifica soft, no auto-pause. L'utente sovrano.

**Owner:** Ray (UX).

---

## Sezione B -- Domande ancora aperte (non pre-decise)

Scelte di prodotto o di design per cui Claude non ha una raccomandazione chiara. Richiedono decisione umana.

---

### B.1 -- Matrice RLS: casi edge non coperti  [OPEN]

**Contesto:** la matrice base in `00_overview.md` Sezione 6 copre il 90% dei casi. Scenari da decidere:

- Commenti su PublishedRoute di autore eliminato: chi puo' cancellarli? **Proposta:** owner della route.
- Like contati anche se liker ha eliminato account? **Proposta:** si', conteggio resta.
- LiveSession dopo crash del leader: continua o chiude? **Proposta:** auto-close dopo 10 min GPS inattivita' (ora formalizzata in D.36).
- Activity di utente banned: visibili o no? **Proposta:** auto-unpublish di tutte le PublishedRoute del bannato.

**Owner:** Ray + Lollo.

---

### B.2 -- Admin in-app: scope minimo MVP  [OPEN]

**Contesto:** in `00_overview.md` Sezione 2 deciso "admin moderazione in-app". Non definito **cosa** puo' fare.

**Scope minimo proposto:**

- Lista report utenti (user-submitted).
- Dettaglio report + azioni: dismiss, warn, unpublish route, ban user.
- Review error_logs recenti.

**Owner:** Ray (scope prodotto), Lollo (fattibilita').

---

### B.3 -- Offline-first per community: caching dei post pubblici?  [OPEN -- proposta concreta pronta]

**Contesto:** drift come cache locale. Per il feed community policy non decisa.

**Opzioni:**

- (a) Cache aggressiva: ultimi 50 post feed salvati localmente.
- (b) Cache minimale: solo own activity e own PublishedRoute offline; community richiede connessione.
- (c) Via di mezzo: caching su azione esplicita utente ("salva per offline").

**Proposta aggiornata Claude (dopo discussione agente di controllo):** variante **(c) pragmatica: "last-seen cache"**. L'ultima GET feed riuscita viene tenuta in memoria + `shared_preferences` con TTL 7 giorni. Offline: banner "Feed aggiornato alle {lastSeenAt}" + feed in sola lettura + azioni (like, commento) in coda sync. Own content sempre accessibile. Dettagli concreti in `07_community/edge_cases.md` Sezione 2.2.

**Perche' cambio:** per una app moto, feed completamente vuoto in offline e' un problema di percezione. La cache implicita last-seen costa poco in storage (pochi KB) e migliora molto l'esperienza in valli / tunnel. Non e' cache complessa -- e' una "snapshot" dell'ultima vista.

**Owner:** Ray (conferma approccio last-seen) + Lollo (implementazione in modulo 07).

---

### B.4 -- Mappe offline Mapbox  [OPEN]

**Contesto:** navigazione in zone senza copertura non supportata nativamente. Non nel Rev02.

**Domande:**

- MVP include download mappe offline per regione/percorso?
- Limiti tile Mapbox free tier (~6k per utente).
- Storage impact.

**Raccomandazione Claude:** rimandare a **MVP v1.1 o primo ciclo paywall** (non generico "post-MVP che scivola"). Per il target moto le mappe offline sono feature quasi-obbligatoria, non un nice-to-have. Lasciare fuori per sempre significa perdere il segmento hardcore.

**Target proposto:** v1.1 (circa 2-3 mesi dopo rilascio MVP). Candidata per paywall RevenueCat.

**Owner:** Ray.

---

### B.5 -- Crash detection: out-of-scope o telemetria passiva?  [OPEN]

**Contesto:** Rev02 dichiara crash detection troppo rischioso (falsi positivi SOS). Decisione confermata.

**Sub-domanda:** raccogliere telemetria accelerometro anche senza trigger SOS? Utile per future feature ML e debug GPS.

**Tradeoff:**

- Pro: dati gratis per futuro.
- Contro: piu' batteria, piu' storage, privacy concerns (GDPR).

**Raccomandazione Claude:** NON raccogliere in MVP. Minimalismo + privacy by default.

**Owner:** Ray.

---

### B.6 -- Visibilita' SafetyEvent per contact notificati  [OPEN]

**Contesto:** in `02_database_schema.md` Sezione 5.13 la policy attuale permette solo all'owner (e admin) di vedere safety_events.

**Domanda:** in futuro i SafetyContact (es. familiare che riceve SOS via SMS) dovrebbero poter accedere all'evento (vedere posizione su mappa dell'app) loggandosi con le proprie credenziali?

**Non implementabile in MVP** perche' SafetyContact e' un contatto denormalizzato (phone + email) senza legame a un Profile. Diventerebbe feature "invita il tuo contatto di sicurezza a scaricare l'app".

**Rimando:** feature post-MVP, design quando verra' affrontato.

**Owner:** Ray (scelta prodotto).

---

### B.7 -- Watchdog LiveSession: alert automatico su gpsInactivity  [OPEN]

**Contesto:** quando una LiveSession termina per `gpsInactivity` (10 min senza punti GPS), il viewer vede "sessione terminata" ma non sa se l'utente e' in area senza copertura o in difficolta'. E' esattamente la zona grigia dove un'app safety perde credibilita'.

**Proposta:**

- Se il viewer e' un SafetyContact registrato nell'app (phone number match), al termine per `gpsInactivity` triggera Edge Function che invia SMS automatico al contatto: "L'utente {X} ha perso segnale GPS alle {Y}. Ultima posizione: {link}. Non siamo sicuri dello stato. Contattalo."
- Owner puo' a sua volta, al ritorno online, inviare un "sono OK" con pulsante dedicato.

**Dettagli:** `09_safety/edge_cases.md` Sezione 3.5.bis.

**Decisione da prendere:** MVP o v1.1?

- Pro MVP: trasforma LiveSession da feature casual a safety vera.
- Contro MVP: richiede Edge Function aggiuntiva, link SafetyContact <-> viewer via phone match, UX "sono OK".

**Raccomandazione Claude:** se il posizionamento e' safety-primario, questa e' MVP. Se il posizionamento e' social+tracking con safety come feature complementare, v1.1.

**Owner:** Ray (posizionamento prodotto) + Lollo (stima implementazione).

---

### B.8 -- Onboarding flow  [OPEN]

**Contesto:** la spec definisce i **vincoli** di onboarding (username modificabile 7gg, SafetyContact necessario per SOS, prima moto auto-primary) ma non il **flusso narrativo**.

**Domande aperte:**

- Quante schermate di onboarding? (proposta: 3-4 max)
- Quali step sono obbligatori, quali saltabili?
- Quando chiediamo SafetyContact (subito? dopo primo giro? mai?)
- Come comunichiamo la battery strategy (tooltip al primo tracking, email, nulla)?
- Dati "fake" al profilo: bloccarli o tollerarli?

**Non bloccante per architettura** (Claude Code puo' implementare tracking/sync/garage senza onboarding definito). Ma necessario prima di beta.

**Owner:** Ray (design prodotto).

---

## Sezione C -- Watch list (cose da rivalutare dopo primi sprint)

Non sono aperte *ora*, ma vanno riviste a momenti precisi.

---

### C.1 -- Track points embedded vs tabella separata  [DEFERRED]

**Decisione attuale:** embedded in `activities` (`00_overview.md` Sezione 5.1).

**Quando rivalutare:** dopo 6-12 mesi di produzione se:

- Volume activity/utente cresce oltre aspettative.
- **Emerge caso d'uso "heatmap percorsi della community"** -- query geospaziale cross-activity sui punti, impossibile con jsonb embedded. Trigger piu' probabile.
- Performance read degrada (jsonb troppo grosso).

**Costo migrazione se servira':** medio. Migration che estrae punti dal jsonb verso tabella separata + partitioning.

---

### C.2 -- Migration da `error_logs` tabella a Sentry  [DEFERRED]

**Decisione attuale:** tabella Supabase (`00_overview.md` Sezione 5.10).

**Quando rivalutare:** volume > 10k errori/giorno, o servono alert real-time, o team cresce.

---

### C.3 -- Two-way sync / multi-device  [DEFERRED]

**Decisione attuale:** single-device, one-way push (`00_overview.md` Sezione 5.2).

**Quando rivalutare:** feedback utente > 5% su tablet o cambio device con perdita stato.

---

### C.4 -- Sentry o Plausible rollout  [DEFERRED]

**Decisione attuale:** attivati "quando servono".

**Trigger:**

- Plausible: appena si inizia a monetizzare o serve data-driven product decisions.
- Sentry: vedi C.2.

---

### C.5 -- Isolate Dart dedicato al tracking  [DEFERRED]

**Decisione attuale:** `flutter_background_service` standard, senza isolate custom (`00_overview.md` Sezione 5.11).

**Quando rivalutare:** se in produzione si osservano crash del main isolate (bug UI) che portano giu' anche il tracking, nonostante la scrittura progressiva limiti i danni.

**Note:** il `track_point_buffer` e' gia' compatibile con isolate dedicato. Aggiungerlo in futuro richiede solo rifattorizzare il modulo tracking.

---

## Sezione D -- Log delle decisioni chiuse (archivio)

Quando una item passa a `[DECIDED]`, viene spostata qui con data di decisione e riferimento spec.

---

### D.1 -- Architettura modulare con package Dart separati  [DECIDED]

**Decisione:** ogni modulo e' un package Dart autonomo con `lib/` pubblico + `lib/src/` privato.
**Spec:** `00_overview.md` Sezione 4.2.
**Data:** 18 aprile 2026.

### D.2 -- Eventual consistency cross-modulo  [DECIDED]

**Decisione:** letture cross-modulo tolleranti a lag, pattern Optional/null/empty.
**Spec:** `00_overview.md` Sezione 4.6.
**Data:** 18 aprile 2026.

### D.3 -- Event bus con regola dell'ascoltatore ignoto  [DECIDED]

**Decisione:** event bus solo per broadcast verso listener non noti a priori.
**Spec:** `00_overview.md` Sezione 4.5.
**Data:** 18 aprile 2026.

### D.4 -- Track points embedded nella activity finale, buffer separato durante registrazione  [DECIDED]

**Decisione:** `track_points_data` jsonb + polyline embedded nella riga `activities` chiusa. Durante registrazione attiva i punti vivono in tabella `track_point_buffer` separata.
**Spec:** `00_overview.md` Sezione 5.1 e 5.11.
**Data:** 18 aprile 2026.

### D.5 -- Sync single-device, one-way push  [DECIDED]

**Decisione:** mobile source of truth per nuove activity, pull solo per rehydration.
**Spec:** `00_overview.md` Sezione 5.2.
**Data:** 18 aprile 2026.

### D.6 -- Realtime solo per live tracking  [DECIDED]

**Decisione:** Supabase Realtime riservato a live session attive. Resto via FCM.
**Spec:** `00_overview.md` Sezione 5.3.
**Data:** 18 aprile 2026.

### D.7 -- Focus Android, iOS supportato by-default  [DECIDED]

**Decisione:** ottimizzazione Android primaria, iOS funzionante ma non feature-parity.
**Spec:** `00_overview.md` Sezione 5.4.
**Data:** 18 aprile 2026.

### D.8 -- Eliminazione account: soft delete anonimizzato  [DECIDED]

**Decisione:** activity restano, owner diventa "utente eliminato". Commenti/like anonimizzati, non cancellati.
**Spec:** `00_overview.md` Sezione 5.5. Implementazione trigger `anonymize_profile_on_soft_delete` in `02_database_schema.md` Sezione 4.4.
**Data:** 18 aprile 2026.

### D.9 -- Tags come text[] con suggerimenti lato app  [DECIDED]

**Spec:** `00_overview.md` Sezione 5.6.
**Data:** 18 aprile 2026.

### D.10 -- Activity media: tabella separata + thumbnail client-side  [DECIDED]

**Spec:** `00_overview.md` Sezione 5.7.
**Data:** 18 aprile 2026.

### D.11 -- Migrations timestamped + staging immediato  [DECIDED]

**Spec:** `00_overview.md` Sezione 5.8. Migration split in 6 file documentato in `02_database_schema.md` Sezione 10.
**Data:** 18 aprile 2026.

### D.12 -- Feature flags: jsonb su profiles  [DECIDED]

**Spec:** `00_overview.md` Sezione 5.9.
**Data:** 18 aprile 2026.

### D.13 -- Error logging: tabella Supabase, migrazione a Sentry condizionale  [DECIDED]

**Spec:** `00_overview.md` Sezione 5.10. Implementazione `02_database_schema.md` Sezione 3.15. Outbox pattern client-side in `03_local_db.md` Sezione 5.4.
**Data:** 18 aprile 2026.

### D.14 -- Matrice RLS baseline completa fin dall'inizio  [DECIDED]

**Decisione:** nessun "buco" RLS, ogni nuova tabella deve essere in matrice.
**Spec:** `00_overview.md` Sezione 6. Implementazione SQL in `02_database_schema.md` Sezione 5.
**Data:** 18 aprile 2026.

### D.15 -- Tracking survivability: scrittura progressiva in drift  [DECIDED]

**Decisione:** nessun dato GPS in corso di registrazione vive unicamente in RAM. Ogni punto scritto in `track_point_buffer` al momento della ricezione. Recovery session al riavvio dopo crash.
**Spec:** `00_overview.md` Sezione 5.11. Implementazione FSM in `04_tracking/state_machine.md`.
**Data:** 18 aprile 2026.

### D.16 -- Client-generated UUID e idempotency end-to-end  [DECIDED]

**Decisione:** ogni entita' user-generated nasce con `client_id` UUID v4 generato client-side prima della persistenza locale. Backend idempotente su `client_id` via `ON CONFLICT DO NOTHING`.
**Spec:** `00_overview.md` Sezione 5.12. Implementazione pratica in `02_database_schema.md` (UNIQUE constraint) e `05_sync/queue_design.md`.
**Data:** 18 aprile 2026.

### D.17 -- Km moto: scorporo automatico via trigger unico  [DECIDED]

**Decisione:** funzione trigger Postgres `recompute_motorcycle_km(motorcycle_id)` chiamata su INSERT activity, UPDATE `motorcycle_id`, soft DELETE activity. Policy prodotto: scorporo (km riflettono sempre le activity presenti).
**Spec:** `02_database_schema.md` Sezione 4.2. Aggiornamento ottimistico client-side documentato in `03_local_db.md` Sezione 4.2.
**Data:** 18 aprile 2026.

### D.18 -- Background service Android: flutter_background_service standard  [DECIDED]

**Decisione:** usiamo `flutter_background_service` standard con foreground service Android, senza isolate Dart dedicati custom. Irrobustimenti ulteriori rimandati a C.5.
**Spec:** `00_overview.md` Sezione 5.4 e 5.11. Implementazione FSM in `04_tracking/state_machine.md`.
**Data:** 18 aprile 2026.

### D.19 -- `PublishedRoute.source_client_id` polymorphic senza FK reale  [DECIDED]

**Decisione:** FK polimorfica verso `activities` o `planned_routes` gestita via trigger `null_published_source_on_parent_delete` su hard-delete del parent. Soft-delete del parent NON azzera il link.
**Spec:** `01_data_model.md` Sezione 8 e `02_database_schema.md` Sezione 4.3.
**Data:** 18 aprile 2026.

### D.20 -- Tabelle drift organizzate in shared/db/ vs modulo  [DECIDED]

**Decisione:** tabelle lette da piu' moduli (13 entita' replicate dal server) vivono in `shared/db/`. Tabelle private al modulo (`recording_sessions`, `track_point_buffer`, `sync_queue`, `error_log_outbox`) vivono nel modulo owner.
**Spec:** `03_local_db.md` Sezione 2.
**Data:** 18 aprile 2026.

### D.21 -- Storage buckets privati con path `{user_id}/...`  [DECIDED]

**Decisione:** 3 buckets (avatars, motorcycle_photos, activity_media) tutti privati. RLS policies via `storage.foldername(name)[1] = auth.uid()::text`. Accesso pubblico sempre via signed URL 15 min.
**Spec:** `02_database_schema.md` Sezione 6.
**Data:** 18 aprile 2026.

### D.22 -- `live_positions` server-side con TTL + nessuna persistenza client  [DECIDED]

**Decisione:** server `live_positions` ha `expires_at` + TTL pg_cron ogni 5 min. Client NON persiste posizioni live in drift -- buffer RAM scorrevole del modulo live.
**Spec:** `02_database_schema.md` Sezione 3.11, Sezione 7. Nota client in `03_local_db.md` Sezione 4.10.
**Data:** 18 aprile 2026.

### D.23 -- Auto-close LiveSession stale + failsafe 24h  [DECIDED]

**Decisione:** job pg_cron auto chiude LiveSession senza punti del leader per N min (vedi D.36 per N = 10 min), e failsafe dopo 24h comunque.
**Spec:** `02_database_schema.md` Sezione 7.
**Data:** 18 aprile 2026.

### D.24 -- Decimazione tracciato per giri molto lunghi (>6h)  [DECIDED]

**Decisione:** per registrazioni > 6h, modulo tracking applica decimazione 1 punto / 2 secondi (invece di 1/1s) per mantenere payload sotto soglia upload Supabase.
**Spec:** `05_sync/queue_design.md` Sezione 5.3.
**Data:** 18 aprile 2026.

### D.25 -- Seriale single-upload in-flight nel MVP  [DECIDED]

**Decisione:** sync_orchestrator processa un item alla volta. No concorrenza.
**Spec:** `05_sync/L0_architecture.md` Sezione 9.4 e `05_sync/queue_design.md` Sezione 9.
**Data:** 18 aprile 2026.

### D.26 -- Sync coda come "promemoria" non snapshot  [DECIDED]

**Decisione:** `sync_queue` contiene riferimenti a entity_client_id, non snapshot di payload. L'upload_dispatcher legge sempre fresh da drift al momento dell'invio.
**Spec:** `05_sync/queue_design.md` Sezione 3.4.
**Data:** 18 aprile 2026.

### D.27 -- Dipendenze FK calcolate automaticamente all'enqueue  [DECIDED]

**Decisione:** `queue_scheduler.enqueueWithAutoDeps()` legge l'entity e popola `dependency_client_ids` automaticamente. Chi enqueue non conosce le FK.
**Spec:** `05_sync/queue_design.md` Sezione 3.3.
**Data:** 18 aprile 2026.

### D.28 -- Niente chunking payload nel MVP  [DECIDED]

**Decisione:** niente chunking. Payload normali 10-50KB, sotto soglia Supabase. Giri > 6h gestiti con decimazione (D.24). Schema `sync_queue` pre-compatibile con chunking futuro.
**Spec:** `05_sync/queue_design.md` Sezione 5.
**Data:** 18 aprile 2026.

### D.29 -- No backup locale SQLite, server e' il backup  [DECIDED]

**Decisione:** DB drift NON incluso in Android Auto Backup. Coerente con single-device + rehydration: device perso, reinstall su nuovo, sync recupera.
**Spec:** `03_local_db.md` Sezione 9.4.
**Data:** 18 aprile 2026.

### D.30 -- Denormalizzazione `activity_media.owner_id`  [DECIDED]

**Decisione:** `activity_media.owner_id` duplicato da `activities.owner_id` per RLS performante senza JOIN. Trigger `enforce_activity_media_owner_consistency` blocca INSERT/UPDATE incoerenti.
**Spec:** `01_data_model.md` Sezione 6, `02_database_schema.md` Sezione 3.4.
**Data:** 18 aprile 2026.

---

### D.31 -- Retry policy numerica per sync (ex A.1)  [DECIDED]

**Decisione:** backoff esponenziale `BASE_DELAY * 2^retry_count * jitter` con BASE=30s, jitter=0.8-1.2, cap MAX=30min. Max retry automatici = 5 (cumulativo circa 15.5 minuti). Oltre soglia: stato `failed` + notifica utente. Retry manuale dall'UI disponibile.
**Spec:** `05_sync/queue_design.md` Sezione 4.
**Data:** 18 aprile 2026 (promossa in blocco TEC-CHIUDIBILE).

### D.32 -- PublishedRoute: snapshot (ex A.2)  [DECIDED]

**Decisione:** snapshot. Al publish, polyline + metadata copiati in `published_routes`. Modifiche post-hoc alla sorgente non si propagano (serve ri-publish). FK `source_client_id` con `ON DELETE SET NULL` via trigger polymorphic.
**Spec:** `01_data_model.md` Sezione 8 e `02_database_schema.md` Sezione 3.6.
**Data:** 18 aprile 2026.

### D.33 -- Signal lost timeout 15s (ex A.5)  [DECIDED]

**Decisione:** `>= 15 secondi` senza nuovi punti GPS, combinato con check velocita' pre-perdita > 20 km/h (distingue tunnel da parcheggio coperto).
**Spec:** `04_tracking/state_machine.md` Sezione 3.5 e `04_tracking/gps_filters.md` Sezione 5.
**Data:** 18 aprile 2026.

### D.34 -- Grace period buffer post-sync 7 giorni (ex A.6)  [DECIDED]

**Decisione:** `track_point_buffer` conservato 7 giorni oltre `closed_synced`, poi purge via `MaintenanceService` al bootstrap. Permette debug post-hoc senza gonfiare storage.
**Spec:** `00_overview.md` Sezione 5.11 e `03_local_db.md` Sezione 9.3.
**Data:** 18 aprile 2026.

### D.35 -- Warning coda offline accumulata (ex A.9)  [DECIDED]

**Decisione:** al superamento di 30 elementi pending nella `sync_queue_local`, banner UI "stai accumulando molti dati non sincronizzati, riabilita sync o verifica connessione".
**Spec:** `05_sync/queue_design.md` Sezione 9 e futura spec UI sync_status_banner.
**Data:** 18 aprile 2026.

### D.36 -- LiveSession timeout per inattivita' leader = 10 minuti (ex A.11)  [DECIDED]

**Decisione:** pg_cron `auto-close-stale-live-sessions` chiude LiveSession senza punti del leader per `>= 10 minuti`.
**Spec:** `02_database_schema.md` Sezione 7.
**Data:** 18 aprile 2026.

### D.37 -- Rimozione `server_id` dalle tabelle drift (ex A.13)  [DECIDED]

**Decisione:** `server_id` rimosso da tutte le tabelle drift. `client_id` e' l'unica PK logica lato client. `id` server-side resta solo in Postgres (necessario per FK interne del DB server).
**Spec:** `03_local_db.md` Sezione 4 (tutte le tabelle interessate).
**Data:** 18 aprile 2026.

### D.38 -- Drift multi-isolate: pattern `createInBackground` (ex A.14)  [DECIDED]

**Decisione:** uso `NativeDatabase.createInBackground()`: ogni isolate ha il proprio connector al file SQLite, locking gestito da SQLite. Pattern standard drift per 1Hz scritture. Migrazione a `DriftIsolate` con pipe possibile in futuro se emergono problemi specifici.
**Spec:** `03_local_db.md` Sezione 8.4.
**Data:** 18 aprile 2026.

### D.39 -- Schema drift v1 pre-dichiara tutte le tabelle MVP (ex A.15)  [DECIDED]

**Decisione:** schema drift v1 include TUTTE le tabelle MVP anche se i moduli corrispondenti arriveranno tardi (es. `notifications_local`). Evita migration nei primi sprint. `addColumn` ok in migration successive; le `addTable` in v1 tolgono attriti.
**Spec:** `03_local_db.md` Sezione 7.1.
**Data:** 18 aprile 2026.

### D.40 -- Path media client: relativo tramite `local_cache_path` (ex A.16)  [DECIDED]

**Decisione:** `activity_media_local` ha colonna `local_cache_path` (TEXT nullable) contenente path relativo alla `ApplicationDocumentsDirectory`. Repository espone `resolveLocalFullPath(relativePath)` che fa join runtime. `local_cache_path` valorizzato NON garantisce esistenza file -- sempre verificare `File.exists()` e, se assente, trigger download da Storage.
**Spec:** `03_local_db.md` Sezione 4.4.
**Data:** 18 aprile 2026.

### D.41 -- Lazy loading `track_points_data` + compute isolate per payload grossi (ex A.17)  [DECIDED]

**Decisione:** due livelli. Primo: DAO espone `loadTrackPointsForActivity(clientId)` separato dalle query feed. Il feed carica solo `polyline_encoded` (20-50 KB, decode istantaneo). Secondo: per activity con `length(track_points_data) > 500 KB`, decode JSON via `compute()` su isolate temporaneo. `polyline_encoded` sempre eager, `track_points_data` sempre lazy.
**Spec:** `03_local_db.md` Sezione 9.2.
**Data:** 18 aprile 2026.

### D.42 -- Clock wall-clock per durate registrazione (ex A.19)  [DECIDED]

**Decisione:** uso `DateTime.now()` wall-clock per calcolo `duration_seconds = ended_at - started_at`. Documentato "non cambiare timezone mid-ride" come limite noto MVP. Upgrade a monotonic clock (`Stopwatch`) possibile in futuro senza impatto schema.
**Spec:** `04_tracking/edge_cases.md` Sezione 5.4.
**Data:** 18 aprile 2026.

### D.43 -- Media orfani post-sync: code indipendenti (principio ex A.18)  [DECIDED]

**Decisione (principio architetturale):** Activity e ActivityMedia hanno code di sync indipendenti. Activity priorita' 3, ActivityMedia priorita' 4. Una ActivityMedia che fallisce 5 volte va `failed` **senza trascinare l'Activity parent in failed**. Activity resta `synced`. Sub-decisione UX (X vs Y per mostrare/nascondere foto failed) resta aperta in A.18.
**Spec:** `05_sync/queue_design.md` Sezione 3 e Sezione 2 (priorita').
**Data:** 18 aprile 2026.

---

## Riepilogo stato attuale

**Totali per sezione:**

- Sezione A (proposte, attendono Lollo o Ray): **9 item**
- Sezione B (aperte, richiedono decisione): **8 item**
- Sezione C (watch list, da rivalutare): **5 item**
- Sezione D (decisioni archiviate): **43 item**

**Priorita' di discussione:**

**Per Ray (scelte UX / prodotto / posizionamento):**
- A.3 UX dialog recovery (X vs Y resume)
- A.7 MAX_ACTIVITIES_REHYDRATION = 50
- A.10 route_likes visibility
- A.12 Username enforcement entro 7gg
- A.18 Foto failed: mostrare o auto-nascondere
- A.20 Auto-stop batteria al 3%
- A.21 Warning UX GPS scadente
- B.7 Watchdog LiveSession (MVP o v1.1?) -- **nuovo, ad alta priorita' per safety positioning**
- B.8 Onboarding flow -- **nuovo, necessario pre-beta**
- B.4 Mappe offline (v1.1 o paywall)

**Per Lollo (tuning in campo / implementativo):**
- A.4 Auto-pause 1km/h x 30s
- A.8 Intervallo auto-retry orario (fisso vs crescente)

**Item B.3 aggiornato** con proposta concreta "last-seen cache" -- Ray conferma, poi si chiude.

**Bloccanti per la produzione di spec successive (moduli 06-12):** nessuno. Moduli 06-12 gia' scritti. Possibile iniziare sviluppo.

**Interventi spec applicati post-agente-controllo:**

- `05_sync/ux_feedback.md` creato (matrice stati + micro-copy IT).
- `09_safety/edge_cases.md` esteso (accuracy scadente SOS, watchdog LiveSession).
- `04_tracking/L0_architecture.md` Sezione 12 aggiunta (battery strategy).
- `07_community/edge_cases.md` Sezione 2.2 riscritta (policy offline last-seen).

---

**Fine 99_open_questions.md**
