# 05 / Sync -- L0 Architecture

**Modulo:** `sync`
**Scopo:** descrivere a livello macro cosa fa il modulo sync, cosa possiede, come si relaziona con il resto dell'app. Dettagli della coda in `queue_design.md`, idempotency in `idempotency.md`, edge case in `edge_cases.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Il modulo `sync` e' responsabile di **portare verso Supabase tutte le entita' user-generated create o modificate localmente**, in modo affidabile e trasparente all'utente.

In una frase: tiene il server allineato con il client, in push unidirezionale.

**Cosa fa:**

- Osserva le entita' user-generated con `sync_state = pending` o `failed`.
- Gestisce una coda persistente di operazioni di sync (`sync_queue`).
- Esegue upload verso Supabase rispettando idempotency (vedi overview Sezione 5.12) e dipendenze tra entita' (Motorcycle prima di Activity, Activity prima di PublishedRoute, ecc.).
- Applica retry policy con backoff esponenziale.
- Aggiorna lo stato locale (`sync_state`) a sync riuscito.
- Esegue rehydration una tantum dal server al primo login su nuovo device.

**Cosa NON fa (frontiera con altri moduli):**

- Non crea entita'. La creazione e' responsabilita' dei singoli moduli (tracking crea Activity, garage crea Motorcycle, community crea PublishedRoute/Comment/Like). Sync le pesca quando hanno `sync_state = pending`.
- Non sincronizza `RecordingSession` e `TrackPointBuffer`. Quelle sono puramente locali per design (vedi `01_data_model.md` Sezione 3, Sezione 4).
- Non gestisce Realtime (live tracking). Quello e' un canale separato, vive nel modulo live/safety con connessione diretta a Supabase Realtime.
- Non gestisce le Notification in arrivo dal server (push FCM). Quello e' un altro modulo (notifications).
- Non gestisce login / autenticazione. Quella e' del modulo auth/profile.

---

## Sezione 2 -- Entita' possedute

Il modulo `sync` e' owner esclusivo della seguente tabella drift:

- **`sync_queue`** -- tabella locale che tiene traccia delle operazioni di upload pianificate o in corso. Schema e invarianti in `queue_design.md`.

Il modulo `sync` e' **writer secondario** di tutte le tabelle user-generated:

- Legge: qualsiasi tabella dove esiste un record con `sync_state IN ('pending', 'failed')`.
- Scrive: aggiorna `sync_state`, `sync_retry_count`, `sync_last_error` sulle righe gestite. NON modifica i campi di dominio.

Regola di invariante: il modulo sync **non puo' mai modificare campi business** (titolo activity, distance_km, ecc.). Puo' modificare solo colonne di metadata di sync. Enforced da code review e convenzione. Se un giorno si decidera' di fare due-way sync, questa regola andra' rivista esplicitamente.

---

## Sezione 3 -- API pubblica (sintesi)

Dettagli completi in `L05_interfaces.md` (da scrivere in seguito). Qui la forma.

Il modulo espone una classe astratta `SyncApi` in `modules/sync/lib/api.dart` con:

- **Stato globale**: `Stream<SyncOverview>` espone `{pending_count, syncing_count, failed_count, last_successful_sync_at, is_online}`. Consumer tipico: UI banner "hai N elementi da sincronizzare".
- **Trigger manuale**: `requestSync()` -- forza un tentativo immediato (l'utente tap "riprova"). Non garantisce successo; risposta asincrona via stream.
- **Retry manuale di un falliti**: `retryFailed(clientId?)` -- ri-accoda uno specifico item (se `clientId` passato) o tutti i `failed` dell'utente.
- **Rehydration**: `performInitialRehydration()` -- una tantum, chiamata dal bootstrap dopo primo login riuscito su device privo di dati. Scarica profilo, moto, ultime N activity, planned_routes, safety_contacts, follows.
- **Pause sync**: `setAutoSyncEnabled(bool)` -- l'utente puo' disabilitare sync automatica (es. per risparmiare traffico dati in roaming). Gli item restano in coda fino a ri-abilitazione.

Nessun'altra API pubblica. Operazioni di basso livello (forzare upload di una specifica riga, leggere la coda) sono interne al modulo.

---

## Sezione 4 -- Dipendenze dichiarate

Nel manifest `modules/sync/lib/sync.dart`:

```dart
@override
List<String> get dependsOn => [
  'shared.db',                   // drift instance globale
  'shared.supabase_client',      // client Supabase + auth state
  'shared.event_bus',            // ascolta eventi di altri moduli
];

@override
List<Type> get consumes => [];   // nessuna API pubblica di altri moduli chiamata

@override
List<Type> get provides => [
  SyncApi,
];
```

**Perche' `consumes` e' vuoto:** il modulo sync lavora esclusivamente via tabelle drift condivise + event bus. Non chiama API pubbliche di altri moduli. Questo lo rende **passivo** rispetto agli altri: se domani aggiungiamo un modulo `gamification`, sync lo sincronizzera' automaticamente purche' le sue tabelle seguano la convenzione `sync_state + client_id`.

**Librerie di terze parti:**

- `supabase_flutter` -- client ufficiale Supabase.
- `drift` -- persistenza (via `shared.db`).
- `connectivity_plus` -- detection stato rete.
- `uuid` -- generazione id interni della `sync_queue` (separati da `client_id` delle entita').

---

## Sezione 5 -- Struttura interna

```
modules/sync/
|-- pubspec.yaml
|-- lib/
|   |-- sync.dart                       (manifest + classe modulo)
|   |-- api.dart                        (SyncApi astratta + types pubblici)
|   +-- src/
|       |-- domain/
|       |   |-- sync_state.dart         (enum SyncState + sealed classes)
|       |   |-- entity_kind.dart        (enum EntityKind: activity, motorcycle, ...)
|       |   |-- sync_operation.dart     (Insert | Update | Delete)
|       |   |-- retry_policy.dart       (funzione pura: retry_count -> next_delay)
|       |   +-- sync_priority.dart      (mapping EntityKind -> priority int)
|       |-- application/
|       |   |-- sync_orchestrator.dart  (loop principale: pick next, upload, update state)
|       |   |-- queue_scheduler.dart    (decide ordine di dequeue rispettando priorita' + dipendenze)
|       |   |-- upload_dispatcher.dart  (per EntityKind, chiama l'endpoint Supabase giusto)
|       |   |-- rehydration_service.dart
|       |   |-- connectivity_watcher.dart (online/offline detection)
|       |   +-- failure_classifier.dart (decide se errore e' retriable o permanent)
|       |-- persistence/
|       |   |-- sync_queue_table.dart
|       |   +-- sync_queue_repository.dart
|       +-- ui/
|           |-- sync_status_banner.dart
|           |-- sync_details_screen.dart (lista item pending/failed + azioni)
|           +-- widgets/
|               +-- retry_button.dart
+-- test/
    |-- domain/
    |-- application/
    +-- persistence/
```

**Note strutturali:**

- `domain/` Dart puro. `retry_policy` e' una funzione pura testabile con coverage 100%.
- `application/sync_orchestrator.dart` e' il loop centrale. Avviato al login, fermato al logout. Vive come servizio singleton nel modulo.
- `upload_dispatcher.dart` ha UNA funzione per ogni `EntityKind`. Dispatch: `(EntityKind, operation, clientId) -> Future<SyncResult>`. Contiene la conoscenza Supabase-specifica (endpoint, shape payload, gzip per track_points_data, ecc.). Tutta la conoscenza "come si parla a Supabase" e' concentrata qui.
- `failure_classifier.dart` distingue errori **retriable** (network, 5xx, timeout) da errori **permanent** (4xx non-auth, constraint violations, shape invalid). Tavola di classificazione in `edge_cases.md`.

---

## Sezione 6 -- Eventi

### 6.1 Eventi emessi

- **`SyncQueueFlushedEvent`** -- payload: `{timestamp, items_synced_count}`. Emesso quando la coda passa da non-vuota a vuota con successo. Consumer tipico: UI per nascondere banner.
- **`SyncItemFailedEvent`** -- payload: `{client_id, entity_kind, error_reason, retry_count}`. Emesso quando un item supera `max_retries` (diventa `failed`). Consumer tipico: UI notifica "X non sincronizzato".
- **`RehydrationCompletedEvent`** -- payload: `{items_count_per_kind}`. Emesso al termine della rehydration iniziale. Consumer tipico: UI bootstrap per passare da splash a home.

### 6.2 Eventi consumati

- **`ActivityCompletedEvent`** (da modulo tracking) -- il modulo sync reagisce: legge la nuova Activity da drift, crea entry in `sync_queue`, triggera orchestrator.
- **`UserLoggedInEvent`** (da modulo auth) -- sync avvia orchestrator, controlla se serve rehydration iniziale.
- **`UserLoggedOutEvent`** (da modulo auth) -- sync ferma orchestrator, non cancella la coda (puo' esserci utente che cambia account e poi torna).
- **`ConnectivityChangedEvent`** (da modulo connectivity_watcher interno, o emesso come evento cross-modulo se serve) -- sync riprende orchestrator quando torna online.

### 6.3 Perche' `ActivityCompletedEvent` e' un evento e non una chiamata diretta

Conforme alla regola dell'ascoltatore ignoto (overview Sezione 4.5). Il modulo tracking emette `ActivityCompletedEvent` come broadcast: vari moduli possono reagire (sync fa upload, garage aggiorna km locali, community prepara suggerimento publish, gamification attribuira' badge in futuro). Tracking non sa chi ascolta.

---

## Sezione 7 -- Interazioni operative (alto livello)

Dettagli tecnici della coda e del retry in `queue_design.md`. Qui solo il flusso a spanne.

### 7.1 Upload di una nuova Activity

1. Tracking completa una Activity e la scrive in `activities` con `sync_state = pending`. Emette `ActivityCompletedEvent`.
2. Sync riceve evento -> `queue_scheduler.enqueue({entity_kind: activity, operation: insert, client_id})`.
3. `sync_orchestrator` loop: dequeue top priority item, verifica dipendenze (es. la moto associata e' gia' sul server?), se ok chiama `upload_dispatcher.upload(item)`.
4. `upload_dispatcher`:
   - Legge la riga da drift (`activities WHERE client_id = ...`).
   - Costruisce payload (gzip di `track_points_data`).
   - Invia via `supabase_flutter.from('activities').upsert(payload, onConflict: 'client_id')`.
   - Riceve risposta.
5. Su successo:
   - Update `activities.sync_state = synced`.
   - Update `activities.id` con `id` server-side ricevuto.
   - Remove riga da `sync_queue`.
   - Chiama `TrackingApi.markRecordingSessionSynced(clientId)` (chiamata diretta per rimuovere buffer -- vedi interazione con tracking Sezione 7.5).
6. Su failure retriable:
   - Update `sync_queue.retry_count += 1`, `next_retry_at = now() + backoff`.
   - Orchestrator procede con item successivo.
7. Su failure permanent:
   - Update `activities.sync_state = failed`, salva `sync_last_error`.
   - Remove da `sync_queue` (non ritentiamo automaticamente errori permanenti).
   - Emette `SyncItemFailedEvent`.

### 7.2 Rehydration su nuovo device

1. Utente installa l'app su device nuovo, fa login con credenziali esistenti.
2. Modulo auth emette `UserLoggedInEvent` con flag `is_first_login_on_device = true` (determinato dall'assenza di dati locali).
3. Sync riceve evento -> `rehydration_service.perform()`.
4. Rehydration scarica in ordine:
   a. Profile completo (1 chiamata).
   b. Motorcycles dell'utente (1 chiamata).
   c. Ultime 50 Activities dell'utente (paginazione se serve).
   d. Planned routes dell'utente.
   e. Safety contacts.
   f. Follow relationships (follower + followed).
   g. Ultime PublishedRoute proprie.
5. Ogni oggetto scaricato viene scritto in drift con `sync_state = synced` (e' gia' sul server).
6. Flag `profile.local_initial_rehydration_complete = true` (colonna drift-only, non esiste su server).
7. Emette `RehydrationCompletedEvent`.

Durante rehydration la UI mostra splash "recupero dati in corso...". Se rehydration fallisce a meta' (rete cade), e' idempotente: puo' essere riavviata dal punto in cui ha lasciato. Ogni scarico e' transazione separata.

### 7.3 Riavvio dell'app con coda non vuota

1. Al bootstrap, dopo login, sync legge `sync_queue` esistente.
2. Se non vuota: avvia orchestrator. Item con `next_retry_at <= now()` vengono processati immediatamente. Altri aspettano.
3. Se `rehydration_complete = false`: rehydration ha priorita' assoluta, coda di push viene messa in pausa fino a termine rehydration. Motivo: evitare conflitti con dati che stanno per arrivare.

### 7.4 Offline prolungato

Se il dispositivo e' offline per giorni:

1. `connectivity_watcher` sa che siamo offline, orchestrator non tenta upload (risparmia batteria e log error).
2. L'utente puo' continuare a usare l'app normalmente: creare Activity, Moto, ecc. Tutto resta in drift con `sync_state = pending`, accumula in `sync_queue`.
3. Al ritorno online: `ConnectivityChangedEvent{online: true}` -> orchestrator riparte, processa coda in ordine di priorita'.
4. UI espone badge "X elementi in attesa di sync" tramite `SyncApi.overview`.

---

## Sezione 8 -- Interfaccia con moduli vicini

### 8.1 Verso `tracking`

- **Trigger**: `ActivityCompletedEvent` via event bus.
- **Callback**: a sync riuscito, sync chiama `TrackingApi.markRecordingSessionSynced(clientId)` direttamente (API diretta, non evento). Motivazione: sync sa esattamente chi deve chiamare (tracking). Tracking a quel punto puo' purgare il `track_point_buffer` relativo.

### 8.2 Verso `garage`

- **Trigger**: garage crea/modifica Motorcycle, scrive in drift con `sync_state = pending`. Sync pesca e sincronizza.
- **Priorita'**: Motorcycle sync prima delle Activity che le riferiscono (FK dependency). Dettaglio in `queue_design.md` Sezione priorita'.
- **Nessun callback specifico**. Garage non riceve notifiche da sync; se gli serve reagire, consuma `SyncItemFailedEvent`.

### 8.3 Verso `community`

- **Trigger**: community crea PublishedRoute, RouteComment, RouteLike, Follow -> scrive con `sync_state = pending`.
- **Priorita'**: PublishedRoute richiede che Activity sorgente sia gia' sincronizzata. Il queue_scheduler verifica la dipendenza prima di dequeuare.
- Comment e Like richiedono che PublishedRoute esista server-side.

### 8.4 Verso `safety`

- **SafetyContact** e **SafetyEvent** vengono sincronizzati come altre entita'.
- **LiveSession / LivePosition** NON passano per il modulo sync -- usano canale Realtime diretto (live -> Supabase Realtime) gestito dal modulo safety.

### 8.5 Verso `auth`

- **UserLoggedInEvent**: sync parte.
- **UserLoggedOutEvent**: sync si ferma, coda persiste.
- **UserDeletedAccountEvent** (futuro): sync fa flush finale + clear coda.

### 8.6 Verso l'UI / app

- Banner di stato in `ui/sync_status_banner.dart` che legge `SyncApi.overview`.
- Screen di dettaglio in `ui/sync_details_screen.dart` dove l'utente vede item pending/failed, puo' tappare "riprova" o "elimina e scarta".

---

## Sezione 9 -- Performance e risorse

### 9.1 Frequenza di polling

- L'orchestrator non fa polling continuo. E' **event-driven**: reagisce a `enqueue` da altri moduli + `ConnectivityChangedEvent` + scadenza `next_retry_at` di item in coda.
- Per gestire `next_retry_at`, usa un timer interno che si risveglia al minimo `next_retry_at` presente in coda. Nessun wake inutile.

### 9.2 Rete

- Upload via HTTPS verso Supabase. Nessuna persistent connection (Realtime resta chiuso dal modulo sync).
- Payload gzip-compressi per Activity (solo `track_points_data`). Risparmio circa 8-10x.
- Timeout richiesta: 30 secondi. Piu' lungo sarebbe fastidioso per UX; meno e' rischioso per upload di giri grossi su rete lenta.

### 9.3 Batteria

- Upload in burst (rapido quando c'e' rete) e' piu' efficiente di upload continuo. L'orchestrator accumula item e li sincronizza insieme al ritorno online.
- Non tiene la CPU sveglia. Se app in background e coda vuota, zero consumo.

### 9.4 Concorrenza

- Un solo upload in-flight alla volta nel MVP. Semplicita' > throughput.
- Se in futuro serve, l'orchestrator puo' passare a "N upload concorrenti per kind diversi" senza toccare altro.

---

## Sezione 10 -- Riepilogo per implementazione

Checklist per chi implementera':

- [ ] Dichiarare `modules/sync` in `melos.yaml`.
- [ ] Implementare `SyncModule` (manifest).
- [ ] Definire `SyncApi` e types pubblici in `lib/api.dart`.
- [ ] Implementare `SyncQueueTable` drift e repository.
- [ ] Implementare `EntityKind` enum con mapping priorita' in `sync_priority.dart`.
- [ ] Implementare `retry_policy` pura.
- [ ] Implementare `FailureClassifier` con tavola retriable/permanent.
- [ ] Implementare `QueueScheduler` (dequeue con priorita' + dipendenze).
- [ ] Implementare `UploadDispatcher` con un metodo per EntityKind.
- [ ] Implementare `SyncOrchestrator` (loop event-driven).
- [ ] Implementare `RehydrationService`.
- [ ] Implementare `ConnectivityWatcher`.
- [ ] UI: SyncStatusBanner, SyncDetailsScreen.
- [ ] Test: domain (retry_policy, scheduler); application con mock Supabase client.

---

## Sezione 11 -- Note a futuro

Cose non implementate ora ma per le quali il design e' compatibile:

- **Two-way sync / multi-device** (open C.3): aggiungerebbe una seconda direzione (pull incrementale delta). Richiederebbe colonne `server_version` e logica di merge. Il modulo sync resterebbe owner della coordinazione; `SyncApi` si estenderebbe, `UploadDispatcher` si affiancherebbe a un `PullDispatcher`.
- **Sync concorrente multi-kind**: orchestrator passa da seriale a parallelo. Richiede lock per kind per evitare corse.
- **Priorita' custom utente** ("spedisci prima questa foto"): aggiungere campo `user_priority` a `sync_queue`.
- **Payload chunking** per Activity grandissime (>1MB): oggi non previsto, vedi `queue_design.md` Sezione chunking per razionale. Se emerge come necessario, lo schema `sync_queue` e' gia' compatibile (basta aggiungere `chunk_index` e `total_chunks`).

---

**Fine 05_sync/L0_architecture.md**
