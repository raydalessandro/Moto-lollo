# 05 / Sync -- Queue Design

**Scopo:** dettaglio del funzionamento della coda di sync: schema tabella, priorita', ordinamento, dipendenze tra entita', retry policy, gestione failure modes.

**Relazione con altri documenti:**
- Architettura generale del modulo: `L0_architecture.md`.
- Classificazione errori retriable vs permanent: `edge_cases.md` (da scrivere).
- Idempotency lato Supabase: `idempotency.md` (da scrivere).

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Schema della tabella `sync_queue`

Tabella drift locale. Mai sincronizzata con Supabase (e' stato client).

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `id` | Integer | no | PK auto-increment drift. Puramente tecnico. |
| `entity_kind` | Enum | no | `activity \| motorcycle \| planned_route \| published_route \| route_comment \| route_like \| follow_relationship \| safety_contact \| safety_event \| activity_media \| profile`. |
| `entity_client_id` | UUID | no | `client_id` dell'entita' da sincronizzare. |
| `operation` | Enum | no | `insert \| update \| delete`. |
| `priority` | Integer | no | Derivata da `EntityKind` (vedi Sezione 2). Lower = higher priority. |
| `enqueued_at` | Timestamp | no | Quando la riga e' stata aggiunta alla coda. |
| `retry_count` | Integer | no | Default 0. Numero di retry gia' tentati. |
| `next_retry_at` | Timestamp | no | Quando e' legittimo tentare il prossimo upload. |
| `last_error_code` | String | si | Codice errore ultimo tentativo (es. `NETWORK_TIMEOUT`, `HTTP_503`, `PERMISSION_DENIED`). |
| `last_error_message` | String | si | Messaggio leggibile per log / UI. |
| `last_attempt_at` | Timestamp | si | Quando e' stato tentato l'ultimo upload. |
| `dependency_client_ids` | Array of UUID | no | Default `[]`. client_id di altri entity che devono essere `synced` prima di questo. |
| `state` | Enum | no | `queued \| in_flight \| awaiting_retry \| blocked_by_dependency`. |

### 1.1 Perche' `id` separato da `entity_client_id`

Un'entita' puo' avere piu' righe in coda:
- Insert e successivamente update prima che l'insert sia completato (es. utente modifica titolo Activity subito dopo averla creata, prima che sync inizi).
- In futuro (chunking) una singola Activity grossa produrrebbe N righe.

Separare `id` coda da `entity_client_id` evita ambiguita'.

### 1.2 Invarianti tabella

1. Su entita' con `sync_state = synced`: NON deve esistere riga in `sync_queue` (se esiste, e' un bug e il modulo sync la rimuove all'avvio).
2. Su entita' con `sync_state = pending`: DEVE esistere almeno una riga in `sync_queue` (altrimenti resterebbe "orfana", mai sincronizzata). L'invariante e' mantenuta dal contratto: chi setta `sync_state = pending` deve enqueue.
3. Su entita' con `sync_state = failed`: NON esiste riga in `sync_queue` (la riga viene rimossa quando si supera max retry o si classifica errore come permanent). Il retry manuale dell'utente ri-crea la riga.
4. Un entity_kind x entity_client_id non puo' avere simultaneamente operazioni in conflitto (es. `insert` + `delete`). Se accade, si applica regola di coalescence (Sezione 3.4).

---

## Sezione 2 -- Priorita' per EntityKind

Valore numerico: 1 = priorita' piu' alta.

| EntityKind | Priorita' | Motivazione |
|---|---|---|
| `profile` | 1 | Aggiornamenti profilo di solito piccoli; devono propagarsi rapidamente per coerenza. |
| `motorcycle` | 2 | Dependency di Activity. Deve esistere server-side prima delle Activity che la riferiscono. |
| `activity` | 3 | Core business. Anche se grossa in payload, e' il valore principale dell'utente. |
| `activity_media` | 4 | Dependency: Activity gia' synced. Peso grande (foto); non bloccare Activity piu' piccole. |
| `planned_route` | 5 | Utente puo' usarla offline; sync differibile senza perdita UX. |
| `published_route` | 6 | Dependency: Activity o PlannedRoute sorgente. |
| `safety_contact` | 2 | Alta priorita'. Aggiornamenti qui devono propagarsi in fretta: un contatto nuovo deve essere valido se scatta un SOS. |
| `safety_event` | 1 | Se l'utente preme SOS, il record deve arrivare server-side il prima possibile (oltre alla notifica via Twilio che e' canale separato). |
| `route_comment` | 7 | Social, non urgente. |
| `route_like` | 8 | Social, idempotente e di basso valore singolo. |
| `follow_relationship` | 7 | Social. |

**Regola scheduler:** ad ogni dequeue, scegliere l'item con minor `priority`. A parita' di priorita', ordine FIFO (`enqueued_at` crescente).

---

## Sezione 3 -- Dipendenze tra entita'

Alcune entita' non possono essere sincronizzate finche' altre non lo sono. Le dipendenze sono **FK server-side**: se un INSERT su Supabase tenta di referenziare una riga che non esiste ancora, fallisce con errore di vincolo.

### 3.1 Dipendenze dichiarate

| Entity | Dipende da (FK) | Note |
|---|---|---|
| `activity` | `motorcycle` (se `motorcycle_id` non null) | Se null, nessuna dipendenza. |
| `activity_media` | `activity` | Sempre. |
| `published_route` | `activity` o `planned_route` (source) | A seconda di `source_type`. |
| `route_comment` | `published_route` | Sempre. |
| `route_like` | `published_route` | Sempre. |
| `follow_relationship` | `profile` (follower) + `profile` (followed) | Entrambi devono esistere. In pratica `follower_id = own` sempre gia' esistente; `followed_id` sempre server-side (altro utente). Nessuna vera dipendenza locale. |
| `safety_event` | (nessuna) | I SafetyContact snapshot sono nell'array dentro SafetyEvent, no FK. |

### 3.2 Risoluzione dipendenze al dequeue

Quando lo scheduler vuole dequeuare un item, verifica le dipendenze:

1. Legge `dependency_client_ids` dell'item.
2. Per ogni `dep_id`, verifica che la riga con quel `client_id` sulla tabella appropriata abbia `sync_state = synced`.
3. Se tutte le dipendenze sono soddisfatte -> procede al dispatch.
4. Se almeno una NON e' soddisfatta -> marca lo stato item come `blocked_by_dependency`, passa al prossimo item in coda.
5. `blocked_by_dependency` viene riconsiderato ad ogni evento `SyncQueueFlushedEvent` o al successo di un sync (che potrebbe sbloccare le dipendenze).

### 3.3 Popolamento `dependency_client_ids` all'enqueue

Quando un modulo produce un entity e lo enqueue, il metodo `enqueue` di sync calcola automaticamente le dipendenze leggendo l'entity dalla drift:

- Enqueue `activity`: leggi `activity.motorcycle_id`. Se non null e la motorcycle ha `sync_state != synced`, aggiungi `motorcycle_id` a `dependency_client_ids`.
- Enqueue `activity_media`: leggi `activity_media.activity_id`. Se activity ha `sync_state != synced`, dipendenza.
- Enqueue `published_route`: leggi `source_type` e `source_client_id`. Verifica source.
- Enqueue `route_comment` / `route_like`: verifica `published_route_id`.

La logica e' incapsulata in `queue_scheduler.enqueueWithAutoDeps(entity)`.

### 3.4 Coalescence (operazioni in conflitto)

Casi dove un entity_client_id ha piu' righe in coda simultaneamente:

| Situazione | Azione |
|---|---|
| Insert (queued) + nuovo Update | Update viene ignorato (il prossimo upload Insert carichera' lo stato aggiornato dell'entita' letto fresco da drift). |
| Insert (in_flight) + nuovo Update | Update viene enqueued come `update` separato, con priorita' sequenziale (verra' eseguito dopo che Insert termina). |
| Insert (queued) + Delete | Entrambi rimossi dalla coda. L'entita' non e' mai arrivata sul server, quindi non c'e' niente da cancellare. |
| Insert (in_flight) + Delete | Delete enqueued; verra' eseguito dopo completamento Insert. |
| Update (queued) + nuovo Update | Update precedente ignorato (l'upload del piu' recente portera' il nuovo stato). |

**Regola generale:** il payload e' sempre letto fresco da drift al momento dell'upload. Le righe in coda sono essenzialmente "promemoria di sincronizzare questo entity" -- non contengono snapshot del payload. Questo semplifica molto la coalescence.

---

## Sezione 4 -- Retry policy

### 4.1 Formula backoff

```
next_retry_delay_seconds = min(
  BASE_DELAY * (2 ^ retry_count) * jitter_factor,
  MAX_DELAY
)
```

Dove:
- `BASE_DELAY = 30` secondi
- `MAX_DELAY = 1800` secondi (30 minuti) -- cap per non avere attese assurde
- `jitter_factor = random(0.8, 1.2)` -- evita thundering herd se molti client sono offline contemporaneamente e tornano online insieme
- `retry_count` parte da 0 al primo tentativo

Valori risultanti indicativi (senza jitter):

| retry_count | next_delay |
|---|---|
| 0 | 30s (primo retry) |
| 1 | 60s |
| 2 | 120s |
| 3 | 240s |
| 4 | 480s (8 min) |
| 5 | 960s (16 min) |
| 6 | 1800s (capped) |

### 4.2 Soglia max retry automatici

**`MAX_AUTO_RETRIES = 5`.**

Dopo 5 tentativi falliti automaticamente, l'item passa a `failed`:
- `sync_state` dell'entita' = `failed`.
- Riga rimossa dalla `sync_queue`.
- `sync_last_error` popolato con ultimo errore.
- Emesso `SyncItemFailedEvent`.

Cumulative wait time prima di dare failed: 30 + 60 + 120 + 240 + 480 = **930 secondi (15.5 minuti)**. Trade-off accettabile tra "non spammare server" e "non far aspettare l'utente troppo".

### 4.3 Retry manuale utente

Se l'utente tappa "riprova" sulla UI:
- `SyncApi.retryFailed(clientId)` reinserisce l'item in `sync_queue` con `retry_count = 0`, `next_retry_at = now()`.
- `sync_state` dell'entita' torna a `pending`.
- L'orchestrator processa immediatamente.

### 4.4 Auto-retry orario dei `failed`

Il sistema **non** abbandona definitivamente gli item `failed`. Un timer periodico ogni **1 ora** ritenta tutti gli entity con `sync_state = failed`:

- Riaccoda con `retry_count = 0`.
- Se fallisce di nuovo entro i 5 tentativi del nuovo ciclo -> torna `failed` per un'altra ora.
- Motivo: molti errori sono **transitori su scala lunga** (rete scarsa per un'ora, outage Supabase di 30 minuti). Fare retry solo per 15 minuti iniziali perderebbe questi casi.

L'utente NON viene ri-notificato ad ogni tentativo. La notifica `SyncItemFailedEvent` si ferma dopo il primo ciclo di failure; se nel frattempo il retry orario riesce, la UI torna semplicemente verde.

### 4.5 Classificazione errori retriable vs permanent

La `retry_policy` si applica solo a errori **retriable**. Errori **permanent** saltano direttamente a `failed` senza retry.

Tabella completa in `edge_cases.md`. Qui solo il principio:

- **Retriable**: network timeout, connection refused, DNS failure, HTTP 5xx, HTTP 429 (rate limit), Supabase error code che indica temporaneita'.
- **Permanent**: HTTP 4xx (escluso 429), constraint violation (non dovrebbe capitare grazie a idempotency ma e' difensivo), payload malformato, auth scaduta (in realta' va gestita facendo re-login, non come failure sync).

Il `failure_classifier.dart` del modulo ha la tavola completa.

---

## Sezione 5 -- Chunking (non implementato in MVP)

Supabase ha limiti pratici su body size API:
- PostgREST default: request body fino a 8MB-ish (variabile per deployment).
- Edge Functions: 2MB body.

**Per Activity normali (2-4h), payload gzippato e' 10-50KB.** Ampiamente sotto soglia.

**Per Activity molto lunghe (8h+), o con foto inline (non il nostro caso), potrebbe avvicinarsi al limite.**

### 5.1 Decisione MVP

**Niente chunking.**

Se una Activity genera payload > 1MB (molto improbabile senza foto inline), il sync fallira' con errore server. Il failure_classifier lo classifica come permanent, l'Activity resta local-only. Eventualita' rara, gestione esplicita via UI "questa Activity e' troppo grande, contatta supporto" (caso limite, non implementato per MVP se non rileva realmente il problema).

### 5.2 Preparazione per futuro chunking

Lo schema `sync_queue` e' gia' compatibile con chunking aggiunto in futuro:
- Aggiungere colonne `chunk_index` e `total_chunks`.
- L'upload_dispatcher, su payload grossi, genera N righe sync_queue con stessi `entity_client_id` e diverso `chunk_index`.
- Server-side serve endpoint Edge Function che accetta chunk e ricompone. Richiede scrittura specifica.

Questo lavoro e' deferred a quando emerge un vero caso d'uso (post-MVP).

### 5.3 Mitigazione preventiva

Se una Activity registra punti per > 8h consecutive (ironman del motociclista), il modulo tracking applica **decimazione** sulla serie: conserva 1 punto ogni 2 secondi invece di 1 ogni secondo se durata > 6h. Serve:
- Mantenere payload sotto soglia.
- Ridurre impatto storage server.
- Tradeoff di qualita' (risoluzione tracciato dimezza dopo 6h di guida ininterrotta).

Questa logica vive nel modulo tracking, non sync. Menzionata qui per completezza.

---

## Sezione 6 -- Rehydration

Dettaglio del flusso gia' accennato in `L0_architecture.md` Sezione 7.2.

### 6.1 Ordine delle fasi

1. **Profile**: sempre prima. GET `/rest/v1/profiles?id=eq.{user_id}`. Upsert in drift.
2. **Feature flags**: letti dal profile scaricato. Applicati immediatamente (influenzano comportamento successivo).
3. **Motorcycles**: GET `/rest/v1/motorcycles?owner_id=eq.{user_id}&deleted_at=is.null`. Upsert.
4. **Safety contacts**: GET analoga. Upsert.
5. **Activities**: GET ultime 50 ordinate per `ended_at desc`. Paginazione solo se futuro.
6. **PlannedRoutes**: GET tutte proprie.
7. **PublishedRoutes proprie**: GET ultime 20 proprie.
8. **Follow relationships**: GET dove `follower_id = own OR followed_id = own`.
9. **ActivityMedia**: per ciascuna Activity scaricata, GET relative media. Files blob scaricati lazy (solo al bisogno di visualizzazione).

### 6.2 Idempotency

Ogni fase e' idempotente: se la rehydration cade a meta' e riparte, upsert non duplica.

Nessun fase dipende dalla successiva per funzionare; se Activity fail, Planned Routes puo' comunque procedere.

### 6.3 Flag di completamento

`profile.local_initial_rehydration_complete` (bool, default false, drift-only) passa a true solo al termine di TUTTE le fasi. Fino a quando e' false, la UI puo' mostrare avviso "sync iniziale in corso".

### 6.4 Rehydration parziale / refresh

In MVP non supportiamo "force refresh from server" (utente che tap per "scaricare di nuovo"). Non serve in single-device one-way push: il client e' sempre aggiornato.

In futuro, per multi-device, servira' sync incrementale (delta) che non e' rehydration completa.

---

## Sezione 7 -- Dashboard interna (debug / dev)

Schermo `ui/sync_details_screen.dart` espone all'utente (e ai dev, senza segni particolari):

- Lista item `sync_queue` corrente, con stato.
- Ultimo `last_error_code` + `last_error_message` per item `failed`.
- Conteggio per EntityKind.
- Timestamp ultimo sync riuscito.
- Toggle auto-sync on/off.
- Pulsanti per item specifici: "riprova", "elimina dalla coda" (skip questo item e marca entity come `failed` definitivo).
- Pulsante globale "riprova tutti i failed".

Questo schermo NON e' raggiungibile da nav bar principale. Accesso tramite:
- Tap su banner "N elementi da sincronizzare".
- Long-press su icona app in home (per dev).
- Pagina settings > "Stato sincronizzazione".

---

## Sezione 8 -- Sicurezza e RLS

Lato Supabase, le policy RLS (overview Sezione 6) garantiscono che l'utente possa INSERT / UPDATE solo le proprie righe. Se il client tenta (per bug) di sincronizzare qualcosa che non gli appartiene, Supabase rifiuta con 403.

**Conseguenza per sync**: un 403 e' un **permanent error** (non ha senso fare retry). Il failure_classifier lo classifica come tale. L'item va in `failed`. UI mostra "operazione non autorizzata, contatta supporto".

**Protezione lato client**: il modulo sync non fa check extra sui permessi. Si affida a RLS. Non duplichiamo logica di autorizzazione.

---

## Sezione 9 -- Invarianti di sistema del modulo

Queste invarianti devono sempre essere vere durante l'esecuzione dell'app:

1. **Ogni entity con `sync_state = pending`** ha o sta per avere una riga in `sync_queue`. Gap massimo: enqueue e' sincrono con il set di `sync_state = pending`. Se l'app crasha tra i due, al prossimo bootstrap il modulo ripristina la coerenza (scansione delle entity con `sync_state = pending` ma senza riga in queue -> ri-enqueue).
2. **Nessuna riga `sync_queue` riferisce entity che non esistono piu'** in drift. Se un entity viene hard-deleted (non succede per entity user-generated ma succede per RouteLike per esempio), il suo enqueue viene rimosso dalla coda. Maintenance routine controlla questo.
3. **Orchestrator non processa mai due item simultaneamente** (MVP). Lock interno.
4. **Un item in `in_flight`** non puo' essere modificato da altro codice -- durante upload il dispatcher ha ownership esclusiva.

---

## Sezione 10 -- Open items verso Lollo

Da aggiungere a `99_open_questions.md`:

- **A.7** -- Conferma dei numeri in Sezione 4 (retry policy). Sono una proposta ragionevole basata su benchmark industry. Lollo potrebbe voler testare diverso.
- **A.8** -- Soglia `MAX_ACTIVITIES_REHYDRATION = 50`. E' sufficiente? Utente che ha 500 activity storiche ne vede solo 50 al nuovo device; le altre restano sul server e arrivano on-demand via scroll infinito del feed. Conferma scelta prodotto.
- **A.9** -- Auto-retry orario dei `failed`: conferma intervallo 1h. Possibile alternativa: retry a 1h, 4h, 24h e poi stop. Piu' realistico se errore e' di sistema.
- **A.10** -- Se utente disabilita auto-sync, dopo N giorni offline l'app mostra warning "stai accumulando molti dati non sincronizzati, 50+ elementi in coda, rischio perdita se reset app"? Proposta si', threshold = 30 elementi.

---

**Fine 05_sync/queue_design.md**
