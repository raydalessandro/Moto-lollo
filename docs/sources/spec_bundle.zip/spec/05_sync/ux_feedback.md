# 05 / Sync -- UX Feedback

**Scopo:** come l'app comunica all'utente lo stato della sincronizzazione. Matrice stato tecnico x contesto UI x indicatore visuale + micro-copy italiano.

**Perche' e' importante:** un sync silenzioso e' confortante se tutto va bene. Diventa angoscioso se qualcosa fallisce senza che l'utente lo sappia. Al contrario, notifiche troppo aggressive ("sto sincronizzando, sto sincronizzando") generano rumore e non-fidelizzazione. Questo documento definisce il **livello di visibilita' appropriato** per ciascun stato.

**Principio guida:** l'utente deve sempre poter rispondere a 3 domande:

1. "Il mio giro e' al sicuro?" (implicito: drift locale sempre salva)
2. "Gli altri lo possono vedere?" (esplicito: sync state visibile)
3. "C'e' qualcosa di cui devo preoccuparmi?" (visibile solo se serve)

**Riferimenti:** `L0_architecture.md`, `queue_design.md`, `edge_cases.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Matrice stato sync x UI

Per ciascuna entita' sincronizzabile (Activity, Motorcycle, PublishedRoute, Comment, Like, Follow, PlannedRoute, SafetyEvent, SafetyContact), il `sync_state` locale ha 4 valori: `pending`, `syncing`, `synced`, `failed`.

La UI mostra indicatori diversi in base a **contesto** e **gravita'**.

### 1.1 Livelli di visibilita'

| Livello | Nome | Quando |
|---|---|---|
| L0 | Invisibile | Sincronizzazione normale. Utente non e' disturbato. |
| L1 | Badge discreto | Stato visibile solo se l'utente guarda la singola entita'. |
| L2 | Indicatore persistente | Badge visibile nella card/feed, non intrusivo. |
| L3 | Banner | Elemento dedicato nella UI globale (dashboard o app bar). |
| L4 | Dialog / notifica | Richiede attenzione attiva utente. |

### 1.2 Matrice principale

| Entita' | Stato | Livello | Dove compare |
|---|---|---|---|
| Activity | synced | L0 | - |
| Activity | pending / syncing | L1 | Icona cloud con freccia nel detail screen. Nel feed personale: nessun indicatore (implicito che sta sincronizzando). |
| Activity | failed | L2 | Nel feed: badge "non sincronizzata" sulla card. Nel detail: banner in alto con pulsante "Riprova". |
| ActivityMedia | synced | L0 | - |
| ActivityMedia | pending / syncing | L1 | Spinner su thumbnail in detail. Nel feed: foto mostrata come caricata (anticipazione). |
| ActivityMedia | failed | L1 | Icona "errore" sulla singola foto, tap per riprovare. Activity parent NON impatta. (coerente con D.43) |
| Motorcycle | synced | L0 | - |
| Motorcycle | pending / syncing | L0 | - (tipicamente < 5s, non vale indicatore) |
| Motorcycle | failed | L2 | Garage screen: card con bordo ambra, tooltip "modifica non sincronizzata". |
| PublishedRoute | synced | L0 | - |
| PublishedRoute | pending / syncing | L1 | Detail: "pubblicazione in corso...". Altri non la vedono finche' sync OK. |
| PublishedRoute | failed | L3 | Banner in cima al feed "Hai N contenuti non pubblicati. Riprova." |
| Comment | synced | L0 | - |
| Comment | pending / syncing | L1 | Commento appare con opacity 0.6 + piccolo spinner inline. |
| Comment | failed | L1 | Commento con bordo rosso, tap per riprovare. Non inviato ma preservato localmente. |
| Like | synced | L0 | - |
| Like | pending / syncing | L0 | - (UX ottimistica: cuore subito pieno) |
| Like | failed | L1 | Cuore torna vuoto (rollback), snackbar breve "Like non inviato" + pulsante "Riprova". |
| Follow | synced | L0 | - |
| Follow | pending / syncing | L0 | - (UX ottimistica: bottone "Seguendo" subito) |
| Follow | failed | L1 | Bottone torna a "Segui", snackbar "Non riuscito". |
| PlannedRoute | synced | L0 | - |
| PlannedRoute | pending / syncing | L1 | Icona discreta su lista. |
| PlannedRoute | failed | L2 | Card con badge "non sincronizzato". |
| SafetyContact | synced | L0 | - |
| SafetyContact | pending / syncing | L0 | - |
| SafetyContact | failed | L4 | **Dialog modale**: "Contatto di sicurezza non salvato sul server. In caso di emergenza potrebbe non essere disponibile. Riprova?" |
| SafetyEvent | synced | L0 | - (gia' gestito nella UI SOS post-trigger) |
| SafetyEvent | pending / syncing | gia' gestito in 09_safety/edge_cases | Vedi Sezione 2 di quel doc. |
| SafetyEvent | failed | L3 | Banner persistente: "Evento SOS non sincronizzato al server. Dati disponibili localmente." |

### 1.3 Stati aggregati globali

Indicatori nella dashboard/UI globale che sommano piu' entita'.

| Condizione | Livello | Display |
|---|---|---|
| Coda vuota, tutto synced | L0 | - |
| Coda `pending/syncing` > 0 ma < 30 e nessun `failed` | L0 | - (normale, zero rumore) |
| Coda `pending/syncing` >= 30 | L3 | Banner dashboard: "Hai N contenuti in attesa di sincronizzazione. Verifica connessione." |
| Almeno 1 `failed` | L2 | Badge "!" sull'icona sync nel drawer/settings. |
| Almeno 1 `failed` per SafetyContact | L4 | Dialog descritto sopra. |
| Auto-sync disabilitato | L3 | Banner: "Auto-sync disattivato. Sincronizza manualmente per caricare i tuoi dati." |
| Offline > 24h e coda non vuota | L3 | Banner: "Sei offline da oltre 24h. N contenuti attendono connessione." |

---

## Sezione 2 -- Micro-copy italiano

**Principi stilistici:**

- **Tono calmo**, mai allarmistico salvo quando genuinamente necessario (safety).
- **Attivo, non passivo**: "Riprova" meglio di "Il tentativo puo' essere ripetuto".
- **Evita gergo tecnico**: "non sincronizzato" meglio di "stato failed"; "caricamento" meglio di "upload"; "attende connessione" meglio di "pending network".
- **Breve**: label max 6 parole, toast max 15 parole, banner max 25 parole.

### 2.1 Label / chip / badge

| Situazione | Copy |
|---|---|
| Activity sta caricando | "Caricamento in corso" |
| Activity non caricata | "Non caricata" |
| Foto in caricamento | "Caricamento foto..." |
| Foto non caricata | "Foto non caricata" |
| Route in pubblicazione | "Pubblicazione in corso" |
| Route non pubblicata | "Non pubblicata" |
| Modifiche non salvate online | "Modifiche locali" |
| Offline | "Sei offline" |

### 2.2 Banner

| Situazione | Copy |
|---|---|
| Coda > 30 items | "Hai {N} contenuti in attesa. Verifica la connessione o sincronizza manualmente." |
| Auto-sync off con coda | "Auto-sync disattivato. {N} contenuti non verranno caricati finche' non sincronizzi manualmente." |
| Offline > 24h | "Sei offline da oltre un giorno. {N} contenuti attendono connessione." |
| Route pubblicazione fallita | "Pubblicazione non riuscita per {N} percorsi. Tocca per riprovare." |
| SafetyEvent fallito | "Un evento di sicurezza non e' stato caricato. I dati sono salvati sul dispositivo." |

### 2.3 Snackbar / toast

| Situazione | Copy |
|---|---|
| Like fallito | "Like non inviato. Tocca per riprovare." |
| Follow fallito | "Non riesco a seguire ora. Tocca per riprovare." |
| Commento fallito | "Commento non inviato. Verifica la connessione." |
| Sync manuale avviato | "Sincronizzazione in corso..." |
| Sync manuale completato | "Tutto sincronizzato." |
| Sync manuale con alcuni fail | "Sincronizzati {N} di {M}. Alcuni elementi attendono." |

### 2.4 Dialog

| Situazione | Titolo | Corpo |
|---|---|---|
| SafetyContact non sincronizzato | "Contatto non salvato online" | "Il contatto e' salvato sul tuo dispositivo ma non sul server. In caso di emergenza, se cambi telefono, potresti non averlo. Riprova?" |
| Eliminazione account con coda | "Hai contenuti non sincronizzati" | "{N} elementi non sono stati ancora caricati sul server. Eliminando l'account andranno persi. Continuare?" |
| Logout con coda grossa | "Hai molti contenuti da sincronizzare" | "Prima del logout e' consigliato sincronizzare {N} elementi. Continuare comunque?" |

### 2.5 Icone e simboli

| Stato | Icona suggerita |
|---|---|
| synced | nessuna |
| pending / syncing | `cloud_upload` con animazione soft |
| failed | `cloud_off` o `error_outline` ambra |
| offline globale | `wifi_off` |
| auto-sync off | `sync_disabled` |

---

## Sezione 3 -- Regole di quiet down (evitare rumore)

Anche con la matrice sopra, rischio di over-notification. Regole aggiuntive:

### 3.1 Dedup temporale

Uno stesso evento di errore non genera snackbar ripetute. `SnackbarService` debounce: se lo stesso `key + message` arriva entro 10s, il secondo viene silenziato.

### 3.2 Aggregazione

Se 3 foto di un'Activity falliscono, mostrare **un unico** badge "3 foto non caricate" invece di 3 errori separati.

### 3.3 Quiet hours durante tracking attivo

Durante `recording_active`, sospendiamo banner L3 non-critici (es. "coda > 30 items"). L'utente sta guidando, non deve essere distratto. Eccezioni: banner SafetyContact failed e SafetyEvent failed restano (safety prevale).

### 3.4 Initial grace period

Al bootstrap dell'app, i primi 5 secondi di `pending` non mostrano alcun indicatore. Se sync parte veloce e completa, utente non vede niente. Se ancora pending dopo 5s: L1 attivo.

---

## Sezione 4 -- Widget riusabili

La matrice e il micro-copy sono implementati attraverso widget esistenti in `11_ui_components/`:

- `SyncBadge`: componente riusabile con stato enum -> icon + color + tooltip.
- `SyncBanner`: banner full-width dismissible/persistente con CTA.
- `SyncSnackbar`: snackbar con action button "Riprova".
- `SyncCloudIcon`: icona animata cloud con stati.

**Da aggiungere al widget_catalog.md**: specificare le shape di questi 4 widget. Intervento rinviato.

---

## Sezione 5 -- Percorso dell'utente in caso di fallimento

Scenari end-to-end: cosa succede dal tap al recupero.

### 5.1 Utente fa un giro, salva Activity offline

1. `stopRecording()` completa. Activity in drift `pending`.
2. Feed personale: Activity visibile subito (feed legge da drift, non dal server).
3. Nessun banner (coda < 30).
4. Utente torna online: sync parte, Activity diventa `synced`. Zero UI change percepibile.
5. Risultato: utente non sa che ha sincronizzato. **E' corretto**: il punto 2 della sua domanda implicita ("il mio giro e' al sicuro?") era gia' OK dal momento del save.

### 5.2 Utente pubblica PublishedRoute, offline persistente

1. `publishFromActivity()` completa. PublishedRoute in drift `pending`.
2. UI di conferma: "Pubblicazione in attesa di connessione".
3. Feed personale: Route visibile come "non pubblicata" (L1 badge).
4. Dopo 1 giorno offline: banner L3 "1 contenuto attende sincronizzazione".
5. Torna online: pubblicazione parte. Badge sparisce, route diventa pubblicata.

### 5.3 Utente crea SafetyContact, fallimento server lungo

1. Contact salvato localmente. UI "Contatto salvato".
2. Sync fallisce 5 volte (es. bug temporaneo Supabase).
3. Stato `failed`. **Dialog L4** triggerato:
   - "Contatto non salvato online. In caso di emergenza da altro device non sara' disponibile. Riprova ora?".
4. Utente sceglie: riprova / lascia / elimina.
5. Se lascia: banner persistente finche' non risolto.

### 5.4 Utente like optimistic rollback

1. Tap su cuore. UI subito mostra cuore pieno, counter +1.
2. Sync fallisce (es. route nel frattempo unpublished).
3. Cuore torna vuoto, counter -1, snackbar: "Like non inviato. Tocca per riprovare."
4. Durata rollback: animato 300ms per non essere "scioccante".

---

## Sezione 6 -- Accessibility

- Tutti gli indicatori sync hanno `Semantics` label esplicita: "Caricamento in corso", "Non sincronizzato", "Errore di caricamento".
- Screen reader annuncia cambio di stato sync solo se livello >= L3 (evita logorrea).
- Colori (ambra, rosso) mai usati da soli per stato: sempre accompagnati da icona + label.

---

## Sezione 7 -- Checklist QA

- [ ] Activity caricata offline, feed mostra senza badge.
- [ ] Activity caricata offline, detail screen mostra L1 badge.
- [ ] Coda raggiunge 30 items, banner L3 appare.
- [ ] Coda scende sotto 30, banner L3 scompare.
- [ ] Auto-sync off con coda, banner L3 visible.
- [ ] SafetyContact fallito, dialog L4 appare.
- [ ] Like fallito, rollback animato, snackbar.
- [ ] Durante tracking attivo, banner L3 di sync ordinario e' sospeso.
- [ ] Banner safety resta anche durante tracking.
- [ ] Screen reader annuncia stato >= L3.
- [ ] Micro-copy italiano rivisto con utente nativo.

---

## Sezione 8 -- Open items specifici

- **B.7 nuovo** (se vuoi portarlo in open_questions): validazione micro-copy con motociclisti reali in beta.
- Proposto: aggiungere al `11_ui_components/widget_catalog.md` le shape di `SyncBadge`, `SyncBanner`, `SyncSnackbar`, `SyncCloudIcon`.

---

**Fine 05_sync/ux_feedback.md**
