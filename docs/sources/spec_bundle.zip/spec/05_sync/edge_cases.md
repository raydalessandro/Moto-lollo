# 05 / Sync -- Edge Cases

**Scopo:** catalogo dei casi limite e scenari di errore del modulo sync, con comportamento atteso per ciascuno. Include la classificazione completa errori retriable vs permanent.

**Riferimenti:**

- Architettura generale: `L0_architecture.md`.
- Coda e retry policy: `queue_design.md`.
- Idempotency: `idempotency.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Tavola di classificazione errori

Quando un tentativo di upload fallisce, il `FailureClassifier` decide: **retriable** (entra in backoff) o **permanent** (va subito in `failed`).

### 1.1 HTTP status codes

| Codice | Classificazione | Nota |
|---|---|---|
| 200 / 201 / 204 | Success | - |
| 400 Bad Request | **Permanent** | Payload malformato. Retry inutile. |
| 401 Unauthorized | **Auth refresh** | Non e' retriable ne' permanent: triggera refresh JWT, retry UNA volta. Se ancora 401 -> `Auth expired`, stop sync + notifica login. |
| 403 Forbidden | **Permanent** | RLS rifiuta. Bug client. Non ritentare. |
| 404 Not Found | **Permanent** | Entity non trovata server-side durante UPDATE. Dovrebbe essere impossibile con idempotency corretta; segnala bug. |
| 409 Conflict | **Success logico** | Duplicate key su INSERT: e' success dall'idempotency (vedi `idempotency.md` Sezione 2). Fetch della riga esistente, passa a synced. |
| 410 Gone | **Permanent** | Entity gia' hard-deleted. Rimuoviamo da coda. |
| 413 Payload Too Large | **Permanent** | Payload > limite Supabase. Segnalare come "activity troppo grande" (caso rarissimo post-decimazione D.24). Richiede intervento manuale. |
| 422 Unprocessable | **Permanent** | Shape JSON invalido o violazione constraint. Bug. |
| 429 Too Many Requests | **Retriable** | Rate limit. Honor `Retry-After` header se presente; altrimenti backoff standard. |
| 499 Client Closed | **Retriable** | Client aborted (utente chiuso app). Riaccodiamo per prossimo ciclo. |
| 500 Internal Server Error | **Retriable** | Temporaneo. |
| 502 Bad Gateway | **Retriable** | Infra temporanea. |
| 503 Service Unavailable | **Retriable** | Supabase in manutenzione o overload. |
| 504 Gateway Timeout | **Retriable** | Timeout infra. |

### 1.2 Errori di rete (pre-HTTP)

| Tipo | Classificazione |
|---|---|
| `SocketException` | **Retriable** |
| `TimeoutException` (local) | **Retriable** |
| `HandshakeException` (TLS) | **Retriable** |
| DNS failure | **Retriable** |
| No connectivity | **Retriable** (in realta' orchestrator non tenta: aspetta `ConnectivityChangedEvent`) |

### 1.3 PostgrestException Supabase-specifiche

| Code | Classificazione | Esempio |
|---|---|---|
| `23505` (unique_violation) | **Success logico** | Duplicate client_id, equivale a 409 |
| `23503` (foreign_key_violation) | **Dependency block** | Dipendenza non ancora synced. Marca item `blocked_by_dependency`. |
| `23514` (check_violation) | **Permanent** | Dato locale non rispetta constraint server. Bug. |
| `PGRST116` (no rows returned) | **Contextual** | Su UPSERT che si aspettava .single(): vedi `idempotency.md` 2.1 per gestione. |
| `42501` (insufficient_privilege) | Equivale a 403 | **Permanent** |

---

## Sezione 2 -- Scenari di rete

### 2.1 Timeout su upload Activity grande

**Scenario:** Activity con `track_points_data` 800KB. Rete lenta. Upload > 30s (timeout).

**Default:** `supabase_flutter` lancia `TimeoutException`. FailureClassifier: **retriable**.

**Atteso:**
- Item torna `awaiting_retry` con backoff.
- Al retry successivo: se rete migliorata, upload succede. L'idempotency (`ON CONFLICT`) gestisce il caso "il primo upload in realta' era arrivato ma il client non l'ha saputo".

**Tuning timeout:** `queue_design.md` Sezione 9.2 dichiara 30s. Per payload molto grandi potrebbe servire piu'. Monitoring necessario post-rilascio.

### 2.2 Rete cade durante upload

**Scenario:** upload in corso, utente entra in galleria, connessione cade.

**Default:** Http client lancia `SocketException`. Retriable.

**Atteso:** retry con backoff. Orchestrator si puo' mettere in attesa di `ConnectivityChangedEvent` per svegliarsi subito al ritorno online (senza aspettare il prossimo `next_retry_at` se questo e' piu' lontano).

**Implementazione:**

```dart
connectivityWatcher.onConnected.listen((_) {
  orchestrator.wakeUpIfSleeping();
});
```

### 2.3 Rete lenta (2G, edge)

**Scenario:** utente in zona coperta solo da 2G. Upload ci mette 5 minuti.

**Default:** timeout a 30s -> fail. Retry, altri 30s, fail. In 5 retry non arriva mai a termine.

**Atteso:**
- Per ora: fail dopo 5 retry. Utente notificato.
- Mitigazione futura: timeout dinamico basato su tipo connessione (`connectivity_plus` distingue `mobile_slow`/`mobile`/`wifi`). Per `mobile_slow` -> 60s. Non MVP.

### 2.4 Utente mette in "modalita' aereo" mid-upload

**Scenario:** upload in corso, utente attiva modalita' aereo.

**Default:** SocketException immediata. Retriable.

**Atteso:**
- `connectivityWatcher` rileva `ConnectivityResult.none`.
- Orchestrator pausa. Item torna in coda.
- L'orchestrator NON tenta nuovi upload mentre offline (risparmia batteria e log).
- Al ritorno online: `ConnectivityChangedEvent(online: true)` -> resume.

### 2.5 DNS failure persistente

**Scenario:** DNS del provider mobile ha problemi, risolve lookup Supabase in lookup fallito.

**Default:** `SocketException: Failed host lookup`. Retriable.

**Atteso:**
- Retry standard.
- Se fallimenti persistenti > 5: passa a `failed`.
- Auto-retry orario riprova dopo 1h (vedi A.8). Quando DNS si riprende, sync parte.

---

## Sezione 3 -- Errori di autenticazione

### 3.1 JWT scaduto

**Scenario:** la sessione Supabase e' scaduta (default token vita 1h). Client prova upload, riceve 401.

**Default supabase_flutter:** auto-refresh del JWT via `refresh_token`. Avviene trasparente.

**Atteso:** caso gestito dalla libreria. Non emergiamo esplicitamente.

**Edge:** se anche il `refresh_token` e' scaduto (raro, vita lunga), client riceve 401 anche dopo refresh. In questo caso:

- Orchestrator ferma sync.
- Emette evento `AuthExpiredEvent` (consumato da modulo auth).
- Modulo auth mostra dialog "Sessione scaduta, rifai login".
- Fino a nuovo login: coda congelata, nessun retry.

### 3.2 Utente cambiato mid-sync

**Scenario:** utente A logout, utente B login. Sync orchestrator era in corso con A.

**Default:** eventi `UserLoggedOutEvent` + `UserLoggedInEvent` arrivano al modulo sync.

**Atteso:**
- `UserLoggedOutEvent`: orchestrator stoppa. Upload in-flight: **aborted**. Item torna `queued`.
- `UserLoggedInEvent` con `user_id != previous`: il nuovo utente B ha la sua `sync_queue` (filtrata implicitamente da `owner_id` nelle letture del drift? Non tecnicamente -- `sync_queue` non ha `owner_id`).

**Problema identificato:** la tabella `sync_queue_local` non filtra per utente. Se A aveva item pending e poi B fa login, lo sync di B potrebbe processare item di A.

**Soluzione:**

- Aggiungere colonna `owner_id` a `sync_queue_local` (popolata al momento dell'enqueue).
- Dequeue query: `WHERE owner_id = currentUserId`.
- Al logout: item restano, ma il worker del nuovo utente li ignora.
- Al ri-login dello stesso utente: item ripresi.

**Impatto:** aggiornare `03_local_db.md` Sezione 5.3 per aggiungere colonna `owner_id` a `SyncQueueLocal`. **Modifica retro-attiva alla spec.**

### 3.3 Account cancellato server-side

**Scenario:** admin ha cancellato (hard) l'account utente. Ogni upload fallisce con 404 o 403.

**Atteso:**
- Tutti gli item dell'utente vanno `failed`.
- UI mostra messaggio "Account non trovato, contatta supporto".
- Modulo auth fa logout forzato al prossimo tentativo di op.

---

## Sezione 4 -- Race conditions e dipendenze

### 4.1 Dependency non risolvibile

**Scenario:** utente crea Activity con motorcycle_id X. Prima che Activity sia synced, cancella motorcycle X hard (non soft).

**Default:**
- Activity in coda con `dependency_client_ids = [X]`.
- Motorcycle X non esiste piu' neanche nel drift.
- Scheduler verifica dependencies: X non esiste -> non e' ne' `synced` ne' `pending`, e' `missing`.

**Atteso:**
- Policy: dependency `missing` -> trattare come "non richiesta". Il server rispondera' con 23503 (FK violation) se proprio c'e' problema.
- Alternativa: marcare Activity come `failed` proattivamente.
- Scelta MVP: **lasciamo provare l'upload**. Il server rispondera':
  - Se `motorcycle_id` punta a record Postgres inesistente: 23503 -> sync mette item in `blocked_by_dependency`. Ma dependency e' ormai "persa", non si sbloccera' mai. Polling infinito.
  - Migliore: al rilevamento `missing` dependency locale, inviare l'Activity con `motorcycle_id = null` (utente aveva scelto una moto, l'ha cancellata, l'Activity resta senza moto). Documentabile come "edge accettabile".

**Scelta implementativa:** al dequeue, se dependency `missing`, cambia campo del payload a `null` per quella FK prima di inviare.

### 4.2 Dependency cancellata server-side durante sync

**Scenario:** Activity gia' sul server referenzia motorcycle X. Un'altra sessione dello stesso utente (multi-device futuro) cancella X. Nel nostro device attuale abbiamo X pending.

**Non applicabile in MVP single-device.** Ignoriamo per ora.

### 4.3 Enqueue duplicato accidentale

**Scenario:** bug fa enqueue 2 volte per la stessa entity.

**Atteso:**
- Protezione in `queue_scheduler.enqueueWithAutoDeps`: check `SELECT * FROM sync_queue WHERE entity_kind = ? AND entity_client_id = ? AND state IN ('queued', 'in_flight')`. Se esiste, skip enqueue.
- Regola di coalescence (vedi `queue_design.md` Sezione 3.4) completa il quadro.

### 4.4 Server accetta INSERT ma ritorna errore

**Scenario:** rete flaky. Il request arriva al server, INSERT eseguito, ma response al client e' corrotto/droppato. Client crede fallito.

**Atteso:**
- Retry. Nuovo tentativo fa upsert. `ON CONFLICT DO NOTHING` gestisce. Fetch dell'esistente. Tutto converge.

**Garantito da `idempotency.md` Sezione 2.**

---

## Sezione 5 -- Drift / storage

### 5.1 Drift failure su update sync_state

**Scenario:** upload riuscito sul server. Client tenta update `activities.sync_state = synced`. Drift fallisce (storage pieno o altro).

**Default:** il server ha la riga. Il client ha ancora `sync_state = syncing` in drift.

**Atteso:**
- Al prossimo giro orchestrator: legge `activities WHERE sync_state = pending OR sync_state = syncing AND age > X`.
- Includiamo `syncing` da piu' di N minuti (es. 10 min) come "stuck", riproviamo.
- Retry upload: server idempotent -> no duplicati, ritorna riga esistente. Update drift riesce questa volta (storage libero).

**Implementazione:** dequeue query include `syncing` stuck come candidate per retry.

### 5.2 Drift fallisce durante maintenance/purge

**Scenario:** routine di purge dei buffer oltre 7 giorni fallisce.

**Atteso:**
- Log in error_logs.
- Retry al prossimo bootstrap. Non critico.

---

## Sezione 6 -- Casi di degradazione UX

### 6.1 Coda molto grande (utente offline per 2 mesi)

**Scenario:** utente ha usato l'app offline, 200 activity in `sync_queue_local`, torna online.

**Default:** orchestrator processa in sequenza, 1 per volta, con backoff su errori.

**Atteso:**
- UI mostra progress "Sincronizzazione in corso, X di Y".
- Se l'utente chiude l'app: prosegue al prossimo avvio.
- Stima tempo: con Activity 20 KB media e connessione 1 MB/s, 200 activity x 1s = 3-4 minuti. Accettabile.

**Mitigazione futura:** concorrenza N simultanei (vedi L0 Sezione 11). Non MVP.

### 6.2 Retry storm dopo outage Supabase

**Scenario:** Supabase down per 30 minuti. Al ritorno, migliaia di client tutti riprovano contemporaneamente.

**Mitigazione:** jitter 0.8-1.2 sui backoff (queue_design.md Sezione 4.1) spalma i tentativi.

**Accoppiato a:** se Supabase torna col limit rate attivo, clients ricevono 429. Honor `Retry-After` header se presente, altrimenti backoff.

### 6.3 Notifiche UI ripetitive

**Scenario:** lo stesso item fallisce 5 volte, UI potrebbe notificare 5 volte "N attivita' non sincronizzate".

**Atteso:**
- Notifica emessa **una sola volta** al passaggio da `<failed_count == 0` a `failed_count > 0`.
- Successive modifiche di `failed_count` aggiornano solo il banner, non generano toast.

**Implementazione:** debounce/dedup nello stream `SyncApi.overview`.

---

## Sezione 7 -- Logout e state residuo

### 7.1 Logout con coda non vuota

**Scenario:** utente ha 10 item pending, fa logout.

**Atteso:**
- Orchestrator si ferma.
- Item restano in `sync_queue_local`.
- Se l'utente fa ri-login con stesso account: coda ripresa.
- Se fa login con account diverso: vedi Sezione 3.2 (filter by owner_id sulla coda).

### 7.2 Uninstall app

**Scenario:** utente disinstalla app con coda di 50 item locali non sincronizzati.

**Atteso:** i dati sono persi. Server non li avra' mai.

**Protezione UX:** al logout, se coda > N item, chiedere conferma "Hai X elementi non sincronizzati. Continuare?". Analogo warning a A.9.

---

## Sezione 8 -- Checklist QA sync

- [ ] Upload nuova Activity con timeout simulato -> retry OK, un solo record server.
- [ ] Upload con fail 5 volte -> item va in failed -> notifica UI.
- [ ] Retry manuale di un failed -> re-enqueue e successo (se errore risolto).
- [ ] Modifica titolo Activity non ancora sincronizzata -> coalescence.
- [ ] Cancellazione Activity non ancora sincronizzata -> entrambi rimossi.
- [ ] Upload con 401 JWT scaduto -> auto-refresh -> successo.
- [ ] Upload con 401 refresh token scaduto -> logout richiesto, coda congelata.
- [ ] Upload con 403 -> permanent, failed immediato.
- [ ] Upload con 409 duplicate -> fetch esistente, sync OK.
- [ ] Offline 24h, poi online -> orchestrator riparte, processa coda.
- [ ] Logout e login stesso utente -> coda ripresa.
- [ ] Logout e login altro utente -> coda NON processa item del precedente.
- [ ] Server down 30min -> retry con backoff, recovery al ritorno.
- [ ] Upload Activity grande (300KB) su 3G lento -> nessun timeout inatteso.
- [ ] Upload Activity con motorcycle_id cancellato locale -> invia con null.
- [ ] Rehydration interrotta a meta' -> ripresa al prossimo bootstrap.

---

## Sezione 9 -- Open items specifici sync

Nessuno nuovo emerge da questo documento. Tutti gia' tracciati:

- A.1 retry policy numerica.
- A.7 MAX_ACTIVITIES_REHYDRATION.
- A.8 intervallo auto-retry orario per failed.
- A.9 warning offline con coda accumulata.
- A.17 compute isolate per decode JSON grossi (relaterio a performance read).
- A.18 media failure indipendente da Activity.

**Una modifica retroattiva necessaria** (non e' open question, e' decisione da applicare):

- `sync_queue_local` deve avere colonna `owner_id` per filtrare dequeue per utente corrente. Aggiornamento in `03_local_db.md` Sezione 5.3.

---

**Fine 05_sync/edge_cases.md**
