# 05 / Sync -- Idempotency

**Scopo:** pattern di idempotency end-to-end tra client e Supabase. Come garantiamo che un'operazione di sync, anche se ripetuta N volte (retry, race condition, recovery), produca sempre lo stesso effetto sul server.

**Riferimenti:**

- Architettura generale: `L0_architecture.md`.
- Schema coda: `queue_design.md`.
- Overview principio: `00_overview.md` Sezione 5.12.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Principio generale

**Idempotency significa:** ripetere N volte la stessa operazione di sync produce lo stesso stato finale del server di una singola esecuzione. Ne' duplicati, ne' side effect inattesi.

**Perche' serve:** la rete e' inaffidabile. Retry sono regola, non eccezione. Senza idempotency, anche una sola perdita del pacchetto "OK" del server genera duplicati.

**Strumento primario:** `client_id` UUID v4 generato client-side al momento di creazione dell'entity. Chiave di business univoca condivisa tra client e server. Vedi `00_overview.md` Sezione 5.12.

**Strumento secondario:** HTTP verbi appropriati + clausole SQL `ON CONFLICT` per ciascun tipo di operazione.

---

## Sezione 2 -- INSERT idempotente

### 2.1 Pattern client-server

**Client side:**

```dart
final payload = {
  'client_id': activity.clientId,          // UUID v4 generato client
  'owner_id': activity.ownerId,
  'motorcycle_id': activity.motorcycleId,
  ...tutti gli altri campi...
};

await supabase
  .from('activities')
  .upsert(payload, onConflict: 'client_id', ignoreDuplicates: false)
  .select()
  .single();
```

**Server side equivalente SQL:**

```sql
INSERT INTO activities (client_id, owner_id, motorcycle_id, ...)
VALUES (..., ..., ...)
ON CONFLICT (client_id) DO NOTHING
RETURNING *;
```

**Come si comporta:**

- Prima volta: inserisce riga, ritorna oggetto completo.
- Seconda volta (retry dopo timeout su OK perso): `ON CONFLICT DO NOTHING` -> nessun duplicato. `RETURNING *` ritorna **0 righe**, pero' PostgREST su 0 righe + `.single()` solleva un errore "PGRST116".
- Soluzione: **alternativa a `upsert` e' `.insert()` con check manuale di errore 409/duplicate key**, oppure l'uso di `ignoreDuplicates: false` + query di fallback per leggere la riga esistente.

### 2.2 Pattern pragmatico scelto

Il client implementa questo flow:

```dart
Future<Result<Map<String,dynamic>, TransportError>> uploadNew(entity) async {
  try {
    final row = await supabase
      .from(tableName)
      .upsert(payload, onConflict: 'client_id')
      .select()
      .single();
    return Ok(row);
  } on PostgrestException catch (e) {
    if (e.code == '23505' || e.code == 'PGRST116') {
      // Duplicate key o nessuna riga ritornata (= gia' esistente).
      // Facciamo SELECT per recuperare lo stato server.
      final existing = await supabase
        .from(tableName)
        .select()
        .eq('client_id', payload['client_id'])
        .single();
      return Ok(existing);
    }
    return Err(TransportError.fromPostgrestException(e));
  }
}
```

Il codice e' scritto una volta in `upload_dispatcher.dart` e funziona per tutte le entity.

**Effetto:** dal punto di vista del chiamante, l'operazione "upload new entity" e' sempre "successful or failed transport". Non esiste "fail perche' duplicato" -- il duplicato e' un successo logico.

### 2.3 Lato server: UNIQUE constraint come rete di sicurezza

Ogni tabella user-generated ha `UNIQUE (client_id)` a livello Postgres. Se per bug il client tenta di inserire con un client_id gia' usato da un'altra entity (mai dovrebbe succedere), il DB rifiuta. E' difesa in profondita', non logica primaria.

---

## Sezione 3 -- UPDATE idempotente

### 3.1 Considerazione

UPDATE e' **naturalmente idempotente** se i campi sono overwrite totale. PUT HTTP vs PATCH:

- `UPSERT` completo = PUT: "lo stato dell'entity deve diventare esattamente questo". Ripetere e' safe.
- `PATCH` parziale = "applica questo delta": ripetere applica il delta N volte, ma se il delta e' un SET e non un INC, e' comunque safe.

Supabase client espone `.update()` che e' PATCH: solo i campi passati sono modificati. Gli altri restano. Safe per retry.

### 3.2 Pattern client

```dart
await supabase
  .from('activities')
  .update({
    'title': newTitle,
    'notes': newNotes,
    'tags': newTags,
    'updated_at': newUpdatedAt.toIso8601String(),
    'version': activity.version + 1,
  })
  .eq('client_id', activity.clientId);
```

**Nota sul `version`:** il campo `version` e' incrementato lato client al momento della modifica, e inviato al server. Serve per future logiche di conflict detection (multi-device, post-MVP). In MVP e' registrato ma non usato per logica.

**Pattern difensivo MVP:** se il server ha un `version` maggiore di `version + 1` ricevuto, il client dovrebbe sapere che qualcuno ha modificato in parallelo. **Attualmente single-device, impossibile.** Ma il campo e' pronto.

### 3.3 Update su entity che non esistono ancora sul server

**Scenario:** l'utente modifica il titolo di una Activity prima che il primo INSERT sia arrivato al server.

**Default naive:** il sync worker spedisce `UPDATE WHERE client_id = X`. Server non trova nulla. PostgREST ritorna 0 righe modificate -- non e' errore.

**Pericolo:** il client crede di aver sincronizzato la modifica, ma in realta' il server non ha la riga. La modifica e' persa dal punto di vista server.

**Soluzione: coalescence sul client side** (documentata in `queue_design.md` Sezione 3.4):

- Se in `sync_queue` esiste gia' una `INSERT queued` per la stessa entity: l'update non produce nuova riga in coda. L'INSERT carichera' lo stato aggiornato (leggi fresco da drift).
- Se la `INSERT` e' in `in_flight`: l'update viene accodato come `UPDATE` separato, eseguito dopo completamento INSERT.
- Se la INSERT e' gia' `synced`: l'UPDATE procede normalmente.

Questo pattern evita il caso "UPDATE perso perche' INSERT non ancora arrivato".

---

## Sezione 4 -- DELETE idempotente

### 4.1 Soft delete e' naturalmente idempotente

Per entity soft-deleted (Activity, Motorcycle, PublishedRoute, PlannedRoute, Profile): il delete e' UPDATE di `deleted_at`. Ripetere un UPDATE che setta `deleted_at = now()` e' safe: il campo resta valorizzato.

Pattern:

```dart
await supabase
  .from('activities')
  .update({'deleted_at': DateTime.now().toUtc().toIso8601String()})
  .eq('client_id', clientId);
```

Se ripetuto: `deleted_at` viene sovrascritto con nuovo timestamp. In linea di principio il secondo timestamp sposta "quando e' stata cancellata". In pratica:

- Se vuoi precisione: il client passa il proprio `deleted_at` locale (momento del tap utente), non `now()` server. Il server accetta. Retry riscrive lo stesso valore (poiche' il client non lo rigenera, usa quello salvato nella sync_queue entity snapshot).

**Decisione pratica:** il client al tap utente setta `local.deleted_at = DateTime.now().toUtc()`, scrive in drift. Il sync worker passa quel valore, non `now()` server. Ripetizioni non spostano il timestamp. Idempotente perfetto.

### 4.2 Hard delete

Per entity hard-delete (RouteLike, FollowRelationship): operazione DELETE SQL.

Pattern:

```dart
await supabase
  .from('route_likes')
  .delete()
  .eq('client_id', clientId);
```

**Idempotency:** se il record non esiste (gia' cancellato), DELETE ritorna 0 righe modificate -- non errore. Ripetere e' safe.

### 4.3 Delete di entity mai sincronizzate

**Scenario:** utente crea Activity, poi la cancella immediatamente prima che l'INSERT sia arrivato al server.

**Gestito da coalescence** (`queue_design.md` Sezione 3.4): INSERT queued + DELETE -> entrambi rimossi dalla coda. L'entity non arriva mai sul server. Zero chiamate sprecate.

**Caso INSERT in_flight + DELETE:** la DELETE viene accodata. Dopo completamento INSERT, DELETE processa normalmente (soft delete dell'entity appena creata).

---

## Sezione 5 -- Upload media (bucket Storage)

### 5.1 Supabase Storage e idempotency

Storage non e' Postgres. Non ha `ON CONFLICT`. API: `storage.from(bucket).upload(path, bytes)`.

**Default behavior:** se `path` gia' esiste -> errore `Duplicate`. Se si vuole sovrascrivere: `upload(..., fileOptions: FileOptions(upsert: true))`.

### 5.2 Pattern scelto: path deterministic + upsert

Path costruito con `client_id` dell'ActivityMedia:

```
{owner_id}/media/{activity_client_id}/{media_client_id}_full.jpg
{owner_id}/media/{activity_client_id}/{media_client_id}_thumb.jpg
```

- `{owner_id}` e `{activity_client_id}` e `{media_client_id}` sono tutti UUID noti client-side.
- Ripetere l'upload dello stesso bytes-content allo stesso path con `upsert: true`: idempotente.
- Ripetere l'upload di un contenuto diverso allo stesso path (mai dovrebbe accadere -- foto sono immutabili): sovrascrive. Accettabile.

### 5.3 Sequenza upload ActivityMedia

```
1. Carica thumb binary su Storage (upsert:true).
2. Carica full binary su Storage (upsert:true).
3. INSERT riga in tabella activity_media con storage_path_thumb / storage_path_full gia' noti.
```

Se retry dopo fail tra 2 e 3:

- Step 1 e 2 re-eseguiti: upsert sovrascrive stessi bytes. Idempotente.
- Step 3 re-eseguito: `ON CONFLICT client_id DO NOTHING`. Idempotente.

Se retry dopo fail tra 3 e lettura OK: step 3 e' gia' stato eseguito ma il client non ha saputo. Nuovo tentativo trova duplicato, legge la riga esistente. OK.

### 5.4 Orphan binaries

**Edge:** il client carica binary su Storage (step 1-2), poi il client stesso fallisce per sempre prima di step 3. La riga `activity_media` non viene mai creata. I file in Storage restano "orfani".

**Mitigazione:** pg_cron settimanale che esegue scan di Storage e cancella file senza riga `activity_media` corrispondente e piu' vecchi di 7 giorni.

**Implementazione rinviata:** non critica per MVP (volume basso, storage Supabase costa poco). Aggiunta come task post-MVP.

---

## Sezione 6 -- Race conditions client-side

### 6.1 Due istanze sync orchestrator

**Scenario:** bug fa partire due istanze concorrenti del sync orchestrator nello stesso processo. Potrebbero processare lo stesso item della `sync_queue` in parallelo.

**Prevenzione:**

- Singleton strong per l'orchestrator, registrato una volta sola in `ModuleRegistry`.
- Lock atomico sul dequeue: il primo a fare `UPDATE sync_queue SET state='in_flight' WHERE id = X AND state='queued'` vince. Il secondo trova 0 righe aggiornate e ri-dequeue.

**Implementazione:**

```dart
final rowsUpdated = await db.customUpdate(
  'UPDATE sync_queue SET state = ? WHERE id = ? AND state = ?',
  variables: [Variable(SyncItemState.in_flight.name), Variable(item.id), Variable('queued')],
);
if (rowsUpdated == 0) {
  // qualcun altro l'ha preso. skip.
  return;
}
```

Grazie a questo pattern, la duplicazione del worker non produce double-upload.

### 6.2 Modifica entity durante sync in-flight

**Scenario:** sync sta spedendo Activity X (status `in_flight`). Utente modifica il titolo di X.

**Default coalescence (`queue_design.md` Sezione 3.4):** nuovo item `UPDATE X` viene accodato come separato. Dopo completamento INSERT/UPDATE in-flight, il nuovo UPDATE viene processato. Nessun duplicato sul server.

**Perche' funziona:** l'upload_dispatcher legge sempre il payload fresco da drift al momento dell'invio. Se al secondo invio legge i dati gia' con titolo modificato, e' corretto: il server riceve l'UPDATE finale.

### 6.3 Delete di entity con sync in-flight

**Scenario:** sync sta spedendo Activity X (INSERT in_flight). Utente fa delete di X.

**Default coalescence:** DELETE viene accodato. Dopo completamento INSERT: il server ha la X. Poi processa DELETE: soft delete sul server. OK.

**Alternativa piu' efficiente:** abort dell'INSERT in-flight. Non implementato in MVP -- complicato, raro, coalescence sequenziale basta.

---

## Sezione 7 -- Version tracking

### 7.1 `version` field

Presente su: `profiles`, `motorcycles`, `activities`, `planned_routes`, `published_routes`.

### 7.2 Uso attuale (MVP)

- Client increment `+1` ad ogni modifica locale.
- Inviato al server durante sync.
- Server lo memorizza, non fa check.
- Single-device: il `version` del client e' sempre allineato con il server una volta synced.

### 7.3 Uso futuro (post-MVP multi-device)

- Optimistic concurrency: ad ogni UPDATE, client invia `version` che crede di avere. Server verifica:
  - Se `db.version == client.version`: accetta update, incrementa a `version+1`.
  - Se `db.version > client.version`: conflict. Server ritorna 409. Client deve fare merge.
- Conflict resolution: strategia last-writer-wins semplice, o piu' sofisticata field-by-field.

**Gia' predisposto nello schema, non attivo.**

---

## Sezione 8 -- Idempotency in rehydration

### 8.1 Principio

Rehydration al primo login e' idempotente per natura: ogni scarico fa `upsert` in drift locale. Interruzione a meta' e ripresa non causa duplicati.

Pattern:

```dart
for (final rowFromServer in serverActivitiesPage) {
  await db.into(activitiesLocal).insertOnConflictUpdate(
    ActivitiesLocalCompanion(
      clientId: Value(rowFromServer.clientId),
      // ... tutti i campi
      syncState: Value(SyncState.synced),
    ),
  );
}
```

`insertOnConflictUpdate` di drift: equivale a `INSERT OR REPLACE` in SQLite (per chiave PK). PK e' `client_id` -> riga sovrascritta se esiste.

### 8.2 Pagination

Rehydration puo' essere interrotta a meta' pagina. Drift e' in una transaction per pagina: se interrotto a meta', rollback automatico, prossima volta si riparte dall'inizio della pagina.

**Nessun flag "pagina X completata"** in drift. Semplice e robusto.

### 8.3 Flag di completamento totale

`profile.local_initial_rehydration_complete` passa a `true` **solo al termine di tutte le fasi** (vedi `queue_design.md` Sezione 6.1). Se rehydration interrotta: flag resta `false` -> al prossimo avvio, rehydration riparte.

Non conserviamo stato granulare "Activity pagina 3 completata" -- riparte dall'inizio, sovrascrive dati gia' locali (che erano corretti, perche' server non e' cambiato significativamente nel frattempo). Costo: piccolo overhead traffico. Beneficio: semplicita' codice.

---

## Sezione 9 -- Tavola riepilogativa delle garanzie

| Operazione | Strumento idempotency | Comportamento su retry |
|---|---|---|
| INSERT nuova entity | `client_id` UUID v4 + ON CONFLICT | Non duplica, ritorna riga esistente |
| UPDATE entity esistente | PATCH con `updated_at` + `version+1` | Sovrascrive con stesso valore, idempotente |
| SOFT DELETE | UPDATE `deleted_at` con timestamp client | Scrive sempre stesso timestamp, idempotente |
| HARD DELETE | DELETE by client_id | 0 righe se gia' cancellato, non errore |
| UPLOAD STORAGE binario | path deterministic + `upsert:true` | Sovrascrive stessi bytes, idempotente |
| REHYDRATION SELECT | upsert drift + flag finale boolean | Interrompibile, riparte dall'inizio |

---

## Sezione 10 -- Contratti di test

Test che devono passare per considerare l'idempotency corretta:

### 10.1 Unit test (client)

- **UploadDispatcher INSERT retry 10 volte:** solo una riga in DB, altre 9 chiamate tornano la stessa riga.
- **UploadDispatcher UPDATE 10 volte stesso valore:** database stable, zero errori.
- **UploadDispatcher DELETE su entity non esistente:** no-op, no errore.

### 10.2 Integration test

- Activity creata client -> simulazione timeout sul primo upload -> retry -> verifica server ha una sola riga.
- Activity creata + modificata prima del primo upload -> verifica server riceve solo la versione finale (UPDATE non viene spedito a parte, coalescence).
- Activity creata + cancellata prima del primo upload -> verifica server non la vede mai.

### 10.3 Fault injection

Test specifico con mock Supabase che risponde:
- Sempre timeout: sync resta `pending`, retry count cresce, dopo 5 va `failed`. Activity esiste solo client-side.
- Timeout su OK (la riga e' stata creata server-side, ma il client non ha saputo): secondo tentativo trova duplicate, fetch esistente, tutto converge.
- 500 random: retry con backoff fino a successo.

---

## Sezione 11 -- Open items

- Tutti gli item rilevanti sono in `99_open_questions.md` (riferimenti: A.1 retry policy, A.8 auto-retry orario). Nessun nuovo item emerge da questo documento.

---

**Fine 05_sync/idempotency.md**
