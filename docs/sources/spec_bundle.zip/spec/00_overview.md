# 00 -- Overview

**Progetto:** App Moto
**Stato:** Setup consolidato, pronti per spec di dominio
**Ultimo aggiornamento:** 18 aprile 2026
**Autori:** Ray (architettura) + Lollo (dev principale). Claude affianca entrambi come orchestratore via chat/Claude Code.

Questo documento e' il riferimento globale del progetto. Contiene stack, vocabolario, principi architetturali, struttura del codice e decisioni di setup. Tutto il resto del lavoro (spec di dominio, data model, moduli) deriva da qui e non puo' contraddirlo senza aggiornarlo esplicitamente.

---

## Sezione 1 -- Stack tecnico

**Mobile (unica codebase):** Flutter (Dart) per iOS + Android. Target primario: Android. iOS supportato by-default dal framework ma non ottimizzato nel MVP.

**Backend:** Supabase -- Auth + PostgreSQL + PostGIS + Realtime + Storage + Edge Functions + pg_cron.

**Mappe:** Mapbox GL Native per rendering + Mapbox Navigation SDK per turn-by-turn.

**DB locale:** drift (SQLite) -- offline-first, fonte di verita' locale per activity appena create.

**GPS e background:** geolocator + flutter_background_service.

**Formati percorso:** GeoJSON (scambio), GPX (import/export utente), polyline encoded (storage e trasmissione).

**Notifiche push:** FCM (Android) + APNs (iOS).

**Comunicazioni utente:** Twilio (SMS) + SendGrid (email). Attivati quando servono.

**Pagamenti:** RevenueCat. Attivato quando serve.

**Analytics:** Plausible self-hosted. Attivato quando serve.

**Error logging:** Tabella `error_logs` su Supabase con RLS insert-only. Review settimanale via pg_cron. Migrazione a Sentry solo se volume lo richiede.

---

## Sezione 2 -- Esclusioni esplicite

Queste sono decisioni consolidate. Non si riaprono senza motivazione architetturale esplicita documentata.

- **Zero Next.js.** App mobile-only nel MVP. Nessun companion web, nessuna pagina pubblica, nessun admin panel web, nessun SEO.
- **Zero nativo Apple / Swift.** Una sola codebase Flutter.
- **Admin moderazione in-app.** Rotta protetta visibile solo se `profiles.role == 'admin'`.
- **Live tracking solo tra utenti App Moto installati.** Nessuna pagina pubblica per non-utenti.
- **Condivisione social tramite immagine statica** (Mapbox Static Images API), non tramite link a pagina web.

**Conseguenze strutturali:**
- 2 repository: `app-moto-app` (Flutter) + `app-moto-docs` (documentazione e spec).
- Roadmap Rev02 accorciata: Sprint 8-9 "Web App" diventa solo "Navigazione". Admin Sprint 10-12 diventa in-app.
- Database Supabase progettato per un solo client (Flutter).

---

## Sezione 3 -- Vocabolario di dominio

I nomi seguenti sono canonici. Usati ovunque -- DB, codice, UI, spec. Non si deviano senza modifica globale.

| Termine | Significato |
|---|---|
| **Activity** | Uscita reale registrata dall'utente. Ha tracciato GPS effettivo, tempo reale, metriche. Puo' essere privata o pubblicata. |
| **PlannedRoute** | Percorso pianificato prima di partire. Non ha tracciato reale, solo itinerario progettato. |
| **PublishedRoute** | Percorso condiviso con la community. Snapshot (copia) al momento del publish -- non riferimento vivo. Se la sorgente viene modificata, serve ri-publish. |
| **TrackPoint** | Singolo punto GPS di una Activity. Nel modello: embedded in `activities` come polyline + array jsonb (vedi Sezione 6). Durante la registrazione attiva vive in `track_point_buffer` (vedi Sezione 5.11). |
| **Motorcycle** | Moto registrata nel garage dell'utente. |
| **LiveSession** | Sessione di condivisione posizione in tempo reale durante una Activity in corso. |
| **SafetyContact** | Contatto di sicurezza per SOS / notifiche emergenza. |
| **RecordingSession** | Sessione di registrazione GPS attualmente attiva o recentemente chiusa (vedi Sezione 5.11). |
| **ClientId** | UUID v4 generato lato client al momento di creazione di un'entita' user-generated. Chiave di idempotency verso il backend (vedi Sezione 5.12). |

Termini come "route" da soli sono vietati -- creano ambiguita' tra PlannedRoute e PublishedRoute. Sempre qualificare.

---

## Sezione 4 -- Principi architetturali

### 4.1 Modulo come unita' di senso

L'app e' organizzata in **moduli**. Un modulo e' una *cosa* del dominio (tracking, sync, garage, community, navigation, safety, planning, settings), non un livello tecnico (models, services, screens). Ogni modulo:

- e' completo in se' (dominio + logica + persistenza + UI)
- e' sviluppabile e testabile in isolamento
- comunica con gli altri solo tramite interfacce pubbliche esplicite

Questa scelta e' *vincolante per tutto il progetto*. Non si introducono strutture a layer (lib/models, lib/services, ...) in parallelo -- creano ambiguita' su dove vive cosa.

### 4.2 Ogni modulo e' un package Dart separato

Nel monorepo `app-moto-app`, ogni modulo e' un pacchetto Dart a se' stante, organizzato in una struttura interna standard:

```
modules/<nome_modulo>/
|-- pubspec.yaml                 (dipendenze del modulo)
|-- lib/
|   |-- <nome_modulo>.dart       (manifest + export pubblici)
|   |-- api.dart                 (API consumate da altri moduli)
|   +-- src/
|       |-- domain/              (entita' pure, FSM, value objects -- Dart puro)
|       |-- application/         (casi d'uso, orchestrazione)
|       |-- persistence/         (drift tables + repositories)
|       +-- ui/                  (screens + widgets Flutter)
+-- test/
```

**Regola di dipendenza interna al modulo:** `ui -> application -> domain` e `application -> persistence -> domain`. La cartella `domain` non importa mai niente dagli altri layer del modulo. Questo garantisce che il dominio sia testabile senza Flutter, senza drift, senza Supabase.

**API pubblica del modulo:** esclusivamente cio' che e' esportato da `lib/<nome_modulo>.dart` o `lib/api.dart`. Tutto sotto `lib/src/` e' privato *by construction* -- altri moduli non possono importare da `src/` (Dart lo consente a compilazione ma il lint `implementation_imports` lo rileva come errore e blocca la CI).

**Configurazione richiesta del monorepo:**
- Gestione packages: `melos` (o equivalente che supporti `pub workspace`).
- Lint globale: `implementation_imports: error` attivo in `analysis_options.yaml` a livello root.
- Ogni pubspec di modulo dichiara esplicitamente le dipendenze dagli altri moduli tramite `path:`.

### 4.3 Struttura repository

```
app-moto-app/
|-- melos.yaml
|-- analysis_options.yaml
|-- pubspec.yaml                 (workspace root)
|-- app/                         (entry point Flutter -- main.dart)
|   |-- lib/
|   |   |-- main.dart
|   |   |-- bootstrap.dart
|   |   |-- router.dart
|   |   +-- module_registry.dart
|   +-- pubspec.yaml
|-- modules/
|   |-- tracking/
|   |-- sync/
|   |-- garage/
|   |-- community/
|   |-- navigation/
|   |-- safety/
|   |-- planning/
|   +-- settings/
+-- shared/
    |-- db/                      (drift instance globale)
    |-- supabase_client/         (client + auth state)
    |-- errors/                  (error types comuni)
    |-- ui_kit/                  (design system, componenti base)
    +-- utils/
```

`shared/` e' minimale per scelta. Tutto cio' che puo' stare dentro un modulo specifico ci sta. `shared/` contiene solo cio' che e' *genuinamente* trasversale (connessione DB, client auth, error types comuni, design system).

### 4.4 Manifest del modulo

Ogni modulo espone un manifest Dart nel file `lib/<nome_modulo>.dart`:

```dart
class TrackingModule extends AppModule {
  @override
  String get name => 'tracking';

  @override
  List<String> get dependsOn => ['shared.db', 'shared.supabase_client'];

  @override
  List<Type> get provides => [TrackingApi, ActivityRepository];

  @override
  List<Type> get consumes => [MotorcycleApi]; // dal modulo garage

  @override
  void register(ModuleRegistry r) {
    r.registerApi<TrackingApi>(TrackingApiImpl(...));
    r.registerRepo<ActivityRepository>(ActivityRepositoryImpl(...));
    r.registerEventHandlers(...);
  }
}
```

Il manifest e' il **ponte umano-AI**: quando Claude Code lavora su un modulo, legge il manifest e sa senza ambiguita' cosa puo' toccare e cosa consuma.

### 4.5 Comunicazione tra moduli

Solo **tre canali permessi**, in ordine di preferenza:

**A. Database locale condiviso (drift).**
Per stato persistente. Il modulo community legge `activities` da drift, non chiama TrackingApi per ottenere la lista activity. Il DB e' il canale naturale per consultazione storica / batch / feed.

**B. API pubblica del modulo.**
Per operazioni imperative dove il chiamante sa chi deve chiamare. Esempio: Navigation chiama `TrackingApi.startTracking(route)`. L'API e' in `modules/<modulo>/lib/api.dart`.

**C. Event bus (shared/).**
Per eventi broadcast verso ascoltatori non noti a priori.

**Regola dell'event bus (molto stringente):**
> Event bus e' permesso **solo** per eventi broadcast verso ascoltatori non noti a priori. Il mittente dice "e' successa questa cosa" e non sa (ne' deve sapere) chi ascolta.
>
> Non e' permesso usare l'event bus come scorciatoia per evitare un'API call diretta tra due moduli che si conoscono.
>
> **Test di verifica (regola dell'ascoltatore ignoto):** se riesci a dire "questo evento deve essere ascoltato da Y", non e' un evento, e' una chiamata API mascherata.

Esempi validi: `ActivityCompletedEvent`, `UserLoggedOutEvent`, `SyncQueueFlushedEvent`.
Esempi invalidi: "TrackingFermaNavigation" (deve essere `NavigationApi.stop()`), "CommunityAggiornaFeed" (deve essere una reazione del community module a un evento broadcast).

**Vincoli trasversali:**
- Un modulo non importa mai da un altro modulo se non dalla sua `api.dart`.
- Un modulo **mai** legge le tabelle drift di un altro modulo direttamente se non tramite view/query condivise in `shared/db/`.
- `shared/db/` contiene lo schema globale aggregato. I singoli moduli dichiarano le proprie tabelle, `shared/db/` le compone.

### 4.6 Eventual consistency sulle letture cross-modulo

Quando un modulo legge stato prodotto da un altro modulo tramite DB locale, deve essere tollerante a lag di visibilita'.

Oggi (tutto in drift locale) il lag e' zero. Quando entrera' la sync Supabase, alcune letture potrebbero vedere stato non ancora sincronizzato o non ancora arrivato dal backend.

**Conseguenza pratica:**
- Ogni lettura cross-modulo deve gestire esplicitamente il caso "stato non ancora visibile" (Optional / null / empty list -- mai throw).
- Nessuna query cross-modulo puo' assumere "se A e' stato appena scritto da un altro modulo, lo trovo subito".
- Se serve reazione sincrona a un cambiamento prodotto da un altro modulo, il produttore emette un evento (vedi 4.5) e il consumatore si aggiorna alla ricezione.

### 4.7 Separazione di dominio (check EAR minimale)

Questa sezione e' un check di coerenza, non una prescrizione ontologica.

Ogni modulo deve avere:

- **distinzione**: confini netti rispetto agli altri moduli. Il modulo deve poter essere spiegato in una frase senza menzionare altri moduli.
- **relazione**: canali espliciti e documentati con gli altri moduli (API pubblica + eventi consumati/prodotti).
- **processo**: comportamento osservabile del modulo documentato (FSM se ha stato, use case se stateless).

Se un modulo fallisce uno di questi check (es. non si riesce a descriverlo senza tirar dentro un altro modulo, oppure non ha API pubblica dichiarata, oppure non si sa cosa faccia internamente) va ripensata la sua definizione prima di implementarlo.

---

## Sezione 5 -- Decisioni di setup (prese in fase di setup, revisionabili se emergono vincoli nuovi)

### 5.1 Track points -- storage embedded nella activity finale

I track points **della activity conclusa** non sono in tabella relazionale separata. Sono dentro la riga `activities`:

- `polyline_encoded` (text): polyline compressa per rendering mappa, circa 20-50KB per giro.
- `track_points_data` (jsonb): array di `{t, lat, lon, speed, ele, point_state, acc}` per analisi dettagliata.
- `bbox` (geometry, PostGIS): bounding box per query spaziali tipo "activity in quest'area".

**Compressione:** il client comprime gzip `track_points_data` prima di upload (risparmio banda 8-10x).

**Motivazione:** 1 Activity = 1 riga. Timeline personale = scan lineare. Feed community = bbox index. Zero JOIN su tabella punti. Scalabilita' reale senza partizionamento.

**Nota importante:** durante la registrazione attiva i punti NON sono embedded -- vivono in tabella buffer separata (vedi Sezione 5.11). L'embedding avviene solo al termine della recording session, quando il buffer viene impacchettato nella riga `activities`.

**Tradeoff accettato:** non si possono fare query SQL cross-activity sui punti (es. "tutti i punti >180 km/h di tutti gli utenti"). Non e' un caso d'uso realistico nel MVP -- si risolve client-side sul singolo tracciato. Watch list: il caso d'uso "heatmap percorsi della community" (menzionato nel Rev02 originale) riaprira' questa scelta, gestito in Sezione C.1 del documento open questions.

### 5.2 Sync -- single-device, one-way push

MVP e' **single-device**. Mobile e' source of truth per activity nuove; server e' source of truth solo per dati gia' arrivati.

- **Push:** mobile -> server (activity nuove, modifiche, like/commenti, ecc.)
- **Pull dal server:** solo in caso di **prima install / reinstall / nuovo dispositivo** (rehydration: "riscarico le mie ultime N activity dal cloud"). Nessun pull continuo, nessuna logica di merge, nessun conflict resolution.

Multi-device, two-way sync, conflict resolution: out of scope MVP. Se in futuro serve, si progetta allora.

### 5.3 Realtime -- solo live tracking attivo

Supabase Realtime usato **solo** per live tracking di sessioni attive (utente sta guidando E ha condiviso con amici). Connessione aperta per la durata del giro, chiusa alla fine.

Tutto il resto (like, commenti, follow, nuove activity pubblicate): **push notification FCM**. Asincrono per natura, l'utente non si aspetta real-time.

**Beneficio:** budget Realtime scala con *numero di sessioni live simultanee*, non con *numero di utenti attivi*. 50-100x piu' efficiente.

### 5.4 Focus Android, avvertenze background service

Android e' il target primario. `flutter_background_service` + `geolocator` funzionano bene con **foreground service + notifica persistente**.

**Rischio noto: custom ROM aggressivi** -- MIUI (Xiaomi), One UI (Samsung), EMUI (Huawei) uccidono servizi in background nonostante foreground service. Mitigazione:

- Onboarding chiede all'utente "rimuovi l'app dall'ottimizzazione batteria" con deep link a impostazioni sistema.
- Prima del primo tracciamento, sanity check: se ROM custom noto problematico rilevato, mostra warning specifico.
- Riferimento tecnico consolidato: **dontkillmyapp.com** cataloga per vendor e versione Android le procedure esatte. Linkare direttamente dalla pagina warning con deep link alla guida per il vendor rilevato.

Dettaglio completo in `04_tracking/edge_cases.md`.

### 5.5 Eliminazione account utente

**Strategia A (scelta):** soft delete del profilo. Activity restano ma vengono anonimizzate (`owner_id` -> utente "eliminato" sistemico). Relazioni follow rimosse. Commenti e like di un utente eliminato vengono anonimizzati ma non spariscono -- evita "buchi" nel feed per altri utenti.

**Strategia B (scartata):** cascade completo. Piu' destructive per community, piu' semplice ma peggiora UX di chi seguiva l'utente.

Reversibile (e' una scelta di query), GDPR-compliant in entrambe le forme purche' documentato.

### 5.6 Tags delle activity

Array di stringhe libere (`text[]` in Postgres con index GIN). Lato app una **lista suggerita** di tag comuni per uniformita'. Zero tabella normalizzata.

Se in futuro serve "numero di utenti per tag" o autocomplete server-side, si migra a tabella `tags` normalizzata -- costo medio, reversibile.

### 5.7 Media (foto delle activity)

**Tabella `activity_media` separata.** A differenza dei track points, qui volume e' basso e query "tutte le foto di un utente" e' realistica.

- **Max 20 media per activity** (soft limit, enforceable lato app). Motivazione: giro tipico di 2-4h produce 5-10 foto per utente medio; 20 copre il 95esimo percentile senza gonfiare storage. Numero facilmente modificabile (constant in codice), non e' schema-bound. Revisione a 3 mesi di produzione se distribuzione reale dice altro.
- Thumbnail generata **client-side** prima di upload (librerie Flutter mature, evita Edge Function).
- Storage path: `{user_id}/media/{activity_id}/{media_id}_{variant}.jpg` con `variant` in {thumb, full}.
- Compressione `full`: qualita' 85, max 2048px lato lungo. `thumb`: 400x400 center crop.

### 5.8 Migrations e ambienti

- Migrations SQL numerate con **timestamp** (`YYYYMMDDHHMMSS_nome_migration.sql`).
- Chi apre PR crea la migration; review obbligatoria prima di merge.
- `supabase db push` **solo da main** via CI.
- **Ambiente staging** creato subito (costa poco, previene disastri). Ogni PR che tocca DB testa la migration su staging prima di merge su main.

### 5.9 Feature flags

Colonna `feature_flags jsonb` su `profiles` con default `{}`. Check client-side tramite helper in `shared/`. Zero servizio esterno.

Permette spegnere/accendere feature per utente o ruolo. Se serve granularita' maggiore (A/B test, rollout percentuale), si integra ProviderFlag/Unleash/altro: reversibile.

### 5.10 Error logging

Tabella Supabase `error_logs` con:

- RLS: INSERT consentita a `authenticated`, SELECT solo a `admin`.
- Colonne essenziali: `user_id`, `platform`, `app_version`, `module`, `level`, `message`, `stack_trace`, `context jsonb`, `created_at`.
- Retention: 90 giorni, pulizia via pg_cron settimanale.
- Review: dashboard in-app per admin.

Se il volume esplode o servono alert real-time, migrazione a Sentry.

### 5.11 Tracking survivability -- scrittura progressiva dei punti

**Invariante assoluta:** nessun dato GPS in corso di registrazione puo' vivere unicamente in memoria RAM. Ogni punto ricevuto dal sensore viene scritto in drift entro il ciclo di ricezione successivo.

**Meccanismo:**

- Tabella drift locale `recording_session` con stato `active | closed_unsynced | closed_synced` e `client_id` UUID v4 generato alla creazione.
- Tabella drift locale `track_point_buffer` che contiene i punti GPS della `recording_session` attualmente in corso. FK a `recording_session.client_id`.
- Ad ogni callback `Position` ricevuto dal `flutter_background_service` il modulo tracking esegue una INSERT in `track_point_buffer`. Nessun accumulo RAM-only.
- Al termine normale della registrazione (utente preme stop): il buffer viene impacchettato -- polyline encoded + array jsonb + bbox -- nella riga `activities` corrispondente. La `recording_session` passa a `closed_unsynced`. Il buffer viene pulito al termine della sync (`closed_synced`).
- Al crash / kill OS / restart dispositivo: al bootstrap l'app controlla `recording_session WHERE state = 'active'`. Se presente, mostra dialog di recovery con mappa del tratto registrato fino all'interruzione e opzioni: *Salva come completata* / *Salva come incompleta* / *Scarta*.

**Conseguenza per il design dei moduli:**

- Il modulo `tracking` gestisce `recording_session` + `track_point_buffer`.
- Il modulo `sync` gestisce solo le activity gia' chiuse (`closed_unsynced -> closed_synced`). Non tocca il buffer.
- Separazione coerente con regole Sezione 4.5 (comunicazione tra moduli via DB condiviso, ciascuno vede solo le proprie tabelle).

**Tradeoff accettato:** scrittura SQLite ogni 1-2 secondi durante il tracking. Impatto batteria misurato in letteratura circa 1-2% per un giro di 2h. Accettabile vs perdita dati in caso di crash.

**Perche' non e' overengineering:** questo e' il pattern standard delle app di tracking (Strava, Komoot, Kurviger, RideWithGPS). Implementarlo ora costa uguale a non implementarlo, ma eviterebbe un intero round di rework se in futuro si scoprisse che serve (che si scoprirebbe). Zero debito tecnico.

**Irrobustimenti rimandati:**

- Isolate Dart dedicato al tracking (resistenza a crash del main isolate): non implementato nel MVP. Se emerge come necessario, si aggiunge senza toccare lo schema del buffer.
- Crash detection / auto-SOS: out of scope come gia' stabilito (B.5 in open questions).

### 5.12 Client-generated UUID e idempotency end-to-end

**Invariante assoluta:** ogni entita' user-generated (Activity, PublishedRoute, PlannedRoute, Motorcycle, RouteComment, RouteLike, SafetyEvent) riceve un UUID v4 generato **client-side** al momento di creazione in memoria, PRIMA di qualsiasi scrittura su drift o invio a Supabase. Questo UUID e' il **`client_id`** dell'entita' e accompagna ogni operazione di sync fino al backend.

**Shape del campo:**

- Colonna `client_id UUID NOT NULL` su ogni tabella user-generated (sia drift che Postgres).
- UNIQUE constraint su `client_id` a livello Postgres.
- Generazione: `Uuid().v4()` via pacchetto `uuid` Dart, eseguito nel costruttore del modello di dominio.

**Regola di idempotency sul backend:**

- Ogni endpoint di creazione (Edge Function o insert via supabase_flutter client) implementa `INSERT ... ON CONFLICT (client_id) DO NOTHING RETURNING *`.
- Se il record con quel `client_id` esiste gia', il server restituisce la riga esistente (non errore). Dal punto di vista del client, l'operazione e' sempre "riuscita" dopo il primo successo, anche se ripetuta N volte.
- Update/delete idempotenti per costruzione (operano su `client_id` esistente).

**Perche' e' cross-cutting e non un dettaglio di sync:**

- Riguarda il modello dati (schema di tutte le tabelle user-generated).
- Riguarda il dominio (i modelli Dart generano l'UUID nel costruttore).
- Riguarda la sync (idempotency sull'upload).
- Riguarda la persistenza locale (PK logica delle righe drift).

Va quindi fissato ora e rispettato da ogni modulo, non relegato al solo `05_sync/`.

**Relazione con la server-side `id`:**

- Postgres mantiene una colonna separata `id UUID DEFAULT gen_random_uuid() PRIMARY KEY` come identificatore interno del server.
- `client_id` e' la chiave di business / idempotency. Lato client e API si usa sempre `client_id`.
- `id` server-side si usa solo per FK interne in DB quando ha senso (es. per performance in JOIN), ma e' un dettaglio di persistenza non esposto al client. Pattern raccomandato: esporre `client_id` anche come PK nelle view server-to-client.

**Conseguenza operativa per la rete:**

- Client genera Activity con `client_id = X`, scrive in drift locale, enqueue upload.
- Sync worker invia POST. Rete cade dopo che il server ha ricevuto ma prima della conferma.
- Retry parte. Server vede `client_id = X` gia' presente, non duplica, risponde OK.
- Client marca come `closed_synced`. Zero duplicati nel feed utente.

Dettagli implementativi in `05_sync/idempotency.md` una volta arrivati li'.

---

## Sezione 6 -- Matrice RLS (baseline completa)

Nessun "buco" RLS. Se una tabella viene aggiunta al DB e non e' in questa matrice, la migration fallisce il review.

| Tabella | SELECT | INSERT | UPDATE | DELETE |
|---|---|---|---|---|
| `profiles` | own + public fields di altri (se profilo pubblico) | self (via trigger su `auth.users`) | self | mai |
| `motorcycles` | own | self | self | self (soft delete) |
| `activities` | own + activity pubblica di chi seguo | self | self | self |
| `published_routes` | own + pubblica di chiunque | self | self | self |
| `planned_routes` | own | self | self | self |
| `route_comments` | visibili se utente vede la route | self | self (own comment) | self (own) + owner_route |
| `route_likes` | visibili se utente vede la route | self | mai | self |
| `follow_relationships` | own (chi seguo + chi mi segue) | self | mai | self |
| `live_sessions` | own + partecipanti invitati | self | self (solo own) | self |
| `live_positions` | partecipanti della sessione | via Edge Function | mai | auto via TTL |
| `safety_contacts` | own | self | self | self |
| `safety_events` | own + contacts se triggerato | self + Edge Function | self | mai |
| `notifications` | own | via Edge Function (mai client) | self (solo `read_at`) | self |
| `error_logs` | admin only | authenticated | mai | via pg_cron |
| `activity_media` | come la activity parent | self | self | self |

**Regole trasversali:**

- `admin` role bypassa RLS su righe che lo prevedono esplicitamente (moderazione). Policy: `profiles.role = 'admin'` come predicato.
- **Storage policies** separate: ogni oggetto ha `owner_id` dentro il path (`{user_id}/...`), policy basata su prefix path.
- **Soft delete** (`deleted_at TIMESTAMPTZ NULL`) su tutto cio' che ha valore storico: activities, motorcycles, published_routes, planned_routes.
- **Hard delete** solo su dati effimeri: live_positions, notifications con `read_at` NOT NULL da piu' di 30 giorni, error_logs piu' vecchi di 90 giorni.

Dettagli SQL delle policy in `02_database_schema.md`.

---

## Sezione 7 -- Convenzioni di codifica

### 7.1 Naming

- Entita' di dominio: PascalCase singolare (`Activity`, `TrackPoint`).
- Tabelle DB: snake_case plurale (`activities`, `track_points`).
- File Dart: snake_case (`activity_repository.dart`).
- Branch Git: `feat/<modulo>/<descrizione-kebab>` o `fix/<modulo>/...`.
- Commit: Conventional Commits (`feat(tracking): add pause detection`).

### 7.2 Test

- `domain/`: test unitari obbligatori, coverage target 90% o piu'.
- `application/`: test unitari obbligatori, coverage target 80% o piu'.
- `persistence/`: test integrazione con drift in-memory.
- `ui/`: widget test sui componenti critici; non e' obbligatorio testare ogni screen.

### 7.3 Git workflow

- Main protetto, merge solo via PR con review obbligatoria.
- Ogni PR ha: descrizione cosa cambia, screenshot se tocca UI, lista migration se ne introduce.
- CI richiesta: `flutter analyze`, `dart format --set-exit-if-changed`, test suite verde.
- Squash merge preferito per mantenere storia pulita.

---

## Sezione 8 -- Metodo spec-first

### 8.1 Livelli di spec

Ogni area funzionale/modulo ha spec strutturate in tre livelli:

- **L0 -- Architettura** (1 pagina). Cosa esiste, cosa fa a livello macro, come si relaziona con il resto.
- **L0.5 -- Interfacce**. Firme di funzioni/classi pubbliche, shape dei dati, contratti. No implementazione.
- **L1 -- Implementazione**. Pseudocodice dettagliato o prosa tecnica precisa. Claude Code puo' implementare senza domande.

### 8.2 Iterazione

Per ogni nuova area: L0 -> feedback -> L0.5 -> feedback -> L1 -> feedback -> consolidato. Iterazioni corte. Niente documenti monolitici.

### 8.3 Edge case

Ogni spec ha sezione **"Casi limite e gestione errori"**. Se manca, la spec non e' finita e non va in review.

### 8.4 Decisione

- Decisioni **reversibili a basso costo** (naming, scelta libreria minore, formato interno): Claude sceglie e documenta in 2 righe la motivazione.
- Decisioni **bloccanti o difficilmente reversibili** (schema DB, API pubbliche tra moduli, contratti di sync): mai prese silenziosamente. Vanno a Ray o in `99_open_questions.md`.
- **Trade-off di prodotto** (comportamento user-facing): sempre esposti a Ray con opzioni + pro/contro. Mai scelti da Claude in autonomia.

### 8.5 Vocabolario

Termini della Sezione 3 sono legge. Se emerge la necessita' di un nuovo termine di dominio, va aggiunto alla Sezione 3 con una proposta chiara prima di essere usato altrove.

---

## Sezione 9 -- Output atteso finale

```
spec/
|-- 00_overview.md                    (questo file)
|-- 01_data_model.md                  (entita' come concetti, campi logici)
|-- 02_database_schema.md             (Postgres/Supabase dettagliato + RLS SQL)
|-- 03_local_db.md                    (drift/SQLite + migrazioni)
|-- 04_tracking/
|   |-- L0_architecture.md
|   |-- L05_interfaces.md
|   |-- state_machine.md
|   |-- gps_filters.md
|   +-- edge_cases.md
|-- 05_sync/
|   |-- L0_architecture.md
|   |-- queue_design.md
|   |-- idempotency.md
|   +-- edge_cases.md
|-- 06_garage/
|-- 07_community/
|-- 08_navigation/
|-- 09_safety/
|-- 10_planning/
|-- 11_ui_components/
|-- 12_settings_profile/
+-- 99_open_questions.md
```

Ogni cartella modulo segue lo stesso template: `L0_architecture.md`, `L05_interfaces.md`, `edge_cases.md` minimi + eventuali documenti specifici (state_machine, filters, ecc.).

---

## Sezione 10 -- Ordine di produzione spec

Ordine consolidato (variante proposta da Claude, approvata da Ray):

1. `00_overview.md` [OK] (questo file)
2. `01_data_model.md`: entita' logiche
3. `04_tracking/L0_architecture.md` + `state_machine.md`
4. `05_sync/L0_architecture.md` + `queue_design.md`
5. `02_database_schema.md`: dopo che tracking e sync core sono fissati
6. `03_local_db.md`
7. `04_tracking/`: completamento (L0.5, gps_filters, edge_cases)
8. `05_sync/`: completamento
9. Moduli rimanenti a scalare: garage -> community -> navigation -> safety -> planning -> settings -> ui_components
10. `99_open_questions.md` aggiornato in continuo

**Motivazione ordine:** schema DB fissato dopo tracking+sync L0 evita rework dovuto a scoperte su stati, idempotency keys, shape payload di upload. Costo: ordine non strettamente top-down. Beneficio: zero migration ALTER di rifinitura dopo il primo commit.

---

## Sezione 11 -- Versioning di questo documento

Ogni modifica strutturale a questo file richiede:

- Motivazione nella PR.
- Impatto documentato: quali spec esistenti vanno aggiornate di conseguenza.
- Approvazione di entrambi (Ray + Lollo) se la modifica tocca Sezioni 4, 5, 6, 8.

Modifiche minori (Sezione 1 versioni di libreria, Sezione 3 aggiunta termini, Sezione 7 convenzioni): PR singola sufficiente.

---

**Fine 00_overview.md**
