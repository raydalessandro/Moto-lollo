# 04 / Tracking -- L0.5 Interfaces

**Scopo:** firme Dart delle API pubbliche del modulo tracking, types di dominio esportati, eventi tipizzati, exception. Livello spec che consente a Claude Code di implementare senza ambiguita' di shape.

**Cosa NON e' qui:**

- Implementazione concreta delle classi (vivra' in `src/application/`, `src/domain/`).
- Logica di filtri GPS (in `gps_filters.md`).
- Logica di recovery dettagliata (gia' in `state_machine.md`).
- Casi limite (in `edge_cases.md`).

**Cosa E' qui:**

- Firme delle classi pubbliche esportate da `modules/tracking/lib/api.dart`.
- Shape dei dati scambiati con altri moduli.
- Contratti di errore (exceptions).
- Tipi di ritorno.

**Riferimenti:**

- Architettura modulo: `L0_architecture.md`.
- FSM: `state_machine.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Convenzioni

### 1.1 Naming

- Interfacce pubbliche: `TrackingApi`, `RecoveryService` (se esposto).
- Value objects immutabili: `TrackingState`, `TrackingMetricsSnapshot`, `RecoveryProposal`, `RecoveryDecision`.
- Eventi broadcast: suffisso `Event` (`ActivityCompletedEvent`).
- DTO per chiamate: suffisso `Request` / `Response` quando utile.
- Exception custom: suffisso `Exception` (`TrackingException`, `PermissionDeniedException`).

### 1.2 Immutabilita'

Tutti i value objects sono immutabili. Realizzati con `@immutable` + `final` fields + costruttore `const` dove possibile. Per oggetti complessi con molti campi si usa `freezed` (gia' tipicamente in progetti Flutter medio-grandi) con `@freezed` e `copyWith` generato.

### 1.3 Null-safety

Nessun `dynamic`. Tutti i types nullable sono dichiarati esplicitamente con `?`. Tutti i fallback sono impliciti: una lettura di stato che puo' essere "non ancora disponibile" ritorna `Future<T?>` o `Stream<T?>`, non lancia.

### 1.4 Gestione errori

- **Operazioni che possono fallire in modo prevedibile** (permessi negati, precondizioni non soddisfatte, storage pieno): ritornano `Result<T, TrackingError>`.
- **Errori di programmazione** (stato FSM inconsistente, invariante violato): throw di `StateError`. Non gestibili dal chiamante, vanno risolti con bugfix.
- **Errori tecnici inattesi** (drift fail, geolocator crash): catturati internamente dal controller, convertiti in `TrackingError.internalFailure` e propagati se impattano API chiamanti, loggati in error_logs.

**Pattern `Result`:** uso `Either<TrackingError, T>` della libreria `dartz` o equivalente semplice fatto in casa. Dichiaro qui la forma:

```dart
sealed class Result<T, E> {
  const Result();
  bool get isOk => this is Ok<T, E>;
  bool get isErr => this is Err<T, E>;
}

final class Ok<T, E> extends Result<T, E> {
  final T value;
  const Ok(this.value);
}

final class Err<T, E> extends Result<T, E> {
  final E error;
  const Err(this.error);
}
```

---

## Sezione 2 -- Types di dominio pubblici

Dichiarati in `modules/tracking/lib/api.dart` o re-export da `src/domain/`.

### 2.1 `TrackingState`

Enum FSM. Corrisponde 1-a-1 agli stati definiti in `state_machine.md` Sezione 1.

```dart
enum TrackingState {
  idle,
  preparing,
  recordingActive,
  recordingAutoPaused,
  recordingManualPaused,
  recordingSignalLost,
  closing,
  recovering,
}
```

### 2.2 `TrackingMetricsSnapshot`

Snapshot momentaneo delle metriche durante una registrazione. Osservabile via stream.

```dart
@freezed
class TrackingMetricsSnapshot with _$TrackingMetricsSnapshot {
  const factory TrackingMetricsSnapshot({
    required TrackingState state,
    required String? activeRecordingClientId, // null se stato idle
    required Duration elapsedTime,
    required Duration totalTimeIncludingPauses,
    required double distanceKm,
    required double avgSpeedKmh,
    required double currentSpeedKmh,
    required double maxSpeedKmh,
    required int pointsBuffered,
    required DateTime lastPointAt,
    required double? lastAccuracyM,
  }) = _TrackingMetricsSnapshot;
}
```

**Uso tipico:** UI ascolta `TrackingApi.metricsStream` e aggiorna il display ogni secondo.

**Performance:** emissione snapshot ogni `~1s` (non ad ogni callback GPS) per non saturare il listener. Valore `lastPointAt` permette di capire quanto e' "fresco" lo stato.

### 2.3 `StartRecordingRequest`

```dart
@freezed
class StartRecordingRequest with _$StartRecordingRequest {
  const factory StartRecordingRequest({
    required String? motorcycleClientId,  // null ammesso se utente non ha moto
    String? draftTitle,
    String? draftNotes,
  }) = _StartRecordingRequest;
}
```

### 2.4 `RecoveryProposal`

Emesso da `checkRecovery()` quando e' stata trovata una RecordingSession `active` al bootstrap.

```dart
@freezed
class RecoveryProposal with _$RecoveryProposal {
  const factory RecoveryProposal({
    required String recordingSessionClientId,
    required DateTime startedAt,
    required DateTime lastPointAt,
    required Duration elapsedTime,
    required double distanceKmSoFar,
    required String? motorcycleClientId,
    required String? draftTitle,
    required int bufferedPointsCount,
    required String compactPolylineForPreview, // polyline semplificata per mini-mappa
  }) = _RecoveryProposal;
}
```

### 2.5 `RecoveryDecision`

```dart
enum RecoveryDecision {
  saveAsComplete,    // equivalente a stopRecording normale
  saveAsIncomplete,  // stessa cosa ma with was_recovered=true
  discard,           // hard delete buffer + session
  resume,            // (non implementato in MVP, preparato per A.3 opzione X)
}
```

### 2.6 `TrackingError`

```dart
sealed class TrackingError {
  const TrackingError();
}

final class PermissionDeniedError extends TrackingError {
  final TrackingPermission which;
  const PermissionDeniedError(this.which);
}

final class AnotherSessionActiveError extends TrackingError {
  final String existingSessionClientId;
  const AnotherSessionActiveError(this.existingSessionClientId);
}

final class MotorcycleNotFoundError extends TrackingError {
  final String motorcycleClientId;
  const MotorcycleNotFoundError(this.motorcycleClientId);
}

final class StorageFullError extends TrackingError {
  const StorageFullError();
}

final class BackgroundServiceStartFailedError extends TrackingError {
  final String reason;
  const BackgroundServiceStartFailedError(this.reason);
}

final class NoActiveRecordingError extends TrackingError {
  const NoActiveRecordingError();
}

final class InvalidStateTransitionError extends TrackingError {
  final TrackingState from;
  final String triggerName;
  const InvalidStateTransitionError(this.from, this.triggerName);
}

final class InternalFailureError extends TrackingError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

### 2.7 `TrackingPermission`

```dart
enum TrackingPermission {
  locationForeground,
  locationBackground,
  notification,       // richiesta da foreground service Android 13+
  batteryOptimization // NON rimosso dall'utente
}
```

Nota: `batteryOptimization` non e' un permesso in senso stretto ma una *condizione* che l'utente deve impostare manualmente. Il modulo tracking lo verifica e puo' chiedere "vuoi aprire le impostazioni e disattivare l'ottimizzazione batteria per quest'app?". Vedi `edge_cases.md`.

---

## Sezione 3 -- `TrackingApi` (contratto pubblico)

Dichiarata come classe astratta. Implementazione concreta in `src/application/tracking_api_impl.dart`. Iniettata via `ModuleRegistry`.

```dart
abstract class TrackingApi {
  // ---------- STATO OSSERVABILE ----------

  /// Emette snapshot metriche ad ogni aggiornamento rilevante (circa 1Hz).
  /// Se nessuna registrazione attiva, emette snapshot con state=idle e metriche a zero.
  Stream<TrackingMetricsSnapshot> get metricsStream;

  /// Stato corrente sincrono.
  TrackingState get currentState;

  /// client_id della registrazione attualmente attiva, o null.
  String? get activeRecordingClientId;

  // ---------- OPERAZIONI DI REGISTRAZIONE ----------

  /// Avvia una nuova registrazione.
  ///
  /// Fallisce con:
  /// - AnotherSessionActiveError se gia' c'e' una RecordingSession attiva.
  /// - MotorcycleNotFoundError se motorcycleClientId passato non esiste.
  /// - PermissionDeniedError se permessi GPS / notifiche negati.
  /// - BackgroundServiceStartFailedError se flutter_background_service non parte.
  ///
  /// Ritorna il client_id della RecordingSession creata su successo.
  Future<Result<String, TrackingError>> startRecording(StartRecordingRequest request);

  /// Mette in pausa manualmente.
  ///
  /// Fallisce con:
  /// - NoActiveRecordingError se non c'e' una sessione attiva.
  /// - InvalidStateTransitionError se lo stato corrente non permette pausa (es. idle, preparing).
  Future<Result<void, TrackingError>> pauseRecording();

  /// Riprende da pausa (manuale o auto).
  ///
  /// Fallisce con:
  /// - InvalidStateTransitionError se stato corrente non e' un paused.
  Future<Result<void, TrackingError>> resumeRecording();

  /// Chiude la registrazione e genera la Activity.
  ///
  /// Ritorna il client_id della Activity creata.
  /// Fallisce con:
  /// - NoActiveRecordingError se niente in corso.
  /// - InternalFailureError se conversione buffer->activity fallisce (dopo 3 retry).
  Future<Result<String, TrackingError>> stopRecording();

  /// Scarta registrazione in corso. Cancella buffer e session.
  ///
  /// Fallisce con:
  /// - NoActiveRecordingError se niente in corso.
  Future<Result<void, TrackingError>> discardRecording();

  // ---------- AGGIORNAMENTO METADATA DRAFT ----------

  /// Aggiorna titolo/note draft della registrazione in corso.
  /// Li salva nella RecordingSession corrente, usati alla chiusura per l'Activity.
  Future<Result<void, TrackingError>> updateRecordingDraft({
    String? title,
    String? notes,
  });

  // ---------- RECOVERY ----------

  /// Invocato al bootstrap. Controlla se esiste RecordingSession con state='active'.
  /// Se si', ritorna RecoveryProposal; se no, null.
  Future<RecoveryProposal?> checkRecovery();

  /// Applica la decisione utente sulla RecoveryProposal.
  /// Esegue l'azione corrispondente (salva / scarta / eventuale resume futuro).
  Future<Result<String?, TrackingError>> applyRecovery({
    required String recordingSessionClientId,
    required RecoveryDecision decision,
  });

  // ---------- CALLBACK DAL MODULO SYNC ----------

  /// Chiamata dal modulo sync quando la Activity corrispondente a questa RecordingSession
  /// e' stata sincronizzata con successo.
  /// Il modulo tracking porta la session a 'closed_synced' e puo' schedulare purge del buffer.
  Future<void> markRecordingSessionSynced(String recordingSessionClientId);
}
```

---

## Sezione 4 -- Eventi emessi sul bus

Dichiarati come `@freezed` value objects in `modules/tracking/lib/api.dart`. Pubblicati via `shared/event_bus/EventBus.emit(event)`.

### 4.1 `RecordingStartedEvent`

```dart
@freezed
class RecordingStartedEvent with _$RecordingStartedEvent {
  const factory RecordingStartedEvent({
    required String clientId,
    required String ownerId,
    required DateTime startedAt,
    required String? motorcycleClientId,
  }) = _RecordingStartedEvent;
}
```

### 4.2 `RecordingStateChangedEvent`

```dart
@freezed
class RecordingStateChangedEvent with _$RecordingStateChangedEvent {
  const factory RecordingStateChangedEvent({
    required String clientId,
    required TrackingState previousState,
    required TrackingState newState,
    required String transitionReason,
    required DateTime occurredAt,
  }) = _RecordingStateChangedEvent;
}
```

**transitionReason** e' stringa enumerativa con valori standard: `user_pause`, `user_resume`, `auto_pause_detected`, `auto_resume_detected`, `signal_lost`, `signal_recovered`, `user_stop`, `user_discard`, `recovery_save_complete`, `recovery_save_incomplete`, `recovery_discard`. Documentato come enum informale.

### 4.3 `ActivityCompletedEvent`

```dart
@freezed
class ActivityCompletedEvent with _$ActivityCompletedEvent {
  const factory ActivityCompletedEvent({
    required String activityClientId,
    required String ownerId,
    required String? motorcycleClientId,
    required DateTime startedAt,
    required DateTime endedAt,
    required Duration duration,
    required double distanceKm,
    required bool wasRecovered,
  }) = _ActivityCompletedEvent;
}
```

**Consumatori attesi:**
- modulo `sync` -> enqueue upload.
- modulo `garage` -> recompute km locale.
- modulo `community` -> prepara suggerimento publish.
- modulo `notifications` (futuro) -> potrebbe triggerare congratulazioni / stats.

### 4.4 `RecordingDiscardedEvent`

```dart
@freezed
class RecordingDiscardedEvent with _$RecordingDiscardedEvent {
  const factory RecordingDiscardedEvent({
    required String clientId,
    required DateTime discardedAt,
    required bool wasRecovery, // true se discarded via recovery dialog
  }) = _RecordingDiscardedEvent;
}
```

---

## Sezione 5 -- Eventi consumati

Il modulo tracking ascolta dal bus:

### 5.1 `UserLoggedOutEvent` (da modulo auth)

Shape definito da modulo auth, rilevante per tracking:

```dart
class UserLoggedOutEvent {
  final String formerUserId;
  final DateTime occurredAt;
  // ...
}
```

Reazione tracking: se stato e' uno dei `recording_*`, transiziona a `recording_manual_paused` e triggera notifica UI. Non chiude la session automaticamente.

### 5.2 `AppLifecycleBackgroundedEvent` / `AppLifecycleForegroundedEvent`

Il modulo tracking NON reagisce a cambi di lifecycle per logica FSM -- il background service continua indipendentemente. Il modulo **puo'** usare questi eventi per ottimizzare UI (es. ridurre frequenza emissioni metrics_stream quando app e' in background), ma non e' obbligato.

---

## Sezione 6 -- `TrackingModule` (manifest)

```dart
class TrackingModule extends AppModule {
  @override
  String get name => 'tracking';

  @override
  List<String> get dependsOn => ['shared.db', 'shared.event_bus'];

  @override
  List<Type> get provides => [TrackingApi];

  @override
  List<Type> get consumes => [MotorcycleApi]; // verifica motorcycle esistente

  @override
  void register(ModuleRegistry r) {
    final db = r.resolve<AppDatabase>();
    final bus = r.resolve<EventBus>();
    final motorcycleApi = r.resolve<MotorcycleApi>();

    final controller = TrackingController(db: db, bus: bus, motorcycleApi: motorcycleApi);
    final api = TrackingApiImpl(controller);

    r.registerApi<TrackingApi>(api);
    r.registerBootstrapTask(controller.bootstrap); // per check recovery al bootstrap
  }
}
```

---

## Sezione 7 -- Contratti sulla `MotorcycleApi` consumata

Il modulo tracking assume dalla `MotorcycleApi` del modulo garage:

```dart
abstract class MotorcycleApi {
  Future<bool> exists(String clientId);
  Future<MotorcycleSummary?> getSummary(String clientId);
}

@freezed
class MotorcycleSummary with _$MotorcycleSummary {
  const factory MotorcycleSummary({
    required String clientId,
    required String name,
    required String brand,
    required String model,
    required double totalKm,
  }) = _MotorcycleSummary;
}
```

Solo questi due metodi sono invocati dal modulo tracking. Il modulo garage puo' esporne altri, ma tracking non se ne cura.

---

## Sezione 8 -- Thread / isolate model

- `TrackingApi` pubblicata e chiamata **esclusivamente dal main isolate**.
- Il `TrackingController` interno coordina il `flutter_background_service` e riceve callback GPS **sul background isolate**.
- Comunicazione main <-> background via port isolate (gestita da `flutter_background_service`).
- Scritture drift (buffer) possono avvenire sia su main che su background: drift supporta cio' via `NativeDatabase.createInBackground()` (vedi A.14).
- Stream `metricsStream` esposto dalla `TrackingApi` e' sempre consumato dal main isolate; il controller fa il bridging background -> main per propagare snapshot.

**Regola esplicita:** codice UI (widgets, screens) non deve MAI tentare di usare direttamente il background service. Interagisce solo con `TrackingApi`.

---

## Sezione 9 -- Dipendenze e injection

Il modulo tracking non usa GetIt / get_it direttamente. Tutte le dependency (AppDatabase, EventBus, MotorcycleApi) sono passate al `TrackingController` via costruttore. Questo rende il modulo testabile senza framework DI.

Il `ModuleRegistry` (in `shared/` o `app/`) si occupa di risolvere le dipendenze e istanziare il controller al bootstrap.

---

## Sezione 10 -- Test contracts

Per ogni metodo di `TrackingApi` esistono test unitari che:

1. Verificano happy path.
2. Verificano ogni `TrackingError` documentato.
3. Verificano invarianti FSM (transizioni vietate rifiutate).

Mock di `MotorcycleApi`, drift, EventBus possibili via iniezione costruttore.

Per test integration (controller + drift reale in-memory):

- RecordingSession stato transitions.
- Buffer accumulation via insert sequenziali.
- buffer_to_activity conversion con metriche calcolate correttamente.
- Recovery su bootstrap con RecordingSession active nel DB.

Copertura target:
- `domain/`: 100% transizioni FSM + 100% funzioni pure metrics.
- `application/`: 80% (escluse interazioni con `flutter_background_service` che richiedono emulatore).

---

**Fine 04_tracking/L05_interfaces.md**
