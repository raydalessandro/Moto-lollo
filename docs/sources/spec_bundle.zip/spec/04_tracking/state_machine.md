# 04 / Tracking -- State Machine

**Scopo:** definizione formale della macchina a stati del modulo tracking. Stati, transizioni ammesse, trigger, side effects (cosa viene scritto in drift, quali eventi vengono emessi).

**Invariante fondamentale:** la FSM e' deterministica. Dato uno stato e un trigger, la transizione risultante e' univoca. Nessuna ambiguita'.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Stati

| Stato | Descrizione |
|---|---|
| `idle` | Nessuna registrazione in corso. L'utente puo' avviarne una nuova. Stato iniziale dell'app. |
| `preparing` | Utente ha premuto "start". Sistema sta verificando permessi, moto, creando RecordingSession. Breve (millisecondi-secondi). |
| `recording_active` | Registrazione in corso. GPS attivo, punti scritti in buffer. Stato "normale" mentre si guida. |
| `recording_auto_paused` | Il filtro GPS ha rilevato sosta (velocita' sotto soglia per tempo T). Registrazione sospesa automaticamente, GPS continua a ricevere ma scarta. |
| `recording_manual_paused` | Utente ha premuto "pause" esplicitamente. Come auto_paused ma richiede azione utente per ripresa. |
| `recording_signal_lost` | GPS non sta ricevendo segnale (galleria, canyon, tunnel). Ultimo punto prima della perdita marcato come `tunnel_entry`. |
| `closing` | Utente ha premuto "stop" (o si sta applicando recovery decision). Sistema sta convertendo il buffer in Activity. Breve (secondi). |
| `recovering` | Al bootstrap: trovata una RecordingSession con state `active`. App attende che la UI mostri dialog e utente decida. |

**Nota: perche' NON c'e' uno stato `error`.** Gli errori (permessi negati, servizio background killato, drift write failure) vengono gestiti come transizioni speciali verso `idle` o come notifica UI senza cambio di stato. La FSM resta pulita; gli errori sono *effetti collaterali* non stati.

---

## Sezione 2 -- Diagramma

```
                            +--------+
                            |  idle  | <------- [stato iniziale app]
                            +--------+
                                |
                                | start()
                                v
                         +-------------+
                         |  preparing  |
                         +-------------+
                                |
                                | permessi OK, session creata
                                v
             +---------> +--------------------+
             |           |  recording_active  |
             |           +--------------------+
             |            ^      |       ^   |
             | resume()   |      |       |   | stop()
             |            |      |       |   |
             |      filter|      |       |   |
             |      auto  |      |       |   |
             |      paused|      |       | signal
             |            |      |       | recovered
             |            |      v       |   |
             |     +----------------------+  |
             |     |  recording_auto_     |  |
             |     |       paused         |  |
             |     +----------------------+  |
             |            |    ^            |
             |            |    |            |
             |            |  filter         |
             |            |  wakes up       |
             | resume()   |    |            |
             |            v    |            |
             |     +----------------------+ |
             |     | recording_manual_    | |
             |     |       paused         | |
             |     +----------------------+ |
             |            |                 |
             |            | pause()         |
             |            |                 |
             |            v                 |
             |     [back to active]         |
             |                              |
             |  signal     signal           |
             |  lost <---  loss             |
             |                              v
             |                 +-----------------------+
             |                 | recording_signal_lost |
             |                 +-----------------------+
             |                           |
             |                           | GPS riappare
             +---------------------------+

                                               stop() / applyRecovery()
                                               v
                                           +---------+
                                           | closing |
                                           +---------+
                                               |
                                               | Activity creata
                                               v
                                           +--------+
                                           |  idle  |
                                           +--------+


     [BOOTSTRAP APP]
        |
        v
     +------------+   recording_session.state=active found
     |  idle      | ------------------------+
     +------------+                         |
                                            v
                                    +-------------+
                                    | recovering  |
                                    +-------------+
                                            |
                                            | applyRecovery(decision)
                                            v
                                    +-------------+
                                    |  closing    |   (per save_complete / save_incomplete)
                                    +-------------+
                                            |
                                            v
                                    +-------------+
                                    |   idle      |   (per discard: hard delete, diretto)
                                    +-------------+
```

---

## Sezione 3 -- Transizioni

Formato: `STATO_ATTUALE -[TRIGGER]-> NUOVO_STATO` + side effects.

### 3.1 Avvio

**`idle -[start(motorcycleId, title)]-> preparing`**
- Validazione: nessuna `recording_session` attiva per owner_id (invariante I.2); `motorcycleId` valido; permessi GPS + notifica concessi (se mancanti: resta in `idle`, side effect = richiesta permessi UI).
- Side effects: nessuno ancora sul DB.

**`preparing -[precondizioni OK]-> recording_active`**
- Side effects:
  - INSERT in `recording_sessions`: `{client_id: UUID v4, owner_id, motorcycle_id, state: 'active', started_at: now(), title_draft: title}`.
  - Avvio `flutter_background_service` in modalita' foreground con notifica persistente.
  - Subscribe callback `geolocator.getPositionStream`.
- Eventi: emette `RecordingStartedEvent`.
- Questa transizione e' automatica, non richiede conferma utente. Una volta entrato in `preparing` e verificate precondizioni, passa a `recording_active`.

**`preparing -[permessi negati]-> idle`**
- Side effects: nessuno (la session non e' stata creata).
- Eventi: nessuno broadcast. La UI riceve errore in risposta alla chiamata `startRecording()`.

### 3.2 Punti GPS in arrivo (transizioni "silenti")

Queste transizioni non cambiano stato, ma vale la pena elencarle perche' rappresentano il flusso principale di eventi.

**`recording_active -[gps_point:normal]-> recording_active`**
- Side effects:
  - INSERT in `track_point_buffer`: `{recording_session_id, seq = next, captured_at, lat, lon, ...}` con `point_state = normal`.
  - Update in-memory di metriche live (distance, avg_speed, max_speed).
- Eventi: nessuno broadcast (il flusso "live state" va sul `Stream<TrackingState>` interno del modulo, non sull'event bus).

**`recording_auto_paused -[gps_point:*]-> recording_auto_paused`**
- Side effects: nessuno. Il punto viene letto dal filtro ma scartato.
- Nota: il filtro continua a valutare. Se la velocita' risale sopra soglia (T secondi), transizionera' a `recording_active`.

**`recording_manual_paused -[gps_point:*]-> recording_manual_paused`**
- Stesso comportamento di auto_paused ma NON c'e' transizione automatica a active -- serve l'utente.

**`recording_signal_lost -[gps_point:*]-> recording_signal_lost` o -> `recording_active`**
- Se il punto e' ricevuto: il GPS ha riacquistato il segnale. Transiziona a `recording_active` (vedi 3.4).
- Se passa timeout T senza punti e siamo gia' in signal_lost: nessuna nuova transizione, aspetta.

### 3.3 Auto-pause e auto-resume

**`recording_active -[filter:auto_pause_detected]-> recording_auto_paused`**
- Trigger: `gps_filter_pipeline` rileva velocita' < soglia_X per durata >= soglia_T. Valori in `gps_filters.md`. Entrambi in `99_open_questions.md` come parametri da confermare con Lollo (default proposta: 1 km/h per 30s).
- Side effects:
  - INSERT marker in buffer: `{seq = next, captured_at: now(), lat/lon = ultimo punto normal, point_state: paused_marker}`.
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_auto_paused, reason: 'auto_pause_detected'}`.

**`recording_auto_paused -[filter:motion_detected]-> recording_active`**
- Trigger: `gps_filter_pipeline` rileva velocita' > soglia_X per N campioni consecutivi.
- Side effects:
  - INSERT marker in buffer: `{seq = next, captured_at: now(), lat/lon = primo punto con moto, point_state: recovered_marker}`.
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_active, reason: 'auto_resume'}`.

### 3.4 Pause / resume manuale

**`recording_active -[pauseRecording()]-> recording_manual_paused`**
- Side effects:
  - INSERT marker `paused_marker` in buffer.
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_manual_paused, reason: 'user_pause'}`.

**`recording_manual_paused -[resumeRecording()]-> recording_active`**
- Side effects:
  - INSERT marker `recovered_marker` in buffer.
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_active, reason: 'user_resume'}`.

**`recording_auto_paused -[resumeRecording()]-> recording_active`**
- Accettato: l'utente puo' forzare il resume anche da auto-pause (es. e' in sosta ma vuole forzare la ripresa del tracking per un motivo suo).
- Side effects: come sopra.

**`recording_active -[pauseRecording()]-> recording_active` (ignorata)**
- Se gia' in active e nessuna pausa e' in corso: la chiamata pauseRecording e' corretta, porta a manual_paused. Non c'e' "doppio pause" da gestire.

### 3.5 Signal lost / recovered

**`recording_active -[filter:signal_lost_detected]-> recording_signal_lost`**
- Trigger: il filtro osserva assenza di punti nuovi per > T secondi (tipicamente 15s) combinata con pattern velocita' stabile pre-perdita (l'utente stava guidando, non era in pausa).
- Side effects:
  - INSERT marker `tunnel_entry` in buffer (con timestamp ultima ricezione + lat/lon ultimo punto normal).
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_signal_lost, reason: 'signal_lost'}`.

**`recording_signal_lost -[gps_point:primo_punto]-> recording_active`**
- Trigger: ricezione di un nuovo punto GPS valido dopo periodo di silenzio.
- Side effects:
  - INSERT marker `tunnel_exit` in buffer (lat/lon = primo punto nuovo).
  - INSERT il punto nuovo stesso come `normal`.
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_active, reason: 'signal_recovered'}`.

**Nota importante:** il tratto "in galleria" NON ha punti tra `tunnel_entry` e `tunnel_exit`. Nel rendering della polyline, questo tratto viene disegnato come linea retta interpolata (dashed style opzionale). Le metriche (distance_km) NON contano il tratto in galleria -- tradeoff accettato: leggera sottostima della distanza per coerenza (non inventiamo dati).

### 3.6 Pausa e signal lost insieme

**`recording_auto_paused -[filter:signal_lost]-> recording_auto_paused`**
- Se siamo in auto-pause e poi perdiamo segnale: no transizione, restiamo in auto-pause. Il segnale perso non e' rilevante perche' siamo gia' sospesi.

**`recording_manual_paused -[filter:signal_lost]-> recording_manual_paused`**
- Stesso. Pausa manuale prevale, signal lost ignorato.

### 3.7 Stop

**`recording_active -[stopRecording()]-> closing`**
**`recording_auto_paused -[stopRecording()]-> closing`**
**`recording_manual_paused -[stopRecording()]-> closing`**
**`recording_signal_lost -[stopRecording()]-> closing`**
- Tutti gli stati di registrazione convergono su `closing` via stop.
- Side effects: nessuno immediato. La conversione avviene nella transizione successiva.

**`closing -[buffer_to_activity OK]-> idle`**
- Side effects:
  - INSERT in `activities` con polyline, jsonb, metriche calcolate, `sync_state = pending`, `was_recovered = false`.
  - UPDATE `recording_session.state = 'closed_unsynced'`, `ended_at = now()`.
  - Stop `flutter_background_service`.
  - Unsubscribe `geolocator`.
- Eventi: emette `ActivityCompletedEvent`.

**`closing -[buffer_to_activity FAIL]-> closing` (retry interno)**
- La conversione da buffer a Activity puo' fallire (transaction drift failure). In questo caso NON si cambia stato -- si fa retry con backoff fino a 3 tentativi.
- Dopo 3 tentativi falliti: transizione a `idle` + side effect = lascia la `recording_session` in `state = active` cosi' che al prossimo bootstrap il recovery la riprenda. Emette evento di errore tecnico in `error_logs`.
- Questo caso e' estremamente raro (drift in-process non dovrebbe mai fallire se il device ha storage libero). Gestione difensiva.

### 3.8 Scarto / discard

**`recording_active -[discardRecording()]-> idle`**
**`recording_auto_paused -[discardRecording()]-> idle`**
**`recording_manual_paused -[discardRecording()]-> idle`**
**`recording_signal_lost -[discardRecording()]-> idle`**
- Side effects:
  - Hard DELETE di `track_point_buffer WHERE recording_session_id = current.client_id`.
  - Hard DELETE della `recording_session` stessa.
  - Stop `flutter_background_service`.
- Eventi: emette `RecordingDiscardedEvent`.

### 3.9 Recovery (bootstrap)

**`[app startup] -> idle` normalmente.**

Al bootstrap, `TrackingController.init()` controlla:

- Se `recording_sessions WHERE state = 'active'` esiste: transizione diretta a `recovering`. Fase `idle` di default saltata.
- Altrimenti: resta in `idle`.

**`recovering -[applyRecovery(save_complete)]-> closing`**
- Side effects: come 3.7 stop + `was_recovered = false` (l'utente ha scelto "salva completa" come se avesse fermato normalmente).

**`recovering -[applyRecovery(save_incomplete)]-> closing`**
- Side effects: come 3.7 stop + `was_recovered = true`.

**`recovering -[applyRecovery(discard)]-> idle`**
- Side effects: come 3.8 discard.

**`recovering -[applyRecovery(resume)]-> recording_active`** (se sub-decisione A.3 opzione X approvata)
- Side effects:
  - Riattiva `flutter_background_service`.
  - Resubscribe `geolocator`.
  - Non aggiunge marker. Il gap tra crash e riavvio non sara' rappresentato nel tracciato (l'utente ne e' consapevole).
- Eventi: emette `RecordingStateChangedEvent{new_state: recording_active, reason: 'recovered_resume'}`.
- **Non implementato in MVP.** Transizione prevista in design, codice scritto in modo da supportarla se attivata.

### 3.10 Eventi di sistema

**Qualsiasi stato -[UserLoggedOutEvent]-> ?**

- Se stato e' `idle`: no-op.
- Se stato e' `preparing`: transiziona a `idle`, annulla creazione session.
- Se stato e' uno dei `recording_*`: transiziona a `recording_manual_paused` + UI warning "hai una registrazione in corso, concludila prima di uscire". Non forza la chiusura.
- Se stato e' `closing`: lascia completare la conversione, poi idle.
- Se stato e' `recovering`: resta in recovering, il dialog va mostrato comunque al successivo login.

**Qualsiasi stato -[AppLifecycleBackgroundedEvent]-> stesso stato**
- No cambio FSM. Il background service prende in carico il work.

**Qualsiasi stato -[AppLifecycleForegroundedEvent]-> stesso stato**
- No cambio FSM. La UI si aggiorna dal `Stream<TrackingState>`.

---

## Sezione 4 -- Tabella riepilogativa transizioni

| From | Trigger | To | Side effect chiave |
|---|---|---|---|
| `idle` | `start()` | `preparing` | nessuno DB |
| `preparing` | precondizioni OK | `recording_active` | INSERT session, avvio background, `RecordingStartedEvent` |
| `preparing` | precondizioni fail | `idle` | nessuno |
| `recording_active` | `gps_point:normal` | `recording_active` | INSERT track_point_buffer |
| `recording_active` | `filter:auto_pause` | `recording_auto_paused` | INSERT paused_marker |
| `recording_active` | `pauseRecording()` | `recording_manual_paused` | INSERT paused_marker |
| `recording_active` | `filter:signal_lost` | `recording_signal_lost` | INSERT tunnel_entry |
| `recording_active` | `stopRecording()` | `closing` | nessuno |
| `recording_active` | `discardRecording()` | `idle` | DELETE buffer + session |
| `recording_auto_paused` | `filter:motion` | `recording_active` | INSERT recovered_marker |
| `recording_auto_paused` | `resumeRecording()` | `recording_active` | INSERT recovered_marker |
| `recording_auto_paused` | `stopRecording()` | `closing` | nessuno |
| `recording_auto_paused` | `discardRecording()` | `idle` | DELETE buffer + session |
| `recording_manual_paused` | `resumeRecording()` | `recording_active` | INSERT recovered_marker |
| `recording_manual_paused` | `stopRecording()` | `closing` | nessuno |
| `recording_manual_paused` | `discardRecording()` | `idle` | DELETE buffer + session |
| `recording_signal_lost` | `gps_point:first` | `recording_active` | INSERT tunnel_exit + normal |
| `recording_signal_lost` | `stopRecording()` | `closing` | nessuno |
| `recording_signal_lost` | `discardRecording()` | `idle` | DELETE buffer + session |
| `closing` | `buffer_to_activity_OK` | `idle` | INSERT activity, UPDATE session, `ActivityCompletedEvent` |
| `closing` | `buffer_to_activity_FAIL` (3 tries) | `idle` | log errore, session resta active |
| `recovering` | `applyRecovery(save_complete)` | `closing` | come stop |
| `recovering` | `applyRecovery(save_incomplete)` | `closing` | come stop + was_recovered=true |
| `recovering` | `applyRecovery(discard)` | `idle` | DELETE buffer + session |
| `recovering` | `applyRecovery(resume)` | `recording_active` | (non MVP) riattiva servizio |
| `[bootstrap]` | session attiva trovata | `recovering` | nessuno |
| `[bootstrap]` | nessuna session attiva | `idle` | nessuno |

---

## Sezione 5 -- Transizioni esplicitamente VIETATE

Per chiarezza, alcune transizioni che potrebbero sembrare plausibili ma non lo sono:

- **`idle -> recording_active` diretto**: mai. Passa sempre da `preparing` che fa le validazioni.
- **`closing -> recording_*`**: mai. Una volta che si e' in closing, la conversione buffer->activity e' in corso; non si puo' "annullare la chiusura" e tornare a registrare.
- **`recording_signal_lost -> recording_manual_paused`**: mai. Se l'utente preme pause mentre e' in signal_lost, la transizione e' direttamente `signal_lost -> manual_paused` (gestita come sub-caso di `pause` da qualsiasi stato di recording, ma non l'ho listata in 3.4 per brevita'; il controller accetta pause da qualsiasi stato di recording).

**Eccezione ammessa alla regola "pause da qualsiasi stato":** in `recording_signal_lost`, `pauseRecording()` e' accettato e transiziona a `recording_manual_paused`. Side effect: scrive `paused_marker` con lat/lon = ultimo punto `normal` disponibile. Aggiungo questa riga alla tabella di Sezione 4 come fix.

| From | Trigger | To | Side effect |
|---|---|---|---|
| `recording_signal_lost` | `pauseRecording()` | `recording_manual_paused` | INSERT paused_marker (su ultimo punto noto) |

---

## Sezione 6 -- Testabilita'

La FSM e' implementata come classe pura Dart in `domain/tracking_state.dart`. Riceve trigger come eventi, ritorna nuovo stato + lista side effects da eseguire. I side effects sono eseguiti dal `TrackingController` nel layer `application/`.

Questo permette test unitari che verificano:

- Ogni transizione della tabella Sezione 4.
- Che transizioni vietate (Sezione 5) vengano rifiutate o ignorate correttamente.
- Che i side effects prodotti corrispondano esatto a quanto atteso per ogni transizione.

**Pattern raccomandato:**

```dart
// Pseudocodice, dettaglio in L05_interfaces.md
final fsm = TrackingFsm(initialState: TrackingState.recording_active);
final result = fsm.handle(TrackingTrigger.pauseRecording());
expect(result.newState, TrackingState.recording_manual_paused);
expect(result.sideEffects, contains(SideEffect.insertMarker(PointState.paused_marker)));
```

Copertura target: 100% delle transizioni valide + test per transizioni rifiutate.

---

## Sezione 7 -- Open items verso Lollo

Da inserire in `99_open_questions.md` sotto Sezione A (proposte da validare):

- **A.4** (nuovo) -- Soglia di velocita' per auto-pause detection. Proposta: `< 1 km/h per > 30 secondi`. Confronto con Strava (2 km/h per 10s) e Komoot (0.5 km/h per 20s). Valori conservativi per moto (stop ai semafori frequenti, non si vuole auto-pause ad ogni rosso).
- **A.5** (nuovo) -- Timeout signal lost detection. Proposta: `15 secondi senza nuovi punti`.
- **A.6** (nuovo) -- Conservazione del buffer dopo `closed_synced`. Proposta: 7 giorni, poi purge. Permette debug post-hoc su sync falliti. Tradeoff storage.

Questi sono parametri, non decisioni architetturali. Valori di default scelti ragionevolmente, validabili dopo sperimentazione in campo.

---

**Fine 04_tracking/state_machine.md**
