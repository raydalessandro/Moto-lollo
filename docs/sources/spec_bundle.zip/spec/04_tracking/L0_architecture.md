# 04 / Tracking -- L0 Architecture

**Modulo:** `tracking`
**Scopo:** questo documento descrive a livello macro (1 pagina densa) cosa fa il modulo, cosa possiede, come si relaziona con il resto dell'app. Dettagli di interfacce in `L05_interfaces.md`, FSM in `state_machine.md`, filtri GPS in `gps_filters.md`, edge case in `edge_cases.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Il modulo `tracking` e' responsabile della **registrazione di una Activity dal momento "utente premi start" al momento "Activity persistita localmente, pronta per sync"**.

In una frase: trasforma un flusso di letture GPS in una Activity persistente.

**Cosa fa:**

- Acquisisce autorizzazioni GPS e background service.
- Gestisce il ciclo di vita di una RecordingSession (start, pause, resume, stop).
- Riceve punti GPS dal sensore tramite `flutter_background_service` e li scrive in `track_point_buffer` in tempo reale.
- Applica filtri GPS (qualita', tunnel detection, auto-pause) durante la registrazione.
- Alla chiusura normale, impacchetta il buffer in una Activity completa con metriche calcolate.
- Gestisce il recovery al riavvio dopo crash / kill OS.
- Emette eventi `ActivityCompletedEvent`, `RecordingStartedEvent`, `RecordingStateChangedEvent` per il resto dell'app.

**Cosa NON fa (frontiera con altri moduli):**

- Non sincronizza con Supabase. La Activity creata viene letta dal modulo `sync` che la spedisce. Vedi `05_sync/`.
- Non gestisce navigazione turn-by-turn. La navigazione e' un modulo separato che, quando attivo durante una registrazione, fornisce solo UI di guida. Vedi `08_navigation/`.
- Non gestisce live sharing. Il modulo `live` ascolta i punti GPS durante registrazione ma e' un consumer separato. Vedi modulo safety/live.
- Non gestisce rendering del tracciato sulla mappa durante la registrazione come responsabilita' primaria. Fornisce il flusso di punti, il widget mappa e' in `ui_kit` o nel modulo UI che compone lo schermo di guida.

---

## Sezione 2 -- Entita' possedute

Il modulo `tracking` e' owner esclusivo delle seguenti tabelle drift. Nessun altro modulo le legge o scrive direttamente.

- **`recording_sessions`** -- vedi `01_data_model.md` Sezione 3.
- **`track_point_buffer`** -- vedi `01_data_model.md` Sezione 4.

Il modulo `tracking` e' anche **writer principale** (ma non owner esclusivo) di:

- **`activities`** -- la riga Activity e' creata dal modulo tracking al momento della chiusura di una RecordingSession. Dopo la creazione, altri moduli possono leggerla (community legge per il feed, garage legge per calcolare km moto, sync legge per spedirla). Altri moduli non scrivono su `activities` se non in circostanze specifiche gestite dal sync (es. ricezione di modifiche da rehydration -- MVP non prevede, ma la tabella e' condivisa).

Le tabelle `activities` sono dichiarate in `shared/db/` perche' condivise. Le tabelle `recording_sessions` e `track_point_buffer` sono dichiarate dentro il modulo `tracking` in `modules/tracking/lib/src/persistence/`.

---

## Sezione 3 -- API pubblica (sintesi)

Dettagli completi in `L05_interfaces.md`. Qui solo la forma.

Il modulo espone una classe astratta `TrackingApi` in `modules/tracking/lib/api.dart` con queste capability principali:

- **Avvio registrazione**: `startRecording({motorcycleId, title})` -- crea una RecordingSession, attiva background service e sensore GPS, transiziona la FSM a `recording_active`.
- **Pausa / ripresa**: `pauseRecording()`, `resumeRecording()` -- transizioni FSM senza fermare servizio. Inserisce marker nel buffer.
- **Stop**: `stopRecording()` -- chiude la session, converte buffer in Activity, salva su drift.
- **Scarta**: `discardRecording()` -- cancella hard la RecordingSession in corso senza creare Activity. Richiede conferma utente lato UI.
- **Stato corrente**: `Stream<TrackingState>` che espone lo stato FSM corrente e metriche live (durata, distanza, velocita' istantanea). Consumer tipico: UI del modulo tracking, e se attivo live sharing, modulo live.
- **Recovery**: `checkRecovery()` -- invocata al bootstrap dell'app. Ritorna un `RecoveryProposal` se c'e' una session con stato `active` trovata al riavvio, altrimenti null.
- **Applica decisione recovery**: `applyRecovery(RecoveryDecision)` -- dopo che la UI ha mostrato il dialog e l'utente ha scelto (save_complete / save_incomplete / discard), il modulo applica.

Nessun'altra chiamata pubblica. Operazioni sulle Activity gia' chiuse (list, read, update metadata, delete) vivono sul repository di `activities` condiviso, accessibile via `shared/` -- non sono API del modulo tracking.

---

## Sezione 4 -- Dipendenze dichiarate

Nel manifest `modules/tracking/lib/tracking.dart`:

```dart
@override
List<String> get dependsOn => [
  'shared.db',              // drift instance globale
  'shared.event_bus',       // emette eventi cross-modulo
];

@override
List<Type> get consumes => [
  MotorcycleApi,            // da modulo garage: per validare motorcycle_id passato a startRecording
];

@override
List<Type> get provides => [
  TrackingApi,
];
```

**Nota:** `MotorcycleApi` e' letta *al momento* di `startRecording` per validazione. Il modulo tracking **non** mantiene riferimenti persistenti a Motorcycle; conserva solo `motorcycle_id` come UUID nella RecordingSession.

**Librerie di terze parti (pubspec del modulo):**

- `geolocator` -- sensore GPS.
- `flutter_background_service` -- foreground service Android + isolate di background.
- `drift` -- persistenza (via `shared.db`).
- `uuid` -- generazione `client_id`.
- `flutter_polyline_points` -- encoding polyline al momento della chiusura.

Nessuna dipendenza da Supabase client. Il modulo tracking e' puro-local: scrive su drift, emette eventi. Il sync e' problema di un altro modulo.

---

## Sezione 5 -- Struttura interna

Coerente con overview Sezione 4.2:

```
modules/tracking/
|-- pubspec.yaml
|-- lib/
|   |-- tracking.dart                    (manifest + classe modulo)
|   |-- api.dart                         (TrackingApi astratta + types pubblici)
|   +-- src/
|       |-- domain/
|       |   |-- tracking_state.dart      (enum FSM + sealed classes per eventi/risultati)
|       |   |-- track_point.dart         (value object, no persistenza)
|       |   |-- recovery_proposal.dart
|       |   +-- metrics_calculator.dart  (funzioni pure per distance, avg_speed, ecc.)
|       |-- application/
|       |   |-- tracking_controller.dart (orchestra FSM, riceve eventi, chiama persistenza)
|       |   |-- recording_lifecycle.dart (start/pause/resume/stop use cases)
|       |   |-- recovery_service.dart    (logica recovery)
|       |   |-- gps_filter_pipeline.dart (applica filtri ai punti in arrivo)
|       |   +-- buffer_to_activity.dart  (converte buffer -> Activity a chiusura)
|       |-- persistence/
|       |   |-- recording_session_table.dart
|       |   |-- track_point_buffer_table.dart
|       |   |-- recording_session_repository.dart
|       |   +-- track_point_buffer_repository.dart
|       +-- ui/
|           |-- recording_screen.dart
|           |-- recovery_dialog.dart
|           +-- widgets/
|               |-- live_metrics_panel.dart
|               |-- start_controls.dart
|               +-- pause_resume_button.dart
+-- test/
    |-- domain/
    |-- application/
    +-- persistence/
```

**Note strutturali:**

- `domain/` e' Dart puro. Nessun import da Flutter, drift, Supabase, geolocator. Testabile via `dart test` senza emulatore.
- `application/tracking_controller.dart` e' il centro di controllo: orchestra la FSM, riceve callback da `geolocator`, chiama `gps_filter_pipeline` + scrittura buffer. E' l'unica classe con stato mutabile importante del modulo.
- `ui/` dipende da `application/` via `TrackingApi`. Mai direttamente da `persistence/` o `domain/`.
- I filtri GPS sono in `application/` perche' orchestrano side effects (lettura history buffer, detection tunnel), non sono funzioni pure. Le funzioni pure di calcolo metriche stanno in `domain/metrics_calculator.dart`.

---

## Sezione 6 -- Eventi

### 6.1 Eventi emessi (broadcast sul event bus)

- **`RecordingStartedEvent`** -- payload: `{client_id, owner_id, started_at, motorcycle_id?}`. Emesso quando la FSM passa a `recording_active` la prima volta (non su resume da pause).
- **`RecordingStateChangedEvent`** -- payload: `{client_id, new_state, transition_reason}`. Emesso ad ogni transizione di stato significativa. Ascoltatori tipici: UI per aggiornare, modulo safety per valutare long-silence.
- **`ActivityCompletedEvent`** -- payload: `{client_id, owner_id, motorcycle_id?, distance_km, duration_seconds, ended_at, was_recovered}`. Emesso quando la Activity viene creata con successo da un buffer. Ascoltatori tipici: modulo sync (enqueue upload), modulo garage (recompute km), modulo community (prepara suggerimento di publish), modulo gamification (future). Vedi overview Sezione 4.5 regola broadcast.
- **`RecordingDiscardedEvent`** -- payload: `{client_id}`. Emesso quando una recording viene scartata (via UI o via recovery dialog).

### 6.2 Eventi consumati

- **`UserLoggedOutEvent`** (da modulo auth/profile) -- il modulo tracking reagisce: se ha una RecordingSession `active`, la transiziona a `recording_paused` e mostra warning UI "sessione in corso, vuoi concluderla prima di uscire?". Non forza la chiusura -- preserva i dati dell'utente.
- **`AppLifecycleBackgroundedEvent`** / **`AppLifecycleForegroundedEvent`** -- il modulo tracking sa se l'app e' in foreground o background per adattare UI ma NON cambia stato FSM. Il background service continua a ricevere punti indipendentemente.

### 6.3 Regola dell'ascoltatore ignoto

Tutti gli eventi sopra rispettano la regola dell'overview Sezione 4.5: sono broadcast, il produttore non conosce i consumer. Se il modulo tracking dovesse inviare un segnale specifico a un modulo noto (es. "modulo navigation fermati quando io mi fermo"), userebbe la `NavigationApi.stop()` direttamente, non un evento.

---

## Sezione 7 -- Interazioni operative

### 7.1 Avvio di una registrazione

1. UI chiama `TrackingApi.startRecording(motorcycleId, title)`.
2. Controller verifica precondizioni:
   a. Nessuna altra RecordingSession `active` per `owner_id` (invariante I.2).
   b. Permessi GPS concessi (chiede se mancanti).
   c. `motorcycleId` esiste e appartiene a `owner_id` (chiama `MotorcycleApi.exists(id)`).
3. Genera nuovo `client_id` UUID v4.
4. Scrive riga in `recording_sessions` con `state = active`.
5. Avvia `flutter_background_service` in modalita' foreground service con notifica persistente.
6. Registra callback sul `geolocator` per ricevere Position.
7. Transiziona FSM a `recording_active`.
8. Emette `RecordingStartedEvent`.

### 7.2 Ricezione di un punto GPS

Ad ogni callback di `geolocator`:

1. Passa la Position al `gps_filter_pipeline`.
2. Il filter decide:
   - `accept` -> crea TrackPoint con `point_state = normal`, scrive in buffer.
   - `reject_accuracy` -> scarta, non scrive nulla.
   - `auto_pause_suggested` -> transiziona FSM a `recording_auto_paused`, inserisce `paused_marker` in buffer.
   - `signal_lost` -> transiziona FSM a `recording_signal_lost`, inserisce `tunnel_entry` se il filtro riconosce pattern.
3. Aggiorna metriche live (durata, distance, speed istantanea). Espone al `Stream<TrackingState>`.
4. Nessuna chiamata di rete. Tutto locale, 100% offline.

### 7.3 Pausa manuale

1. UI chiama `TrackingApi.pauseRecording()`.
2. Controller scrive `paused_marker` nel buffer (con `lat/lon` uguali all'ultimo punto `normal`).
3. Transiziona FSM a `recording_manual_paused`.
4. Il GPS continua a ricevere punti ma il filtro li scarta finche' lo stato e' pausa.
5. Non emette `RecordingStateChangedEvent` al volo per ogni punto scartato -- solo alla transizione di stato.

### 7.4 Stop e creazione Activity

1. UI chiama `TrackingApi.stopRecording()`.
2. Controller transiziona FSM a `closing`.
3. Invoca `buffer_to_activity.convert(recordingSessionId)`:
   - Legge tutti i punti del buffer in ordine di `seq`.
   - Calcola `polyline_encoded` dai punti `normal` (esclusi i marker).
   - Calcola metriche: `distance_km`, `duration_seconds`, `duration_total_seconds`, `avg_speed_kmh`, `max_speed_kmh`, `elevation_gain_m`, `bbox`.
   - Serializza `track_points_data` come array jsonb.
   - Insert transazionale in `activities` con `client_id = recording_session.client_id` e `sync_state = 'pending'`.
   - Update `recording_session.state = 'closed_unsynced'`, `ended_at = now()`.
4. Ferma `flutter_background_service`.
5. Transiziona FSM a `idle`.
6. Emette `ActivityCompletedEvent`.
7. Il buffer NON viene cancellato immediatamente -- resta finche' la RecordingSession passa a `closed_synced` (routine di purge gestita dal modulo tracking in background, trigger = ricezione di segnale da sync "questa session e' synced").

### 7.5 Recovery al bootstrap

1. All'avvio dell'app, `bootstrap.dart` chiama `TrackingApi.checkRecovery()`.
2. Controller cerca `recording_sessions WHERE state = 'active'`.
3. Se trovato: costruisce un `RecoveryProposal` con snapshot dei dati (durata, km, mini-polyline dai punti nel buffer).
4. UI mostra dialog. Utente sceglie `save_complete | save_incomplete | discard`.
5. UI chiama `applyRecovery(decision)`.
6. Controller esegue logica corrispondente:
   - `save_complete`: equivalente a `stopRecording()` normale. Activity creata, `was_recovered = false` (la sessione viene considerata regolarmente conclusa dall'utente).
   - `save_incomplete`: come sopra ma `was_recovered = true`. Utile per filtri statistiche.
   - `discard`: hard delete di `recording_session` + `track_point_buffer` corrispondenti.
7. FSM passa a `idle`. Emette `ActivityCompletedEvent` o `RecordingDiscardedEvent` a seconda del caso.

**Sub-decisione "Riprendi tracciamento" (opzione X in open question A.3):**
- Se Lollo approva l'opzione X, aggiungeremo 4a scelta `resume`. Logica: riporta la session a `active`, riattiva GPS e background service, lascia il buffer com'e'. Il gap temporale tra crash e recovery non e' registrato.
- Per ora NON implementata. Il codice e' scritto in modo tale che aggiungerla non richieda rifattorizzare il resto.

---

## Sezione 8 -- Performance e batteria

### 8.1 Frequenza campionamento GPS

- Default: **1 campione/secondo** (`LocationAccuracy.high`, `distanceFilter: 0`).
- Auto-paused: stesso rate, ma filtro scarta.
- Signal lost (tunnel): geolocator non produce punti, no consumo fix.

### 8.2 Scrittura drift

- Una INSERT per ogni punto `normal` o marker. Batching non e' necessario -- drift gestisce efficientemente writes a 1Hz.
- Benchmark atteso: 1-2% batteria su 2h di guida. Da verificare in campo. Metrics raccolte via telemetria opt-in (post-MVP).

### 8.3 Memoria

- Buffer in drift, non in RAM. RAM consumata dal modulo tracking: ~ finestra scorrevole di 20-50 punti per il `gps_filter_pipeline` (tunnel detection, smoothing). Circa 10 KB costanti.
- Metriche live aggiornate in RAM (struct piccola).

### 8.4 Wake locks

- Foreground service Android detiene wake lock del CPU per ricezione GPS (richiesto dal framework). No wake lock addizionale.

---

## Sezione 9 -- Interfaccia con moduli vicini

### 9.1 Verso `sync`

- Il modulo tracking scrive in `activities` con `sync_state = pending`.
- Il modulo sync osserva la tabella (poll periodico o trigger event) e spedisce.
- Alla fine sync, il modulo sync aggiorna `recording_session.state = closed_synced` tramite una API interna di tracking (`TrackingApi.markRecordingSessionSynced(clientId)`) o tramite un evento consumato da tracking.
- **Decisione architetturale:** usiamo API call esplicita, non evento. Motivazione: sync sa esattamente chi deve chiamare (tracking), quindi regola dell'ascoltatore ignoto richiede chiamata diretta. Vedi overview Sezione 4.5.

### 9.2 Verso `garage`

- Tracking emette `ActivityCompletedEvent` con `motorcycle_id` e `distance_km`.
- Garage ascolta e triggera (futuro, post-sync) `recompute_motorcycle_km`. In MVP offline-first il trigger Postgres fa il lavoro a livello server; lato client il garage puo' fare calcolo ottimistico locale per UX.

### 9.3 Verso `live` (submodulo di safety)

- Se l'utente ha avviato una LiveSession prima o durante il tracking, il modulo live ascolta `Stream<TrackingState>` di tracking per ottenere punti GPS in tempo reale.
- Tracking NON sa che c'e' un live attivo. E' il modulo live che consuma i dati.

### 9.4 Verso `navigation`

- Quando l'utente sta seguendo una PlannedRoute con navigazione, Navigation chiama `TrackingApi.startRecording(...)` e Tracking parte normalmente.
- Se Navigation ordina stop (es. arrivo a destinazione), chiama `TrackingApi.stopRecording()`. Chiamata diretta, regola dell'ascoltatore ignoto.

### 9.5 Verso `ui_kit`

- `ui_kit` fornisce primitive visuali (pulsanti, indicatori). Il modulo tracking compone schermi usando `ui_kit`, ma `ui_kit` non sa nulla di tracking.

---

## Sezione 10 -- Riepilogo per implementazione

Checklist per chi implementera' (Claude Code + Lollo):

- [ ] Dichiarare package `modules/tracking` nel `melos.yaml` root.
- [ ] Implementare `TrackingModule` (manifest) in `lib/tracking.dart`.
- [ ] Definire `TrackingApi` astratta in `lib/api.dart` con tutti i metodi di Sezione 3.
- [ ] Implementare `TrackingState` sealed class + enum FSM in `lib/src/domain/tracking_state.dart` (FSM in `state_machine.md`).
- [ ] Implementare tabelle drift `RecordingSessions` e `TrackPointBuffer` (campi in `01_data_model.md` Sezioni 3 e 4).
- [ ] Implementare repository per le due tabelle.
- [ ] Implementare `TrackingController` con orchestrazione FSM.
- [ ] Implementare `GpsFilterPipeline` (dettaglio filtri in `gps_filters.md`).
- [ ] Implementare `BufferToActivity` converter.
- [ ] Implementare `RecoveryService` con `checkRecovery()` e `applyRecovery()`.
- [ ] Setup `flutter_background_service` Android (foreground service + notifica).
- [ ] UI: RecordingScreen, RecoveryDialog, widgets.
- [ ] Test: domain (metrics, FSM transitions) unit; persistence integration con drift in-memory; application con mock geolocator.

---

## Sezione 11 -- Note a futuro

Cose non implementate ora ma per le quali il design e' compatibile:

- **Isolate Dart dedicato al tracking** (vedi open question C.5). Il buffer e' gia' in drift, la FSM e' gia' separata in `application/`, quindi isolarlo significa spostare `TrackingController` in un isolate separato comunicante via port. Zero cambi al domain o alla persistenza.
- **Crash detection** (B.5). Se un giorno si decidera' di raccogliere accelerometro passivo, il pipeline GPS puo' essere esteso senza toccare la FSM.
- **Multi-device live tracking** (C.3). Richiederebbe che la RecordingSession sia sincronizzata con backend. Oggi non lo e'. Quando sara', aggiunta di flag `remote_mirrored` sulla session e sync incrementale dei punti via Realtime.
- **Riprendi tracciamento dopo recovery** (sub-decisione A.3). Preparato il terreno in Sezione 7.5.

---

## Sezione 12 -- Battery strategy

Per un'app GPS che gira in background, la batteria **non e' un edge case: e' una feature principale**. Un'app percepita come "mangia batteria" genera recensioni 1-stella e churn alto. Questa sezione formalizza la strategia pro-attiva.

### 12.1 Profilo di consumo stimato

Valori stimati su hardware moderno (Android 12+, iPhone 11+), condizioni standard:

| Configurazione | Consumo stimato |
|---|---|
| Tracking attivo (solo GPS 1Hz + foreground service + notifica) | 1.5 - 2.5 %/h |
| Tracking + Navigation attiva (Mapbox rendering + TTS) | 6 - 10 %/h |
| Tracking + LiveSession (Realtime upload punti) | 3 - 4 %/h |
| Tracking + Navigation + LiveSession (scenario peggiore) | 10 - 15 %/h |

Valori da **validare empiricamente** in beta. Documentare in `04_tracking/edge_cases.md` checklist QA.

### 12.2 Comunicazione pre-ride

Al primo `startRecording()` della giornata (o dopo 24h dall'ultimo warning), mostrare tooltip non intrusivo:

> "Il tracking usa il GPS continuativamente. Consumo stimato: ~2% batteria all'ora. Se userai anche la navigazione, considera un caricatore."

Lingua adattata, tono informativo non allarmistico. Chiudibile. Non ripetere entro 24h.

**Onboarding**: includere una sezione "come preparare il telefono per lunghi giri" con suggerimenti: caricatore USB in moto, luminosita' auto, modalita' aereo se non serve social.

### 12.3 Soglie e comportamenti runtime

| Livello batteria | Azione |
|---|---|
| >= 30% | Nessuna azione. Tracking normale. |
| < 30%, > 15% | Icona batteria gialla nel banner tracking. Nessun'altra azione. |
| <= 15%, > 5% | Notifica soft: "Batteria al {N}%. Considera di ridurre la frequenza GPS per estendere la durata." + CTA "Attiva modalita' risparmio". |
| <= 5%, > 3% | Notifica strong: "Batteria critica al {N}%. Se il telefono si spegne, il tuo giro e' salvato localmente ma la navigazione si interrompera'." |
| <= 3% | Vedi A.20 (aperta). Proposta Claude: auto-stop con salvataggio Activity. |

### 12.4 Battery saver mode (setting utente)

Toggle in settings (modulo 12, `SettingsApi.setBatterySaverMode`):

- **Off** (default): GPS 1Hz, tutto attivo.
- **On**: GPS 0.5Hz (1 punto ogni 2s), background service low-priority, riduzione aggiornamento UI metriche da 1Hz a 0.5Hz.

Effetti misurabili: ~30% di consumo in meno, accuratezza polyline leggermente ridotta (accettabile per i giri dove l'utente vuole solo tenere traccia senza precisione millimetrica).

**Auto-enable battery saver**: se batteria all'avvio tracking <= 30% E l'utente non ha mai disattivato manualmente il saver, attivalo in automatico con toast "Modalita' risparmio attivata per batteria scarsa."

### 12.5 Feedback post-ride

Al termine di una Activity, mostrare in dettaglio la statistica:

> "Questo giro ha usato circa il {N}% della batteria ({N/duration}%/h)."

L'utente impara il profilo reale del suo device. Se il consumo e' significativamente superiore allo stimato (> 1.5x), suggerire diagnostica:

> "Il consumo e' piu' alto del previsto. Cause frequenti: luminosita' alta, molte app in background, GPS scadente. Verifica le impostazioni."

### 12.6 Interazione con OS battery optimization

Gia' trattato in `04_tracking/edge_cases.md` Sezione 2 (ROM custom Android aggressive). Qui solo nota: **la battery strategy dell'app e' complementare alle esenzioni OS**. L'utente deve fare entrambe le cose. Onboarding lo chiarisce.

### 12.7 Open items specifici batteria

- Valori esatti soglie (15%, 5%, 3%) da confermare con test reali.
- Battery saver: riduzione GPS a 0.5Hz o anche disabilitare calcoli di derivate (max speed)?
- Auto-enable battery saver in condizioni estreme: quanto essere aggressivi?
- Tracking su device molto vecchi (pre-2020): profilo consumo puo' essere peggiore del 2x. Serve testing specifico.

**Legame con A.20:** la decisione sull'auto-stop al 3% va presa insieme a questa strategia. Se l'utente ha battery saver attivo + warning chiari a 15%/5%, l'auto-stop al 3% e' un failsafe finale, non una sorpresa.

---

**Fine 04_tracking/L0_architecture.md**
