# 04 / Tracking -- Edge Cases

**Scopo:** catalogo dei casi limite e scenari di errore del modulo tracking, con comportamento atteso per ciascuno. Checklist per testing e riferimento per l'implementazione difensiva.

**Riferimenti:**

- FSM: `state_machine.md`.
- Filtri GPS: `gps_filters.md`.
- API: `L05_interfaces.md`.

**Formato:** ogni edge case ha: **scenario**, **cosa succede di default**, **cosa dovrebbe succedere**, **implementazione**. Se il comportamento default e' gia' corretto, lo diciamo esplicitamente.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Permessi OS

### 1.1 Permesso location foreground negato al primo start

**Scenario:** utente primo avvio app, tap "Start recording", sistema chiede permesso location, utente rifiuta.

**Default:** `geolocator.requestPermission()` ritorna `denied`.

**Atteso:**
- `startRecording()` ritorna `Err(PermissionDeniedError(locationForeground))`.
- RecordingSession NON creata.
- UI mostra dialog "Per registrare un'uscita serve l'accesso alla posizione. Apri impostazioni?"
- CTA porta a `Geolocator.openLocationSettings()` o `openAppSettings()`.

**Implementazione:** controller verifica permessi in `startRecording` PRIMA di creare la session.

### 1.2 Permesso location background negato

**Scenario:** Android 10+ richiede permesso "Allow all the time" separato per background. Utente ha concesso "Only while using the app" ma non background.

**Default:** se `geolocator` in foreground service tenta di girare con permesso solo foreground, su alcune Android puo' comunque funzionare finche' app in foreground, poi ferma senza errore visibile.

**Atteso:**
- Al primo `startRecording`, verifichiamo permesso background.
- Se mancante: startRecording ritorna `PermissionDeniedError(locationBackground)`.
- UI mostra spiegazione "Per tracciare anche quando metti il telefono in tasca, serve concedere 'sempre'. Apri impostazioni?"

**Implementazione:** nel controller, oltre a `checkPermission()`, chiamare `Permission.locationAlways.status` (pacchetto `permission_handler`). Se `.denied` o `.limited`, dichiarare errore.

**Edge aggiuntivo:** utente concede "Always" poi lo revoca mid-ride. Il foreground service continua con quello che gli era stato dato. Alla prossima apertura app, il check mostrera' stato denied e pusheremo utente a riattivare. La registrazione in corso non viene interrotta (OS gestisce).

### 1.3 Permesso notifiche negato (Android 13+)

**Scenario:** Android 13 richiede `POST_NOTIFICATIONS` per foreground service. Se negato, il foreground service parte ma senza notifica visibile -- OS dopo qualche minuto killa il servizio.

**Default:** servizio viene killato silenziosamente dopo ~5 minuti. Utente vede tracking fermato senza capire perche'.

**Atteso:**
- `startRecording` verifica `Permission.notification.status` (Android 13+).
- Se `.denied`: `PermissionDeniedError(notification)`.
- UI spiega "L'app ha bisogno di mostrare una notifica mentre registri, altrimenti il tracking si ferma. Concedi permesso?"

**Implementazione:** pacchetto `permission_handler` con target sdk 33+. `Permission.notification.request()`.

### 1.4 Location services disattivati a livello OS

**Scenario:** utente ha disattivato "Location" nelle impostazioni sistema. Permesso all'app e' concesso ma GPS globale e' off.

**Default:** `geolocator.getPositionStream` emette errori `LocationServiceDisabledException`.

**Atteso:**
- Pre-check con `Geolocator.isLocationServiceEnabled()` prima di startRecording.
- Se disabilitato: `PermissionDeniedError(locationForeground)` con messaggio specifico "Attiva la localizzazione nelle impostazioni del dispositivo".
- Deep link a `Geolocator.openLocationSettings()`.

### 1.5 Permessi revocati mid-recording

**Scenario:** registrazione in corso, utente apre impostazioni, revoca permesso location.

**Default:** stream GPS smette di emettere punti. Nessun errore esplicito.

**Atteso:**
- Il timer signal_lost scatta dopo 15s senza punti.
- FSM va in `recording_signal_lost`.
- Ma questa volta *non* ricevera' mai un punto valido di ripresa.
- Al prossimo foreground app: controllo permessi, se revocati: notifica UI "Permessi revocati, registrazione in pausa. Ri-concedi e tocca per riprendere."
- La registrazione NON viene chiusa automaticamente -- l'utente deve decidere (salvare, scartare, riprovare).

**Implementazione:** listener su `Permission.location.status` cambia; se scende, emit `RecordingStateChangedEvent` con transition_reason = `permission_revoked`. UI reagisce.

---

## Sezione 2 -- ROM custom Android (battery optimization)

Vedi overview Sezione 5.4 e riferimento dontkillmyapp.com.

### 2.1 MIUI (Xiaomi) aggressive battery killer

**Scenario:** utente su Xiaomi con MIUI 13+. Avvia tracking, mette telefono in tasca. MIUI killa il foreground service dopo 10-30 minuti nonostante tutto.

**Default:** tracking si ferma. Drift buffer ha solo i primi 30 min. Utente non si accorge fino a stop.

**Atteso:**
- Onboarding rileva `Build.MANUFACTURER == "Xiaomi"` (o altro vendor in lista) -> mostra warning pre-first-recording.
- CTA "Apri impostazioni batteria" -> deep link alla pagina MIUI specifica.
- Dopo onboarding, flag `user_acknowledged_battery_warning_<vendor>=true` su profiles.feature_flags. Non ri-mostrare.
- Se al primo stop il tracking ha durato < 10% del tempo che l'utente pensava (check euristico), mostra nota "Il tracking puo' essersi interrotto, vuoi verificare le impostazioni batteria?".

**Implementazione:**
- Pacchetto `device_info_plus` per rilevare vendor.
- Tabella vendor -> intent deep link (manutenuta manualmente, dontkillmyapp.com come riferimento).
- UI componente `BatteryOptimizationWarning` riusabile.

### 2.2 Samsung One UI

**Scenario:** simile a MIUI. Samsung ha "Put app to sleep", "Deep sleep". Default puo' essere "on" per app poco usate.

**Atteso:** come 2.1, con deep link specifico Samsung.

### 2.3 Huawei EMUI / Magic UI

**Scenario:** simile. Huawei + EMUI ha "Protected apps" da attivare manualmente.

**Atteso:** come 2.1.

### 2.4 Android stock / Google Pixel

**Scenario:** battery optimization piu' permissiva, ma puo' comunque mettere l'app in "Restricted" se utente manualmente.

**Atteso:**
- Check `PowerManager.isIgnoringBatteryOptimizations(packageName)`.
- Se `false` e siamo in Android stock: chiedere all'utente di esentare l'app via `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`.
- Meno aggressivo del warning MIUI perche' stock funziona decentemente anche senza esenzione.

### 2.5 Tutti i vendor, foreground service ucciso mid-ride

**Scenario:** nonostante tutto, OS killa il servizio.

**Default:** il buffer drift ha i punti fino all'istante del kill. La `recording_session.state` resta `active`.

**Atteso:**
- Al prossimo avvio app, check_recovery trova la session attiva -> dialog di recovery (vedi FSM 3.9).
- Utente decide: salva incompleta / scarta.
- L'app non sa precisamente quando il kill e' avvenuto. `lastPointAt` nel RecoveryProposal da' un indizio utile ("la registrazione si e' interrotta alle 14:32").

**Questo e' esattamente il caso per cui esiste la scrittura progressiva in drift (overview Sezione 5.11).** Non perdiamo l'intero giro.

---

## Sezione 3 -- Storage e risorse

### 3.1 Storage dispositivo pieno

**Scenario:** utente ha pochissimo storage residuo. Drift tenta INSERT nel track_point_buffer e fallisce con `SQLITE_FULL`.

**Default:** `drift` lancia `SqliteException`. Se non catturato in controller, crash.

**Atteso:**
- Controller cattura la exception in `GpsFilterPipeline.apply()` durante la scrittura del punto.
- Primo fallimento: log error + continua (il prossimo punto ripotrebbe andare bene, il file system puo' aver liberato spazio tra un sec e l'altro).
- Se 3 insert falliti consecutivi -> emit `StorageFullError` via `TrackingError`. FSM transiziona a un stato simile a `recording_manual_paused` (interno) + UI alert "Spazio esaurito. Libera spazio o ferma registrazione."
- Niente auto-stop: l'utente decide (salva quello che c'e' + stop, oppure libera storage e riprende).

**Implementazione:** try/catch attorno alle INSERT nel `TrackPointBufferRepository`. Counter `_consecutiveInsertFailures` nel controller.

### 3.2 Buffer drift molto grande (giri multi-giorno)

**Scenario:** utente tiene il tracking attivo per 10+ ore senza stop. Buffer accumulato: 36.000+ punti.

**Default:** nessun problema. SQLite gestisce milioni di righe senza degrado.

**Atteso:** alla chiusura (`buffer_to_activity`), la conversione e' lenta (decode + calcolo metriche + encoding polyline). UI mostra progress "Salvataggio in corso...".

**Mitigazione automatica:** per registrazioni > 6h, applicare decimazione (vedi D.24): `INSERT only 1 punto ogni 2 secondi invece di 1/1s`. Decisione applicata dal `GpsFilterPipeline` quando `(now - session.started_at) > 6h`. Marker nel buffer: `point_state = normal` invariato; semplicemente meno punti.

### 3.3 RAM pressure sul background isolate

**Scenario:** OS scarso di RAM, background isolate killato.

**Default:** quando torna in foreground, l'app deve decidere cosa fare.

**Atteso:**
- Alla prossima apertura app, `check_recovery` trova session active -> dialog recovery.
- Stesso pattern del kill OS (vedi 2.5).

---

## Sezione 4 -- FSM e race conditions

### 4.1 Doppio tap rapido su "Start"

**Scenario:** utente tappa "Start" due volte in 100ms.

**Default:** due invocazioni di `startRecording` in parallelo possono creare due RecordingSession.

**Atteso:**
- `TrackingController` ha un mutex interno (`_operationLock`). Operazioni start/stop/pause/resume sono serializzate.
- Seconda invocazione aspetta la prima. Al termine della prima, la seconda vede `fsm.state == recording_active` e ritorna `AnotherSessionActiveError`.

**Implementazione:** `Lock` da pacchetto `synchronized` Dart, o `Completer` manuale.

### 4.2 Punto GPS in arrivo mentre FSM e' in `closing`

**Scenario:** utente tappa stop. FSM va `recording_active -> closing`. Mentre `buffer_to_activity` sta lavorando, il GPS emette un ultimo punto.

**Default:** il pipeline tenta di scrivere nel buffer, ma la session potrebbe essere gia' `closed_unsynced`.

**Atteso:**
- Il `GpsFilterPipeline` controlla `controller.currentState`. Se diverso da un `recording_*`, DROP silenzioso.
- Quindi i punti in volo durante closing vengono scartati. Non compaiono nell'Activity finale. Accettabile -- e' il tratto "ultimissimo" di ride.

**Alternativa scartata:** "includi gli ultimi punti in closing" richiederebbe sincronizzazione pesante. Non vale.

### 4.3 Stop chiamato durante gia' closing

**Scenario:** utente tappa stop due volte. Prima invocazione in corso, seconda arriva prima del completamento.

**Default:** due invocazioni di `buffer_to_activity` in parallelo -> possibile INSERT duplicata di Activity.

**Atteso:**
- `_operationLock` previene. Seconda chiamata attende.
- Al termine della prima, fsm.state e' `idle` (activity creata). Seconda invocazione vede `NoActiveRecordingError`.

### 4.4 Buffer_to_activity crash a meta'

**Scenario:** durante conversion (transazione drift), eccezione non gestita.

**Atteso:**
- Transazione drift rollback automatico. Activity NON inserita.
- FSM resta in `closing`.
- Retry automatico fino a 3 volte (documentato in FSM 3.7).
- Dopo 3 fallimenti: session resta `active`, fsm torna `idle`, recordign_session non modificata. Al prossimo bootstrap: dialog recovery.

**Implementazione:** try/catch esplicito attorno a `db.transaction()`. Counter `_conversionRetries`.

### 4.5 App terminata durante `closing`

**Scenario:** utente tappa stop, OS killa app prima che la transazione drift completi.

**Default:** transazione drift rollback automatico (SQLite garantisce).

**Atteso:**
- Al prossimo avvio: recording_session ancora `active` -> dialog recovery.
- Il tratto registrato fino al tap di stop e' intatto nel buffer.
- Utente puo' salvare di nuovo.

### 4.6 User logout durante registrazione

**Scenario:** utente apre settings, fa logout. Registrazione in corso.

**Atteso:**
- Il modulo auth emette `UserLoggedOutEvent`.
- Tracking ascolta, transiziona a `recording_manual_paused` (vedi state_machine 3.10).
- UI warning "Hai una registrazione in corso. Vuoi salvarla prima di uscire?"
- Utente puo' scegliere: "Salva e esci" (stop + logout) oppure "Annulla logout" (resume ride).
- Se utente forza logout comunque: la session resta in DB con state=active, motorcycle_id potrebbe non essere piu' valido. Al prossimo login, se **stesso utente**, vede recovery dialog. Se **utente diverso**: la session e' filtrata (RLS applicativo lato drift: `WHERE owner_id = currentUserId`).

**Caso borderline:** utente A logout, utente B login, poi utente A ri-login. La sua session e' ancora li', recovery appare. OK.

---

## Sezione 5 -- Input malformati / edge GPS

### 5.1 GPS primo fix ritardato

**Scenario:** utente tappa start, GPS impiega 30 secondi a dare il primo fix valido (cielo coperto).

**Default:** FSM in `recording_active` ma nessun punto scritto per 30s.

**Atteso:**
- Signal lost timer scatta a 15s. Ma velocita' recente = 0 (nessun punto ancora). Check "velocity_pre_perdita > 20 km/h" fallisce -> NON emettiamo signal_lost.
- Restiamo in `recording_active` senza punti. UI mostra "Ricerca GPS..." (Stream metriche include `lastAccuracyM = null`).
- Al primo punto valido, inizia registrazione normale.

**UI responsability:** bolla "GPS non ancora acquisito, attendi qualche secondo" visibile finche' `lastAccuracyM == null`.

### 5.2 GPS drift anomalo (punti fantasma a distanza)

**Scenario:** GPS (bug raro) riporta un punto a 500km di distanza con accuracy = 5m.

**Default:** velocity implied = 500 km / 1s = enorme. Viene scartato dal filtro velocity sanity (Sezione 3.1 gps_filters).

**Atteso:** il punto passa quality (accuracy OK) ma fallisce velocity sanity -> drop. Il prossimo punto legittimo passa.

### 5.3 GPS cambia improvvisamente quota di +1000m

**Scenario:** sensore barometrico sbaglia, altitudine passa da 200m a 1200m in 1 secondo.

**Default:** il punto viene scritto. L'elevation_gain_m finale sara' gonfiato.

**Atteso:**
- MVP: nessun filtro specifico sull'altitudine. `elevation_gain_m` e' "best effort".
- Futuro: filtro sanity sulla velocita' verticale (max 20 m/s). Se supera, usare altitude null o ignorare delta per quel punto.

Documentato come "limite noto MVP".

### 5.4 Clock del dispositivo cambia mid-recording

**Scenario:** utente cambia timezone (viaggio internazionale). OS aggiorna clock. `captured_at` di punti successivi puo' essere discontinuo (salto di +/-2h).

**Default:** buffer contiene timestamp con salto. `duration_seconds` calcolato come `ended_at - started_at` sbaglia di 2h.

**Atteso:**
- Usare **clock monotonic** (`DateTime.now().millisecondsSinceEpoch` NO; `Stopwatch` o `Platform.clockTickFrequency` SI) per calcolo durata effettiva.
- `captured_at` dei punti resta quello del sensore (utile per debug ma non per metriche).
- `started_at`, `ended_at` calcolati da monotonic clock + offset iniziale.

**Implementazione:** al momento di `startRecording`, salvare `monotonic_start_ns = Stopwatch().elapsed`. Ogni punto calcola `captured_at_offset_ns = monotonic_now - monotonic_start_ns`. `started_at` wall-clock usato solo per display. Metriche usano monotonic offsets.

**Compromesso:** questo e' over-engineering per MVP. Proposta alternativa: usare wall-clock e documentare "non cambiare timezone mid-ride". Decisione aperta: vedi Sezione 7.

### 5.5 Moto scelta all'avvio poi cancellata

**Scenario:** utente avvia tracking con moto X. Apre garage, cancella moto X. Continua a guidare.

**Default:** al closing, `motorcycle_id` nell'Activity e' client_id di una moto soft-deleted.

**Atteso:**
- MotorcycleApi deve ammettere che "exists" consideri anche soft-deleted? Proposta: NO. Se la moto e' soft-deleted, `exists()` ritorna false.
- Ma durante tracking il check non avviene piu' -- e' gia' stato fatto allo start.
- Alla chiusura: `buffer_to_activity` inserisce l'Activity con `motorcycle_id` soft-deleted. Il FK Postgres ammette (soft delete = colonna `deleted_at`, FK non rompe). Trigger `recompute_motorcycle_km` aggiornera' comunque la moto (anche soft-deleted riceve km).

**Edge borderline ma gestito.** Impatto: l'utente vede una moto "eliminata" che ha ancora km riferiti. Nella UI garage, moto con `deleted_at NOT NULL` sono nascoste -> utente non le vede con km strani. OK.

### 5.6 Utente avvia tracking senza aver mai creato una moto

**Scenario:** primo avvio app, utente non ha ancora creato moto. Tappa "Start recording".

**Default:** `StartRecordingRequest.motorcycleClientId = null`.

**Atteso:**
- Questo e' ammesso (il campo e' nullable).
- Activity creata con `motorcycle_id = null`.
- Post-creation UI suggerisce "Non hai collegato una moto. Vuoi farlo ora?" -> flow di modifica activity + creazione moto.

---

## Sezione 6 -- UI / UX edge

### 6.1 Utente chiude app mentre FSM e' recording_active

**Scenario:** utente swipe-kill l'app dalla recent apps mentre il tracking e' attivo.

**Default dipende dal vendor:**
- Stock Android: foreground service continua (separato dal task UI).
- MIUI / One UI aggressivi: servizio killato insieme al task.

**Atteso:**
- Se servizio continua: nessun problema, al prossimo foreground l'app ri-connette al servizio e vede stato recording_active.
- Se servizio killato: vedi 2.5 -> recovery al prossimo avvio.

### 6.2 Low battery critica durante ride

**Scenario:** batteria scende sotto 3%.

**Atteso:**
- Modulo tracking ascolta livello batteria via `battery_plus`.
- Al 10% (soft warning): notifica non intrusiva "Batteria al 10%, considera di ricaricare".
- Al 5%: notifica piu' forte + suggerimento "Vuoi che fermi il tracking per salvare batteria?" (l'utente decide).
- Al 3% (hard): auto-stop con salvataggio Activity. Notifica "Tracking fermato per batteria critica. Activity salvata."

Questa e' feature sensibile: fermare automaticamente significa prendere decisione per l'utente. Alternativa: mai auto-stop, solo avviso. **Decisione aperta** -> aggiungere ad open_questions.

### 6.3 Dispositivo si spegne hard (batteria a zero senza warning)

**Scenario:** batteria a zero istantaneo (vecchia batteria), device si spegne.

**Default:** recording_session resta `active` in drift. Punti fino al momento dello spegnimento sono salvati.

**Atteso:** alla riaccensione + avvio app, recovery dialog standard.

---

## Sezione 7 -- Open items specifici tracking

Da aggiungere a `99_open_questions.md`:

- **Clock monotonic vs wall-clock per durate** (vedi 5.4). Proposta: wall-clock per MVP con disclaimer. Upgrade a monotonic se emerge caso reale.
- **Auto-stop per batteria critica a 3%** (vedi 6.2). Default proposto: solo avviso, mai auto-stop.
- **Gestione accuracy_m costantemente scadente** (vedi 5.1 edge): se per 5 minuti consecutivi tutti i punti vengono droppati per low quality, cosa fa il modulo? Notifica UI "GPS scadente, considera di riposizionare telefono"?

---

## Sezione 8 -- Checklist per QA / beta test

Scenari da provare manualmente prima di rilascio:

- [ ] Start senza permessi location foreground.
- [ ] Start senza permessi location background (Android 10+).
- [ ] Start senza permessi notifica (Android 13+).
- [ ] Start con location services OS disattivati.
- [ ] Registrazione di 5 minuti in stock Android.
- [ ] Registrazione di 5 minuti in Xiaomi/Samsung/Huawei (possibilmente).
- [ ] Ride con 3+ semafori (verifica auto-pause/resume).
- [ ] Ride con 1+ galleria (verifica tunnel_entry/exit).
- [ ] Ride di 8+ ore (verifica decimazione attiva).
- [ ] Kill app mid-ride + recovery.
- [ ] Kill foreground service (via settings) mid-ride + recovery.
- [ ] Storage pieno simulato.
- [ ] Batteria bassa (sotto 10%) warning.
- [ ] Logout mid-ride.
- [ ] Cancellazione moto mid-ride.
- [ ] Avvio senza moto.
- [ ] Cambio timezone mid-ride.

---

**Fine 04_tracking/edge_cases.md**
