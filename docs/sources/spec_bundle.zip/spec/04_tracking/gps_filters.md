# 04 / Tracking -- GPS Filters

**Scopo:** specifica algoritmica del `GpsFilterPipeline`: come ogni punto GPS ricevuto viene valutato e classificato, come vengono rilevati auto-pause, signal lost, tunnel.

**Cosa NON e' qui:**

- Transizioni FSM (vivono in `state_machine.md`).
- Persistenza dei punti (in `03_local_db.md` Sezione 5.2).
- Edge case non-filter (in `edge_cases.md`).

**Dove vive il codice:** `modules/tracking/lib/src/application/gps_filter_pipeline.dart` + funzioni pure helper in `modules/tracking/lib/src/domain/`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Pipeline overview

Ad ogni `Position` ricevuta dal `geolocator`, il pipeline esegue una sequenza di step. Ogni step puo' produrre un **verdetto**:

- **`accept`**: il punto viene scritto nel buffer come `normal` (o marker appropriato).
- **`drop_low_quality`**: il punto viene scartato, nessuna scrittura.
- **`transition_auto_pause`**: triggera transizione FSM `recording_active -> recording_auto_paused`, scrive `paused_marker`.
- **`transition_auto_resume`**: triggera FSM `recording_auto_paused -> recording_active`, scrive `recovered_marker`.
- **`signal_lost`**: triggera FSM `recording_active -> recording_signal_lost`, scrive `tunnel_entry`. (Nota: il vero trigger avviene da un timer, non da un punto ricevuto. Vedi 5.)
- **`signal_recovered`**: triggera FSM `recording_signal_lost -> recording_active`, scrive `tunnel_exit` + il punto corrente come `normal`.

**Sequenza degli step:**

```
 raw_position
      |
      v
[1. Quality filter]   -> drop_low_quality / continue
      |
      v
[2. Velocity sanity]  -> drop_low_quality / continue
      |
      v
[3. State router]     -> decide cosa fare in base a stato FSM corrente
      |
      +-- recording_active:        [4a. Auto-pause detection] -> transition_auto_pause / accept
      +-- recording_auto_paused:   [4b. Motion detection]     -> transition_auto_resume / drop
      +-- recording_manual_paused: drop (always)
      +-- recording_signal_lost:   signal_recovered (always, primo punto valido)
      +-- altri stati:             drop (non dovrebbe mai succedere, log warning)
```

Il pipeline e' implementato come una sequenza di filtri componibili (pattern "chain of responsibility"). Ogni filtro ha signature:

```dart
abstract class GpsFilter {
  FilterVerdict apply(PositionInput input, FilterContext ctx);
}
```

`FilterContext` contiene finestra scorrevole degli ultimi N punti e stato FSM corrente.

---

## Sezione 2 -- Quality filter (step 1)

**Scopo:** scartare punti con accuracy inutilizzabile.

### 2.1 Soglia `accuracy_m`

- Se `accuracy_m > ACCURACY_MAX_M` -> `drop_low_quality`.
- Default: `ACCURACY_MAX_M = 50` metri.

**Razionale:** un punto con accuracy 100m puo' essere spostato di 100m in qualsiasi direzione -- lo scartiamo per evitare polyline a zigzag. Accuracy tra 5-20m e' GPS buono; 30-50m e' GPS urbano denso o foresta, accettabile.

**Nota sul primo fix:** quando l'app inizia a ricevere punti dopo startRecording, i primi 1-3 punti possono avere `accuracy > 50m` perche' il GPS sta ancora "convergendo". Il filter li scarta, il che e' corretto. La FSM resta in `recording_active` aspettando un punto valido. Se passano > 15 secondi senza punti validi, entra in `signal_lost` (vedi Sezione 5).

### 2.2 Null safety

- Se `latitude`, `longitude` o `captured_at` sono null -> drop.
- Se `accuracy_m` e' null -> trattiamo come accuracy "sconosciuta": accettiamo ma non usiamo per filtri successivi.

### 2.3 Altitudine / speed / heading

Null ammessi. Non sono critici per il tracciato. Vengono persistiti se presenti, null altrimenti.

---

## Sezione 3 -- Velocity sanity filter (step 2)

**Scopo:** scartare punti con velocita' implausibile per una moto su strada aperta.

### 3.1 Soglia velocita'

- Se `speed_ms > MAX_REASONABLE_SPEED_MS` -> `drop_low_quality`.
- Default: `MAX_REASONABLE_SPEED_MS = 90` m/s (324 km/h).

**Razionale:** oltre i 324 km/h un punto e' sicuramente noise. Scelta larga per non scartare picchi legittimi (autostrada Germania, pista chiusa). Strava usa soglie simili.

### 3.2 Salti spaziali improvvisi

Aggiuntivo al check velocita' sensore, controlliamo spostamento vs ultimo punto:

- `delta_distance = haversine(ultimo_punto_normal, current)`.
- `delta_time = current.captured_at - ultimo_punto_normal.captured_at`.
- `implied_speed_ms = delta_distance / delta_time`.
- Se `implied_speed_ms > MAX_REASONABLE_SPEED_MS` (stessa soglia) -> drop.

Questo cattura il caso in cui il GPS, uscendo da un'area problematica, ci "teletrasporta" di 500m in 2 secondi.

**Finestra osservazione:** ultimo punto normal nel `FilterContext.recentPoints`. Non serve persistenza aggiuntiva -- il buffer di 10-20 punti e' gia' in RAM nel controller.

### 3.3 Primi punti della registrazione

Se non c'e' ancora un punto normal nel buffer (prima registrazione appena iniziata), skip del check 3.2. Passa direttamente il 3.1.

---

## Sezione 4 -- Auto-pause detection (step 4a)

**Scopo:** quando l'utente si ferma (semaforo lungo, sosta non dichiarata), transizione automatica a `recording_auto_paused` cosi' le metriche (distance, avg_speed) non si gonfiano con pause implicite.

**Proposta parametri (A.4 aperta, in attesa Lollo):**

- **`AUTO_PAUSE_SPEED_KMH`**: 1 km/h (0.28 m/s).
- **`AUTO_PAUSE_DURATION_S`**: 30 secondi.
- **`AUTO_PAUSE_WINDOW_SAMPLES`**: 30 campioni consecutivi (a 1Hz corrisponde a 30s).

### 4.1 Algoritmo

Mantieni contatore `_slowCount` nel pipeline (azzerato all'entrata in recording_active).

```
On each accepted point in recording_active:
  if (point.speed_kmh < AUTO_PAUSE_SPEED_KMH):
    _slowCount += 1
    if (_slowCount >= AUTO_PAUSE_WINDOW_SAMPLES):
      emit transition_auto_pause
      _slowCount = 0
  else:
    _slowCount = 0
```

**Nota:** l'auto-pause viene triggerata **dopo** che 30 punti consecutivi hanno speed<1 km/h. Tutti e 30 vengono scritti nel buffer come `normal` (sono punti veri, non finti). Il marker `paused_marker` viene inserito al momento della transizione, con lat/lon uguali all'ultimo punto normal.

**Edge case:** se `speed_kmh` e' null (sensore non ha dato il valore), usiamo il calcolo implicito `distanza_vs_ultimo / delta_t`. Se anche questo e' null (primo punto), trattiamo come "non slow" -- _slowCount resta a zero.

### 4.2 Motion detection per auto-resume (step 4b)

Simmetrico. Quando siamo in `recording_auto_paused`:

```
On each incoming point:
  if (point.speed_kmh > AUTO_PAUSE_SPEED_KMH):
    _movingCount += 1
    if (_movingCount >= MOTION_DETECT_WINDOW_SAMPLES):
      emit transition_auto_resume
      _movingCount = 0
  else:
    _movingCount = 0
```

- **`MOTION_DETECT_WINDOW_SAMPLES`**: 3 campioni consecutivi (3s a 1Hz).

**Razionale asimmetrico:** per entrare in pause serviamo certezza (30s -> minimizziamo falsi positivi). Per uscire da pause basta poca certezza (3s -> minimizziamo latenza). L'utente che riparte non deve aspettare 30 secondi prima che il tracking torni attivo.

### 4.3 Punti durante auto-pause

I punti ricevuti durante `recording_auto_paused` **non vengono scritti nel buffer**. Vengono letti solo per valutare se triggerare auto-resume. Questo evita di gonfiare il buffer con punti inutili (ora di sosta al bar -> 3600 punti).

### 4.4 Configurabilita' futura

I parametri vivono in una classe `GpsFilterConfig` passata al costruttore del pipeline. Default sopra. Test override a piacere. In futuro, feature flag sul `profile` potrebbe rendere i valori configurabili per utente (opzioni power user).

---

## Sezione 5 -- Signal lost detection

**Scopo:** quando il GPS smette di fornire punti (tunnel, canyon profondo, interferenza), transizione a `recording_signal_lost`. Inserisce marker `tunnel_entry` prima della perdita e `tunnel_exit` alla ricomparsa.

### 5.1 Il trigger NON e' un punto

Signal lost si rileva dalla **mancanza** di punti, non dalla loro ricezione. Serve un **timer**.

Il `TrackingController` avvia un timer quando la FSM entra in `recording_active`:

```
timer = Timer.periodic(1s) {
  if (now - lastAcceptedPointAt > SIGNAL_LOST_TIMEOUT_S) {
    if (fsm.state == recording_active) {
      emit signal_lost
    }
  }
}
```

**Proposta parametri (A.5 aperta):**

- **`SIGNAL_LOST_TIMEOUT_S`**: 15 secondi senza punti accettati.

### 5.2 Condizione aggiuntiva: velocity pre-perdita

Non tutti i "15 secondi di silenzio" sono tunnel. Se l'utente e' in pausa (parcheggio coperto), il GPS potrebbe zittirsi. Ma non e' un tunnel.

**Check aggiuntivo:** prima di dichiarare signal_lost, verifica lo stato GPS recente:

```
recent_speed = average(recentPoints.last 10, field: speed_kmh)
if recent_speed > SIGNAL_LOST_MIN_SPEED_KMH and signal_missing > SIGNAL_LOST_TIMEOUT_S:
  emit signal_lost with point_state = tunnel_entry
```

- **`SIGNAL_LOST_MIN_SPEED_KMH`**: 20 km/h (stava guidando, non era fermo).

Se `recent_speed < 20 km/h`, NON emettiamo signal_lost. La mancanza e' probabilmente causata da utente fermo in area coperta -- auto-pause e' una migliore lettura.

**Edge case:** auto-pause e signal_lost in competizione. Se durante una ride veloce il GPS sparisce per 30 secondi, dovremmo avere signal_lost triggered a 15s. L'auto-pause non scatta perche' non abbiamo punti ricevuti per alimentare `_slowCount`. OK, signal_lost vince.

### 5.3 Inserimento `tunnel_entry`

Al momento del trigger signal_lost:

```
tunnel_entry_point = TrackPoint {
  captured_at: lastAcceptedPointAt, // non now -- il tunnel e' iniziato al silenzio
  lat, lon: lastAcceptedPoint.lat, lastAcceptedPoint.lon,
  point_state: tunnel_entry
}
insertIntoBuffer(tunnel_entry_point)
```

### 5.4 Signal recovered

Quando, essendo in `recording_signal_lost`, arriva un punto valido (passa il quality filter), il filter:

1. Inserisce marker `tunnel_exit` con lat/lon del nuovo punto e captured_at del nuovo punto.
2. Inserisce il nuovo punto stesso come `normal`.
3. Emette signal_recovered (transizione FSM -> recording_active).

Il tratto in galleria non ha punti tra `tunnel_entry` e `tunnel_exit`. In rendering polyline: interpolazione lineare tra i due (opzionalmente con stile "dashed").

### 5.5 Metriche in galleria

Le metriche ignorano il tratto `tunnel_entry -> tunnel_exit`:

- `distance_km`: **non** somma la distanza interpolata.
- `duration_seconds`: **non** conta il tempo tra entry e exit.
- `duration_total_seconds`: **si'**, conta (tempo reale trascorso).

**Tradeoff onesto:** se il tunnel e' lungo 5km, la `distance_km` della Activity sara' circa 5km inferiore rispetto al contachilometri moto. E' intenzionale: non inventiamo dati. Documentato nelle note UI ("tratti in galleria non contribuiscono alla distanza per mancanza di dati GPS").

---

## Sezione 6 -- Smoothing (opzionale, MVP no)

Non applichiamo smoothing (Kalman, moving average) sui punti in input.

**Razionale:**

- GPS moderno su smartphone e' gia' filtrato internamente dal chipset.
- Smoothing aggiuntivo sposta i punti -> distorce il tracciato rispetto alla realta'.
- Il rendering mappa (Mapbox) fa gia' anti-aliasing visuale.
- Smoothing introduce latenza (media dei recent N punti, il current viene mostrato con ritardo).

Se in futuro emerge esigenza concreta (es. tracciato zigzaga in citta' stretta), valutiamo aggiunta di smoothing a monte. Lasciato fuori MVP per semplicita'.

---

## Sezione 7 -- Parametri: tabella riepilogativa

| Parametro | Default | Sezione | Aperto in `99_open_questions.md` |
|---|---|---|---|
| `ACCURACY_MAX_M` | 50 m | 2.1 | - |
| `MAX_REASONABLE_SPEED_MS` | 90 m/s (324 km/h) | 3.1 | - |
| `AUTO_PAUSE_SPEED_KMH` | 1 km/h | 4 | A.4 |
| `AUTO_PAUSE_WINDOW_SAMPLES` | 30 (= 30s a 1Hz) | 4 | A.4 |
| `MOTION_DETECT_WINDOW_SAMPLES` | 3 (= 3s a 1Hz) | 4.2 | - |
| `SIGNAL_LOST_TIMEOUT_S` | 15 s | 5.1 | A.5 |
| `SIGNAL_LOST_MIN_SPEED_KMH` | 20 km/h | 5.2 | - |

Vivono tutti in `GpsFilterConfig` in `modules/tracking/lib/src/domain/gps_filter_config.dart`.

---

## Sezione 8 -- Casi concreti: scenari tipici

### 8.1 Partenza da casa, freddo-fix GPS

- Start premuto, primo punto arriva dopo 4s con `accuracy_m = 80` -> drop.
- Secondo punto a 5s con `accuracy_m = 35` -> accept.
- Terzo punto a 6s con `accuracy_m = 20` -> accept.
- FSM resta `recording_active` per tutto. Metriche partono da primo punto accettato.

### 8.2 Semaforo rosso ~45 secondi

- Guidando a 30 km/h, arrivo al rosso. Velocita' scende a 0.
- Primi 30 secondi con speed < 1 km/h -> `_slowCount` arriva a 30, triggera auto-pause. Marker scritto.
- Punti successivi durante rosso non scritti nel buffer.
- Verde, utente riparte. Velocita' sale a 15 km/h in 3 secondi -> `_movingCount` arriva a 3, triggera auto-resume. Marker scritto.
- Tra marker `paused_marker` e `recovered_marker` non ci sono punti -> nel rendering polyline: linea "non continua" tra i due (visivamente ok, sono nello stesso punto).

### 8.3 Tunnel 800m a 80 km/h

- Ingresso tunnel, ultimo fix valido. Timer silenzio parte.
- 15 secondi senza punti -> check velocity recente (80 km/h) > 20 km/h -> emit signal_lost. Marker `tunnel_entry` con lat/lon e timestamp del fix pre-perdita.
- Utente percorre tunnel per 35 secondi, zero punti.
- Uscita tunnel, primo fix con `accuracy_m = 25` -> passa quality filter.
- Inserisce marker `tunnel_exit` con new lat/lon, poi il punto stesso come `normal`.
- Signal recovered, FSM torna `recording_active`. Tempo totale galleria: 35s. Distance_km NON include gli 800m.

### 8.4 Pausa bar 20 minuti + partenza

- Arrivo al bar a 0 km/h -> auto-pause triggerata dopo 30s.
- Utente sta 20 minuti fermo. Punti ricevuti (se GPS fix continua): non scritti nel buffer.
- Riparte. Velocita' > 1 km/h per 3 samples -> auto-resume.
- Tra `paused_marker` (iniziale) e `recovered_marker` (finale): nessun punto scritto. Distanza 0 conta, durata 0 conta nelle metriche "effettive".
- `duration_total_seconds` invece conta i 20 minuti + tempo pre/post.

### 8.5 Strada con GPS scadente (canyon urbano)

- Accuracy oscilla tra 30 e 60 metri.
- Punti con `accuracy > 50` scartati. Buffer riceve ~50% dei punti attesi.
- La polyline risultante e' "a lacune" ma tutti i punti presenti sono affidabili. Rendering: piu' corti tratti ma nessuno zigzag.
- Metriche leggermente sottostimate (distance fatta su punti discreti). Accettabile.

### 8.6 Parcheggio interrato

- Entrata parcheggio, velocita' gia' bassa (5 km/h).
- 15 secondi di silenzio -> check velocity: recent_speed ~ 5 km/h < 20 km/h -> **NON** emettiamo signal_lost.
- Continuiamo in `recording_active`. I prossimi punti quando GPS torna avranno la forma di un'interruzione "naturale" (un punto con delta_t lungo, distanza contenuta, passa sanity filter velocity).

Questo e' intenzionale: parcheggi interrati non sono "tunnel" in senso di valore mappa -- li trattiamo come "GPS scarso momentaneo".

---

## Sezione 9 -- Testing

### 9.1 Unit test

Tutti i filtri sono funzioni pure (o quasi -- dipendono solo dal `FilterContext` passato). Testabili senza emulatore:

```dart
test('quality filter drops high-accuracy points', () {
  final filter = QualityFilter(config);
  final point = PositionInput(..., accuracyM: 60);
  final verdict = filter.apply(point, ctx);
  expect(verdict, isA<DropLowQualityVerdict>());
});
```

### 9.2 Integration test

Con drift in-memory:

- Simula sequenza di 100 punti, verifica buffer contenuto finale.
- Simula scenari 8.1-8.6 sopra, verifica markers inseriti e metriche calcolate.

### 9.3 Campo

- Giri di test reali con diverse condizioni (citta', autostrada, tunnel).
- Dump del buffer + rendering manuale su mappa per verifica visiva.
- Iterazione sui parametri se necessario.

---

**Fine 04_tracking/gps_filters.md**
