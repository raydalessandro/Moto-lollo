# 08 / Navigation -- Edge Cases

**Scopo:** casi limite navigation.

**Riferimenti:** `L0_architecture.md`, `L05_interfaces.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Avvio navigazione

### 1.1 PlannedRoute con waypoints duplicati

**Atteso:** Mapbox Directions accetta. Route risultante e' "passa per waypoint X poi torna subito"; lungo ma valido.

### 1.2 PlannedRoute con waypoints troppo vicini (< 20m)

**Atteso:** Mapbox ignora il duplicato, treat come one waypoint. Nessun errore visibile.

### 1.3 PlannedRoute senza waypoints intermedi (solo start/end)

**Atteso:** Directions calcola route ottimale. Nav OK.

### 1.4 PlannedRoute con > 10 waypoints

**Atteso:** `TooManyWaypointsError`. UI: "Troppi punti intermedi. Modifica il percorso."

### 1.5 PlannedRoute soft-deleted dopo che UI l'ha gia' caricata

**Atteso:** `startNavigation` verifica `plannedApi.getRoute(clientId)` ritorna null -> `PlannedRouteNotFoundError`.

### 1.6 Mapbox Directions 422 (route non calcolabile)

**Scenario:** waypoint in posizione impossibile (mare aperto, strada privata chiusa).

**Atteso:** `DirectionsApiError('route_not_found')`. UI: "Impossibile calcolare il percorso. Verifica i punti."

### 1.7 Mapbox Directions 429 (rate limit)

**Atteso:** `DirectionsApiError('rate_limited')`. UI: "Limite giornaliero raggiunto. Riprova piu' tardi o considera l'upgrade."

### 1.8 Offline

**Atteso:** `NetworkRequiredError`. UI: "Serve connessione per avviare la navigazione."

### 1.9 GPS non disponibile

**Scenario:** permessi negati, location services off.

**Atteso:** `PermissionDeniedError`. UI come nel tracking -> dialog deep link impostazioni.

---

## Sezione 2 -- Durante navigazione

### 2.1 Connessione persa mid-navigation

**Atteso:**
- Mapbox SDK continua su cache interna del route.
- Se utente devia: reroute fallisce silenziosamente. Stato resta `offRoute` finche' utente rientra o torna online.
- Banner UI "Offline, riconnessione..." discreto.

### 2.2 Deviazione piccola (< 50m, rumore GPS)

**Atteso:** SDK non triggera `onRouteDeviation`. Stato resta `navigating`.

### 2.3 Deviazione intenzionale (> 50m sostenuto)

**Atteso:**
- `onRouteDeviation` callback da Mapbox.
- Se autoReroute on: reroute_detector invoca Directions -> nuovo route. Stato: offRoute -> navigating.
- Se autoReroute off: stato resta offRoute. UI mostra "Fuori rotta. Torna indietro o riprogramma."

### 2.4 Deviazioni ripetute in zona confusa (centro citta')

**Atteso:** debounce di 5 secondi tra reroute. Previene spam Directions API.

### 2.5 Punto di arrivo raggiunto

**Atteso:**
- `onArrival` callback da Mapbox.
- Stato: navigating -> arrived.
- UI mostra "Sei arrivato!" + statistiche giro + CTA "Ferma navigazione" / "Ritorna al punto di partenza".
- Dopo 30 secondi inattivita': auto-stop.
- `NavigationEndedEvent(reason: arrived)`.

### 2.6 Utente forza chiusura durante navigazione

**Atteso:**
- Mapbox foreground service si ferma.
- Alla riapertura app: stato idle (niente recovery per navigazione, diversamente da tracking).
- Utente deve ri-avviare navigation.

**Motivazione:** la navigation e' stato transiente. Al contrario del tracking, i dati non vanno persi -- non c'e' nulla da recuperare oltre al waypoint attuale.

---

## Sezione 3 -- Coesistenza con tracking

### 3.1 Tracking attivo + start navigation

**Atteso:** consentito. Entrambi ricevono GPS. Tracking accumula punti, navigation guida.

### 3.2 Entrambi attivi + kill del tracking

**Atteso:** navigation continua. Non e' dipendente.

### 3.3 Stop manual navigation mentre tracking attivo

**Atteso:** navigation stop. Tracking prosegue. Nessuna interferenza.

### 3.4 Battery usage combined

**Osservazione:** tracking (2%/h) + nav (10%/h) = ~12%/h. Documentare "moto con caricatore USB consigliato per giri > 2h".

---

## Sezione 4 -- Voice / TTS

### 4.1 Lingua non supportata da TTS

**Atteso:** fallback a inglese. Se anche quello non disponibile: silenzio, maneuver banner visuale continua.

### 4.2 TTS speak overlap

**Scenario:** due maneuver vicine, TTS sta ancora annunciando la prima quando arriva la seconda.

**Atteso:** `flutter_tts` supporta queue interno. La seconda viene annunciata dopo il completamento della prima. Se la distanza e' tale che la prima e' gia' passata, Mapbox Nav SDK skippa la voice della prima.

### 4.3 Utente disattiva voce mid-trip

**Atteso:** toggle immediato. Annunci in coda vengono silenziati. Maneuver banner visuale resta.

---

## Sezione 5 -- Mapbox specifici

### 5.1 Token Mapbox non valido / scaduto

**Atteso:** `DirectionsApiError('auth_failed')`. Richiede aggiornamento app (nuovo token embedded in build).

### 5.2 Versione Mapbox SDK non compatibile

**Atteso:** crash nativo al runtime. Mitigato da CI check su versioni compatibili.

### 5.3 Usage Mapbox vicino al limit mensile

**Atteso:** nessun warning runtime dall'SDK. Dashboard Mapbox server-side mostra usage. Post-MVP: implementare backend alerting.

---

## Sezione 6 -- UI edge

### 6.1 Rotazione device mid-navigation

**Atteso:** UI navigation_screen si ri-layouta. State preservato. Navigation continua.

### 6.2 Entrare in background durante navigazione

**Atteso:**
- Mapbox foreground service mostra notifica persistente con maneuver attuale.
- TTS continua.
- Main UI non renderizza (app in background).
- Quando utente rientra: UI ricarica state corrente.

### 6.3 Phone call in arrivo

**Atteso:**
- OS abbassa volume TTS automaticamente.
- Dopo chiamata: ripristino volume.
- Nessuna azione specifica del modulo.

### 6.4 Tap button indietro Android

**Atteso:** UI navigation_screen mostra dialog "Vuoi fermare la navigazione?". Default: No (rimane in nav).

---

## Sezione 7 -- Checklist QA

- [ ] startNavigation con PlannedRoute valido + assente + soft-deleted.
- [ ] Navigation su percorso breve (< 5 km) completa con arrived.
- [ ] Deviazione 100m -> auto-reroute.
- [ ] Deviazione 100m con autoReroute off -> offRoute state.
- [ ] Offline mid-navigation.
- [ ] Entrata in tunnel (GPS lost) -> nav SDK tollera.
- [ ] Coesistenza con tracking.
- [ ] TTS italiano + fallback inglese.
- [ ] Toggle voice mid-trip.
- [ ] Stop navigation pulito.
- [ ] Recupero phone call.
- [ ] Back button Android.

---

## Sezione 8 -- Open items specifici navigation

- **Post-MVP B.4:** mappe offline per download regionale.
- **Post-MVP:** dashboard backend per monitorare Mapbox usage.
- **Open UX:** mostrare route 3D oppure 2D standard? Default 3D tilt. Configurabile in settings.

---

**Fine 08_navigation/edge_cases.md**
