# 08 / Navigation -- L0.5 Interfaces

**Scopo:** firme Dart delle API pubbliche del modulo navigation.

**Riferimenti:** `L0_architecture.md`, convenzioni in `04_tracking/L05_interfaces.md` Sezione 1.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Types di dominio

### 1.1 `NavigationState`

```dart
enum NavigationState {
  idle,
  starting,
  navigating,
  offRoute,
  arrived,
}
```

### 1.2 `Maneuver`

Istruzione turn-by-turn per widget UI.

```dart
@freezed
class Maneuver with _$Maneuver {
  const factory Maneuver({
    required ManeuverType type,
    required String instruction,          // "Gira a destra in Via Roma"
    required double distanceM,            // distanza residua al maneuver
    required Duration durationRemaining,  // durata residua al maneuver
    required String? streetName,
    required ManeuverModifier? modifier,
  }) = _Maneuver;
}

enum ManeuverType {
  turn,
  newName,
  depart,
  arrive,
  merge,
  onRamp,
  offRamp,
  fork,
  endOfRoad,
  continueStraight,
  roundabout,
  rotary,
  exitRoundabout,
  exitRotary,
  notification,
}

enum ManeuverModifier { straight, left, right, slightLeft, slightRight, sharpLeft, sharpRight, uTurn }
```

Mapping 1-a-1 con classi Mapbox SDK. Wrapper nativo in `mapbox_nav_adapter` converte.

### 1.3 `RouteProgress`

Stato complessivo della navigazione.

```dart
@freezed
class RouteProgress with _$RouteProgress {
  const factory RouteProgress({
    required NavigationState state,
    required String? plannedRouteClientId,
    required double distanceRemainingM,
    required Duration durationRemaining,
    required double fractionTraveled,    // 0.0 - 1.0
    required Maneuver? upcomingManeuver,
    required LatLng? currentLocation,
    required double? currentSpeedKmh,
  }) = _RouteProgress;
}

@freezed
class LatLng with _$LatLng {
  const factory LatLng(double lat, double lon) = _LatLng;
}
```

### 1.4 `NavigationError`

```dart
sealed class NavigationError {
  const NavigationError();
}

final class PlannedRouteNotFoundError extends NavigationError {
  final String clientId;
  const PlannedRouteNotFoundError(this.clientId);
}

final class TooManyWaypointsError extends NavigationError {
  final int count;
  final int max;
  const TooManyWaypointsError(this.count, this.max);
}

final class DirectionsApiError extends NavigationError {
  // Mapbox API fail (limit, malformed route, etc.)
  final String details;
  const DirectionsApiError(this.details);
}

final class NetworkRequiredError extends NavigationError {
  const NetworkRequiredError();
}

final class PermissionDeniedError extends NavigationError {
  // location permission negato (riutilizza enum tracking)
  const PermissionDeniedError();
}

final class NavigationAlreadyActiveError extends NavigationError {
  const NavigationAlreadyActiveError();
}

final class InternalFailureError extends NavigationError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

---

## Sezione 2 -- `NavigationApi` (contratto)

```dart
abstract class NavigationApi {
  // ---------- STATO OSSERVABILE ----------

  /// Stream di progressione. Emette a ogni update significativo (tipicamente 1-2 Hz).
  Stream<RouteProgress> get progressStream;

  /// Stream dedicato alle nuove maneuver imminenti.
  Stream<Maneuver> get maneuverStream;

  /// Stato corrente.
  NavigationState get currentState;

  // ---------- CONTROLLO ----------

  /// Avvia navigazione dal PlannedRoute specificato.
  /// Fallisce se:
  /// - PlannedRoute non trovata / soft-deleted -> PlannedRouteNotFoundError.
  /// - Waypoints > 10 -> TooManyWaypointsError.
  /// - Mapbox Directions API fallisce -> DirectionsApiError.
  /// - Offline -> NetworkRequiredError.
  /// - Altra navigazione gia' attiva -> NavigationAlreadyActiveError.
  Future<Result<void, NavigationError>> startNavigation(
    String plannedRouteClientId, {
    @Default(true) bool voice,
  });

  /// Ferma la navigazione in corso. Idempotente (no-op se gia' idle).
  Future<void> stopNavigation();

  /// Riportala mappa centrata sulla posizione corrente.
  void recenterMap();

  /// Attiva / disattiva voce. Nuovo stato persiste in preferenze.
  void toggleVoice();

  /// Configura reroute auto. Default true.
  void setAutoReroute(bool enabled);

  // ---------- STATO AUSILIARIO ----------

  /// Ritorna il PlannedRoute correntemente in navigazione, o null.
  String? get activePlannedRouteClientId;

  /// Ritorna l'ultima maneuver annunciata.
  Maneuver? get lastAnnouncedManeuver;
}
```

---

## Sezione 3 -- Eventi emessi

```dart
@freezed
class NavigationStartedEvent with _$NavigationStartedEvent {
  const factory NavigationStartedEvent({
    required String plannedRouteClientId,
    required DateTime startedAt,
    required Duration estimatedDuration,
    required double estimatedDistanceKm,
  }) = _NavigationStartedEvent;
}

@freezed
class NavigationEndedEvent with _$NavigationEndedEvent {
  const factory NavigationEndedEvent({
    required String plannedRouteClientId,
    required DateTime endedAt,
    required NavigationEndReason reason,
  }) = _NavigationEndedEvent;
}

enum NavigationEndReason { arrived, userStopped, error }

@freezed
class NavigationManeuverEvent with _$NavigationManeuverEvent {
  const factory NavigationManeuverEvent({
    required Maneuver maneuver,
    required DateTime occurredAt,
  }) = _NavigationManeuverEvent;
}
```

---

## Sezione 4 -- `NavigationModule` (manifest)

```dart
class NavigationModule extends AppModule {
  @override
  String get name => 'navigation';

  @override
  List<String> get dependsOn => ['shared.event_bus', 'shared.auth'];

  @override
  List<Type> get provides => [NavigationApi];

  @override
  List<Type> get consumes => [PlannedRouteApi];

  @override
  void register(ModuleRegistry r) {
    final plannedApi = r.resolve<PlannedRouteApi>();
    final mapboxAdapter = MapboxNavAdapter();
    final ttsSpeaker = TtsSpeaker();
    final controller = NavigationController(
      plannedApi: plannedApi,
      mapboxAdapter: mapboxAdapter,
      ttsSpeaker: ttsSpeaker,
      bus: r.resolve<EventBus>(),
    );
    r.registerApi<NavigationApi>(NavigationApiImpl(controller));
  }
}
```

---

## Sezione 5 -- Thread model

La callback Mapbox Nav arriva dal thread nativo Android/iOS. `MapboxNavAdapter` fa il marshalling verso il main isolate Dart via platform channel. Tutti gli stream `NavigationApi` emettono su main isolate.

---

## Sezione 6 -- Test contracts

- `startNavigation` happy path + ogni `NavigationError`.
- State transitions tramite mock adapter.
- Reroute debounce.
- Voice toggle persistente.

---

**Fine 08_navigation/L05_interfaces.md**
