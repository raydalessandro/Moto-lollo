# 08 / Navigation -- L0 Architecture

**Scopo:** navigazione turn-by-turn su percorsi pianificati. Wrapper sopra Mapbox Navigation SDK.

**Cosa NON e' qui:**

- Tracking (modulo 04).
- Creazione di PlannedRoute (modulo 10 planning).
- Rendering statico di polyline / mappa view-only (widget condivisi in `shared/maps/`).

**Riferimenti:**

- Stack: `00_overview.md` (Mapbox GL Native + Nav SDK).
- Entita' PlannedRoute: `01_data_model.md` Sezione 7.
- Decisione mappe offline rinviata: B.4.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Quando l'utente ha un PlannedRoute e vuole percorrerlo fisicamente, il modulo navigation gli fornisce istruzioni vocali e visive turn-by-turn, mostra posizione live sulla mappa, rileva deviazioni e rie-route se richiesto.

**Coesistenza con tracking:** navigazione attiva e tracking possono coesistere. L'utente pianifica un giro in moto, avvia il tracking (modulo 04) e contemporaneamente la navigazione verso il percorso pianificato. Le due funzioni condividono il feed GPS del `geolocator` ma non comunicano direttamente -- ciascuna riceve i propri update dal sistema.

---

## Sezione 2 -- Struttura interna

```
modules/navigation/
|-- lib/
|   |-- navigation.dart
|   |-- api.dart
|   +-- src/
|       |-- domain/
|       |   |-- navigation_state.dart
|       |   |-- maneuver.dart
|       |   |-- route_progress.dart
|       |   +-- navigation_error.dart
|       |-- application/
|       |   |-- navigation_controller.dart
|       |   |-- reroute_detector.dart
|       |   +-- tts_speaker.dart
|       |-- infrastructure/
|       |   |-- mapbox_nav_adapter.dart      (wrapper su Mapbox Nav SDK)
|       |   +-- voice_config.dart
|       +-- ui/
|           |-- navigation_screen.dart
|           +-- widgets/
|               |-- maneuver_banner.dart
|               +-- mini_map.dart
|-- test/
+-- pubspec.yaml
```

**Isolamento Mapbox:** tutte le chiamate dirette a Mapbox Navigation SDK passano attraverso `mapbox_nav_adapter.dart`. Il resto del modulo non conosce Mapbox API dirette. Permette mock per testing e eventuale sostituzione SDK futuro.

---

## Sezione 3 -- API pubblica (sintesi)

- `startNavigation(plannedRouteClientId, voice: bool)` -> Future<Result<void, NavigationError>>.
- `stopNavigation()` -> void.
- `recenterMap()` -> void.
- `toggleVoice()` -> void.
- `get stateStream` -> Stream<NavigationState>.
- `get maneuverStream` -> Stream<Maneuver>.

---

## Sezione 4 -- Stati

```
 idle -- startNavigation() --> starting
   ^                              |
   |                              v
   |                        navigating
   |                              |
   |                     +--------+--------+
   |                     |                 |
   |               offRoute          arrived
   |                     |                 |
   |                     +--------+--------+
   +------- stopNavigation() / arrival -------
```

Stati:

- **`idle`**: nessuna navigazione in corso.
- **`starting`**: chiamata Mapbox in corso per costruire route navigabile dal PlannedRoute. Tipicamente < 2 sec.
- **`navigating`**: navigazione attiva, utente sul percorso.
- **`offRoute`**: utente deviato. Vedi Sezione 6.
- **`arrived`**: raggiunto punto di arrivo. Mostra completamento, torna a idle.

---

## Sezione 5 -- Interazione con PlannedRoute

### 5.1 Dalla PlannedRoute al route navigabile

Un `PlannedRoute` (vedi modulo planning) contiene:

- `waypoints`: lista di coordinate [lat, lon] che l'utente ha inserito.
- `polyline_encoded`: polyline computata dal routing engine Mapbox durante la pianificazione.

Quando `startNavigation()` viene chiamato:

1. `mapbox_nav_adapter` prende i waypoints.
2. Invoca Mapbox Directions API con profilo `mapbox/driving-traffic` (configurabile in `voice_config.dart`).
3. Riceve oggetto `DirectionsRoute` Mapbox.
4. Avvia `MapboxNavigation` con quel route.
5. Stato passa da `starting` a `navigating`.

**Osservazione:** la polyline del PlannedRoute e' uno snapshot del momento della pianificazione. La navigazione usa directions aggiornate (traffico, chiusure). Potrebbero divergere. Accettabile -- utente vuole la navigazione piu' accurata.

### 5.2 Waypoints multipli

Se il PlannedRoute ha 5+ waypoints, Mapbox supporta fino a 25 waypoints per Directions request. MVP limita a 10 waypoints per PlannedRoute (vincolo di prodotto).

---

## Sezione 6 -- Off-route detection e reroute

### 6.1 Detection

Mapbox Nav SDK fornisce callback `onRouteDeviation` quando l'utente si discosta oltre soglia configurabile (default 50m). Il nostro `reroute_detector` ascolta.

### 6.2 Policy di reroute

**MVP:** auto-reroute silenzioso. Quando rilevata deviazione:

1. `reroute_detector` invoca Mapbox Directions da posizione attuale a prossimo waypoint non raggiunto.
2. Mapbox Nav SDK aggiorna route internamente.
3. Stato transiziona temporaneamente a `offRoute`, poi torna `navigating` dopo ricezione nuovo route.

**Configurabile:** l'utente puo' disattivare auto-reroute in settings. In tal caso, state resta `offRoute` finche' utente torna manualmente o ferma navigazione.

### 6.3 Limite traffic quotidiano

Mapbox free tier: limit di chiamate Directions. Auto-reroute continuo in zona confusa potrebbe esaurirlo. Mitigazione: debounce di 5 secondi tra reroute successivi.

---

## Sezione 7 -- Voice (TTS)

Mapbox Nav SDK fornisce istruzioni testuali. Conversione a voce tramite `tts_speaker` che wrappa `flutter_tts`.

**Configurabilita':**

- Lingua voce: default italiano (device locale).
- Volume: 0-100.
- Toggle on/off.
- Distanza avviso: "tra 500m gira a destra" vs "gira subito a destra" (standard Mapbox).

**Silenzio offline:** se sintesi TTS non disponibile in lingua richiesta, fallback a inglese. Se anche quello fallisce: silenzio, solo maneuver banner visivo.

---

## Sezione 8 -- Eventi emessi sul bus

- `NavigationStartedEvent(plannedRouteClientId, estimatedDurationMin)`.
- `NavigationEndedEvent(plannedRouteClientId, reason)` dove reason e' uno tra: arrived, userStopped, error.
- `NavigationManeuverEvent(maneuver)` -- per widget UI dall'esterno che vogliono mostrare next turn.

**Nessun evento di low-level** (off-route, re-route) sul bus -- roba interna del modulo.

---

## Sezione 9 -- Eventi consumati

### 9.1 `AppLifecycleBackgroundedEvent`

Mapbox Nav SDK supporta background nativamente su Android (foreground service separato dal nostro). Il modulo navigation NON crea un secondo foreground service -- usa quello di Mapbox SDK.

### 9.2 `UserLoggedOutEvent`

Se navigazione in corso: auto-stop + `NavigationEndedEvent(reason: error)`.

---

## Sezione 10 -- Dipendenze

### Consumes:

- `shared/event_bus/EventBus`.
- `PlannedRouteApi` dal modulo planning (via `shared/db/repositories/` per letture).
- Mapbox Nav SDK nativo (via platform channels / FFI).

### Provides:

- `NavigationApi`.

---

## Sezione 11 -- Offline e mappe

**Policy MVP:** navigazione richiede connessione. Vedi B.4.

**Experience degraded:** se utente avvia navigazione con connessione stabile e poi entra in tunnel o zona senza campo, Mapbox SDK continua a navigare usando cache di route gia' scaricato. Perdita di reroute finche' non torna online. Accettabile.

**Feature post-MVP (B.4):** download mappe offline per regione (monetizzabile).

---

## Sezione 12 -- Performance

**Batteria:** navigazione attiva con GPS + TTS + mappa renderizzata consuma ~8-15% batteria/ora. Molto.

**Mitigazione:**
- Se tracking attivo contemporaneamente: nav + tracking insieme.
- Documentato nell'UI: "Navigazione attiva, tieni il caricatore pronto".

**Traffico rete:** Mapbox Nav consuma ~2-5 MB/ora per tile + directions. Accettabile.

---

## Sezione 13 -- Testing

### 13.1 Unit test

- Reroute detector: input delta posizione > soglia -> trigger reroute.
- TTS speaker: string maneuver -> speak call mock.

### 13.2 Integration test

- Mock `mapbox_nav_adapter`: simula state machine senza SDK reale.
- State transitions corrette (starting -> navigating -> arrived).

### 13.3 Campo

- Test reali con PlannedRoute brevi (5-10 km) in citta' e autostrada.
- Verifica offline degradation.

---

**Fine 08_navigation/L0_architecture.md**
