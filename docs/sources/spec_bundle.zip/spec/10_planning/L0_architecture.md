# 10 / Planning -- L0 Architecture

**Scopo:** pianificazione di percorsi (PlannedRoute). L'utente definisce waypoints, il modulo calcola polyline via Mapbox Directions, persiste per uso futuro (navigazione, pubblicazione, riferimento).

**Cosa NON e' qui:**

- Navigazione di un PlannedRoute (modulo 08).
- Pubblicazione di un PlannedRoute in community (modulo 07).
- Mappa interattiva per placement waypoint (widget condiviso `shared/maps/`).

**Riferimenti:**

- Entita' PlannedRoute: `01_data_model.md` Sezione 7.
- Schema: `02_database_schema.md` Sezione 3.5.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Permettere a un utente di:

- Creare un percorso "da fare" partendo da waypoints sulla mappa.
- Salvarlo con nome, descrizione, tags.
- Rivederlo, modificarlo, eliminarlo.
- Usarlo come base per navigazione (modulo 08) o pubblicazione (modulo 07).

**Il modulo e' owner** di PlannedRoute.

**Distinzione chiave rispetto a PublishedRoute:** PlannedRoute e' privata dell'utente, persistente come "bookmarks" di percorsi. PublishedRoute e' condivisa socialmente (snapshot creato al publish). Un PlannedRoute puo' o non puo' diventare una PublishedRoute.

---

## Sezione 2 -- Struttura interna

```
modules/planning/
|-- lib/
|   |-- planning.dart
|   |-- api.dart
|   +-- src/
|       |-- domain/
|       |   |-- planned_route.dart
|       |   |-- waypoint.dart
|       |   +-- planning_error.dart
|       |-- application/
|       |   |-- planned_route_service.dart
|       |   +-- directions_builder.dart   (Mapbox Directions call)
|       |-- persistence/
|       |   |-- planned_routes_dao.dart
|       |   +-- planned_route_repository.dart
|       +-- ui/
|           |-- plans_screen.dart            (lista)
|           |-- plan_detail_screen.dart
|           |-- plan_editor_screen.dart      (creazione / modifica con mappa)
|           +-- widgets/
|-- test/
+-- pubspec.yaml
```

---

## Sezione 3 -- API pubblica (sintesi)

- `watchAllPlannedRoutes(ownerId)` -> Stream.
- `getPlannedRoute(clientId)` -> Future<PlannedRouteDetail?>.
- `createPlannedRoute(request)` -> Future<Result<String, E>>.
- `updatePlannedRoute(clientId, request)` -> Future<Result<void, E>>.
- `deletePlannedRoute(clientId)` -> Future<Result<void, E>>.
- `duplicatePlannedRoute(clientId)` -> Future<Result<String, E>>.
- `getByClientId(clientId)` -> per il modulo navigation.

---

## Sezione 4 -- Interazioni operative

### 4.1 Creazione

1. Utente apre `plan_editor_screen` (mappa interattiva + pannello waypoints).
2. Tap sulla mappa per aggiungere waypoint. Max 10 (coerente con navigation Sezione 5.2).
3. Ogni modifica dei waypoints: trigger ricalcolo polyline via Mapbox Directions (debounced 800ms per evitare flood API).
4. UI mostra polyline live, distance_km stimata, duration_seconds stimata.
5. Tap "Salva" -> `createPlannedRoute`:
   - Validazione (min 2 waypoints, tutti con coordinate valide).
   - Insert drift con `sync_state = 'pending'`.
   - Emit `PlannedRouteCreatedEvent`.
   - Sync enqueue upload.

### 4.2 Modifica

Edit flow simile. Al salvataggio:
- `updated_at` + `version + 1`.
- Se la PlannedRoute e' referenziata da una PublishedRoute (via `source_client_id`), la PublishedRoute **non** viene automaticamente aggiornata. Resta snapshot (D.32). UI segnala "Questa pianificazione e' gia' pubblicata. Per aggiornare la versione pubblicata, usa Aggiorna pubblicazione."

### 4.3 Duplicazione

Utente tap "Duplica" su PlannedRoute esistente:
- Nuovo client_id.
- Waypoints, polyline_encoded, bbox, distance_km, duration_seconds copiati.
- `title = original.title + " (copia)"`.
- Nessun legame con l'originale (no FK). Sono entita' indipendenti post-duplicazione.

### 4.4 Eliminazione

Soft delete. PlannedRoute sparisce dalla UI plans_screen ma:
- PublishedRoute eventualmente associate restano (hanno snapshot).
- Navigazione non puo' piu' avviarsi su PlannedRoute soft-deleted -> `PlannedRouteNotFoundError` dal modulo 08.

---

## Sezione 5 -- Interazione con Mapbox Directions

Il `directions_builder` fa la chiamata a Mapbox Directions API (stessa che nav fa all'avvio). Cache locale 5 min per stesso set di waypoints (evita chiamate ripetute durante editing).

**Profilo di routing:** `mapbox/driving` o `mapbox/driving-traffic`. Default `driving` nel planning (no traffico in tempo reale -- la pianificazione e' asincrona al momento dell'uso).

**Gestione fallimenti:** se Directions API fallisce (offline, rate limit, waypoints non raggiungibili), UI mostra errore, polyline non disponibile. Utente puo' comunque salvare senza polyline (caso borderline ma valido per drafting). In tal caso, tentativo alla prossima modifica o al momento di startNavigation.

**Campo `polyline_encoded` nullable:** lo schema gia' lo supporta (`TEXT` nullable). Ma per UX pulita, UI chiede di avere polyline prima di salvare.

---

## Sezione 6 -- Eventi emessi

- `PlannedRouteCreatedEvent(clientId, ownerId, title, waypoints_count)`.
- `PlannedRouteUpdatedEvent(clientId, ownerId, changedFields)`.
- `PlannedRouteDeletedEvent(clientId, ownerId, deletedAt)`.

Consumatori:
- Sync: enqueue.
- Community: se publish e' stata fatta da questa PlannedRoute, visualizza indicatore aggiornamento (D.32).

---

## Sezione 7 -- Eventi consumati

Nessuno critico. Il planning e' un modulo "input utente puro".

`UserLoggedOutEvent`: nessuna reazione (stream filtrate per ownerId).

---

## Sezione 8 -- Dipendenze

- `shared/db/AppDatabase`.
- `shared/event_bus/EventBus`.
- `shared/auth/AuthService`.
- Mapbox Directions API (client-side via `mapbox_api_client` shared package).

Provides: `PlannedRouteApi`.

---

## Sezione 9 -- Performance

Volume tipico: 5-30 PlannedRoute per utente attivo. Nessuna ottimizzazione specifica.

---

## Sezione 10 -- Testing

- CRUD happy path.
- Creazione con 2-10 waypoints.
- Validazione waypoints invalidi.
- Directions fail -> salva senza polyline.
- Duplicate preserva metadata.
- Soft delete non tocca PublishedRoute associate.

---

**Fine 10_planning/L0_architecture.md**
