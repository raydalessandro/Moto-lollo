# 10 / Planning -- L0.5 Interfaces

**Scopo:** firme Dart del modulo planning.

**Riferimenti:** `L0_architecture.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Types di dominio

### 1.1 `Waypoint`

```dart
@freezed
class Waypoint with _$Waypoint {
  const factory Waypoint({
    required double lat,
    required double lon,
    required int order,       // posizione nell'ordine 0-based
    String? label,            // opzionale nome ("Partenza", "Pausa pranzo")
  }) = _Waypoint;
}
```

### 1.2 `PlannedRouteSummary`

Versione leggera per lista.

```dart
@freezed
class PlannedRouteSummary with _$PlannedRouteSummary {
  const factory PlannedRouteSummary({
    required String clientId,
    required String title,
    required double distanceKm,
    required Duration estimatedDuration,
    required int waypointCount,
    required String polylineEncoded,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _PlannedRouteSummary;
}
```

### 1.3 `PlannedRouteDetail`

Versione completa.

```dart
@freezed
class PlannedRouteDetail with _$PlannedRouteDetail {
  const factory PlannedRouteDetail({
    required String clientId,
    required String ownerId,
    required String title,
    required String? description,
    required List<String> tags,
    required List<Waypoint> waypoints,
    required String polylineEncoded,
    required BoundingBox bbox,
    required double distanceKm,
    required Duration estimatedDuration,
    required DateTime createdAt,
    required DateTime updatedAt,
    required int version,
  }) = _PlannedRouteDetail;
}
```

### 1.4 `CreatePlannedRouteRequest`

```dart
@freezed
class CreatePlannedRouteRequest with _$CreatePlannedRouteRequest {
  const factory CreatePlannedRouteRequest({
    required String title,
    String? description,
    @Default([]) List<String> tags,
    required List<Waypoint> waypoints,
    String? polylineEncoded,                 // se gia' calcolato client-side
    double? distanceKm,
    Duration? estimatedDuration,
  }) = _CreatePlannedRouteRequest;
}
```

### 1.5 `UpdatePlannedRouteRequest`

```dart
@freezed
class UpdatePlannedRouteRequest with _$UpdatePlannedRouteRequest {
  const factory UpdatePlannedRouteRequest({
    String? title,
    String? description,
    List<String>? tags,
    List<Waypoint>? waypoints,
    String? polylineEncoded,
    double? distanceKm,
    Duration? estimatedDuration,
  }) = _UpdatePlannedRouteRequest;
}
```

### 1.6 `PlanningError`

```dart
sealed class PlanningError {
  const PlanningError();
}

final class ValidationError extends PlanningError {
  final String field;
  final String message;
  const ValidationError(this.field, this.message);
}

final class NotFoundError extends PlanningError {
  final String clientId;
  const NotFoundError(this.clientId);
}

final class NotOwnerError extends PlanningError {
  final String clientId;
  const NotOwnerError(this.clientId);
}

final class TooFewWaypointsError extends PlanningError {
  const TooFewWaypointsError();
}

final class TooManyWaypointsError extends PlanningError {
  final int count;
  final int max;
  const TooManyWaypointsError(this.count, this.max);
}

final class DirectionsApiError extends PlanningError {
  final String details;
  const DirectionsApiError(this.details);
}

final class InternalFailureError extends PlanningError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

---

## Sezione 2 -- `PlannedRouteApi` (contratto)

```dart
abstract class PlannedRouteApi {
  // ---------- QUERY ----------

  Stream<List<PlannedRouteSummary>> watchAllPlannedRoutes(String ownerId);

  Future<PlannedRouteDetail?> getPlannedRoute(String clientId);

  // ---------- MUTAZIONI ----------

  /// Crea una nuova pianificazione.
  /// Se polylineEncoded / distanceKm / estimatedDuration non sono presenti nel request,
  /// il service tenta di calcolarli via Mapbox Directions.
  Future<Result<String, PlanningError>> createPlannedRoute(
    CreatePlannedRouteRequest request,
  );

  Future<Result<void, PlanningError>> updatePlannedRoute(
    String clientId,
    UpdatePlannedRouteRequest request,
  );

  Future<Result<void, PlanningError>> deletePlannedRoute(String clientId);

  Future<Result<String, PlanningError>> duplicatePlannedRoute(String clientId);

  // ---------- HELPER PER MAPBOX ----------

  /// Calcola polyline + distanza + durata da un set di waypoints.
  /// Usabile da UI editor durante il drafting senza persistere.
  Future<Result<DirectionsResult, PlanningError>> computeDirections(
    List<Waypoint> waypoints,
  );
}

@freezed
class DirectionsResult with _$DirectionsResult {
  const factory DirectionsResult({
    required String polylineEncoded,
    required BoundingBox bbox,
    required double distanceKm,
    required Duration estimatedDuration,
  }) = _DirectionsResult;
}
```

---

## Sezione 3 -- Eventi emessi

```dart
@freezed
class PlannedRouteCreatedEvent with _$PlannedRouteCreatedEvent {
  const factory PlannedRouteCreatedEvent({
    required String clientId,
    required String ownerId,
    required String title,
    required int waypointCount,
    required DateTime createdAt,
  }) = _PlannedRouteCreatedEvent;
}

@freezed
class PlannedRouteUpdatedEvent with _$PlannedRouteUpdatedEvent {
  const factory PlannedRouteUpdatedEvent({
    required String clientId,
    required String ownerId,
    required Set<String> changedFields,
    required DateTime updatedAt,
  }) = _PlannedRouteUpdatedEvent;
}

@freezed
class PlannedRouteDeletedEvent with _$PlannedRouteDeletedEvent {
  const factory PlannedRouteDeletedEvent({
    required String clientId,
    required String ownerId,
    required DateTime deletedAt,
  }) = _PlannedRouteDeletedEvent;
}
```

---

## Sezione 4 -- `PlanningModule` (manifest)

```dart
class PlanningModule extends AppModule {
  @override
  String get name => 'planning';

  @override
  List<String> get dependsOn => [
    'shared.db',
    'shared.event_bus',
    'shared.auth',
    'shared.mapbox',
  ];

  @override
  List<Type> get provides => [PlannedRouteApi];

  @override
  List<Type> get consumes => [];

  @override
  void register(ModuleRegistry r) {
    // instanziazione service + directions_builder
  }
}
```

---

## Sezione 5 -- Test contracts

- CRUD happy path.
- Validation: 1 waypoint -> TooFewWaypointsError.
- Validation: 11 waypoints -> TooManyWaypointsError.
- Create senza polyline -> Mapbox Directions invocato.
- Create con polyline gia' fornita -> Mapbox NON invocato.
- Duplicate genera client_id diverso.
- Soft delete non tocca PublishedRoute associate.

---

**Fine 10_planning/L05_interfaces.md**
