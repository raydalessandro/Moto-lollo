# 10 / Planning -- Edge Cases

**Scopo:** casi limite planning.

**Riferimenti:** `L0_architecture.md`, `L05_interfaces.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Creazione

### 1.1 Meno di 2 waypoints

**Atteso:** `TooFewWaypointsError`. UI: "Aggiungi almeno una partenza e una destinazione."

### 1.2 Piu' di 10 waypoints

**Atteso:** `TooManyWaypointsError(count, max=10)`. UI: "Massimo 10 punti per percorso."

### 1.3 Waypoints con coordinate invalide

**Scenario:** lat = 200 (invalid), lon = -500 (invalid).

**Atteso:** `ValidationError('waypoints[i].lat', 'Coordinata non valida')`. Sanity check: -90 <= lat <= 90, -180 <= lon <= 180.

### 1.4 Waypoints coincidenti (2 waypoints identici)

**Atteso:** consentito per drafting. Mapbox Directions trattera' come "gita breve". UI potrebbe warning soft "I punti sono molto vicini".

### 1.5 Waypoints non raggiungibili (es. isola, strada privata)

**Scenario:** Mapbox Directions ritorna 422 "no route found".

**Atteso:**
- `DirectionsApiError('no_route_found')`.
- UI: "Non riesco a calcolare un percorso tra questi punti. Prova a spostarli."
- PlannedRoute NON creato, utente edita e riprova.

### 1.6 Offline durante creazione

**Scenario:** utente ha piu' waypoints, tenta computeDirections offline.

**Atteso:**
- `DirectionsApiError('offline')`.
- UI offre 2 opzioni:
  - (a) Salva senza polyline (bozza). Al prossimo online, l'utente puo' "calcolare percorso".
  - (b) Non salvare, riprova online.

### 1.7 Mapbox timeout (> 10s)

**Atteso:** `DirectionsApiError('timeout')`. Retry manuale.

### 1.8 Creazione con polyline fornita client-side ma inconsistente con waypoints

**Scenario:** client invia polyline_encoded che non passa per i waypoints dichiarati.

**Atteso:** consentito. Schema DB non verifica coerenza. Lato pragmatico: rischio UX basso -- il client editor calcola sempre polyline coerente. Se bug futuro invia dati inconsistenti, UX degradata ma non crash.

**Non-MVP:** validazione server-side via Edge Function che ricalcola e confronta.

---

## Sezione 2 -- Modifica

### 2.1 Rimozione di tutti i waypoints

**Scenario:** utente cancella waypoints nell'editor finche' ne restano 1 o 0.

**Atteso:** pulsante "Salva" disabilitato nell'UI. Service ritorna `TooFewWaypointsError` se chiamato comunque.

### 2.2 Sostituzione totale waypoints

**Scenario:** utente cancella tutti i waypoints attuali e ne aggiunge di nuovi. Lo fa "sopra" la PlannedRoute esistente.

**Atteso:** update standard. `changedFields = {waypoints, polylineEncoded, bbox, distanceKm, estimatedDuration}`. `version + 1`.

### 2.3 Modifica di PlannedRoute referenziata da PublishedRoute

**Atteso:**
- PlannedRoute viene modificata.
- PublishedRoute NON e' auto-aggiornata (snapshot D.32).
- UI mostra badge "Questa pianificazione e' gia' pubblicata. Clicca per aggiornare la versione pubblica."
- Click -> chiama `CommunityApi.resyncFromSource(publishedRouteClientId)`.

### 2.4 Modifica di PlannedRoute in corso di navigazione

**Scenario:** utente sta navigando su PlannedRoute X. Apre app, modifica X.

**Atteso:**
- Modifica in drift accettata.
- Navigation in corso usa DirectionsRoute Mapbox calcolato al momento dello start (snapshot). Non e' impattata.
- Al termine della navigation, lo startNavigation successivo usera' la nuova versione.

### 2.5 Modifica di propria PlannedRoute di altro owner (bug sicurezza)

**Atteso:** `NotOwnerError`. Check client-side prima di DB write.

---

## Sezione 3 -- Eliminazione

### 3.1 Delete di PlannedRoute referenziata da PublishedRoute

**Scenario:** PlannedRoute X ha PublishedRoute Y con source_client_id = X.

**Atteso:**
- X soft-deleted.
- Y resta visibile (snapshot completo).
- Al prossimo fetch server di Y: `source_client_id` puntera' ancora a X (soft-deleted). UI client community mostra "fonte non piu' disponibile" (vedi `07_community/edge_cases.md` Sezione 1.4).
- **Nota:** il trigger `null_published_source_on_parent_delete` agisce solo su HARD delete. Soft delete NON azzera il riferimento, per design.

### 3.2 Delete in corso di navigazione

**Scenario:** utente sta navigando X, apre app e cancella X.

**Atteso:**
- X soft-deleted.
- Navigation in corso NON interrotta (snapshot route gia' caricato da Mapbox SDK).
- Al prossimo startNavigation: `PlannedRouteNotFoundError`.

### 3.3 Delete + re-create con stessi waypoints

**Atteso:** consentito. Nuovo client_id, nessuna relazione con quella soft-deleted.

---

## Sezione 4 -- Duplicazione

### 4.1 Duplicate di PlannedRoute soft-deleted

**Atteso:** `NotFoundError`. Soft-deleted non sono disponibili per duplicazione.

### 4.2 Duplicate preserva polyline gia' calcolata

**Atteso:** si', `polyline_encoded` copiato as-is. Nessuna re-chiamata Mapbox.

### 4.3 Titolo duplicato

**Atteso:** `title = originale + " (copia)"`. Se la copia viene duplicata a sua volta: "(copia) (copia)". Nessun cap alla lunghezza; validazione 100 chars potrebbe rifiutare. In tal caso fallback: `title = original.title.substring(0, 90) + " (copia)"`.

---

## Sezione 5 -- Mapbox Directions edge

### 5.1 Directions API limit daily

**Scenario:** utente heavy user supera 1000 richieste/giorno (free tier).

**Atteso:** `DirectionsApiError('rate_limited')`. UI: "Limite raggiunto. Riprova domani o upgrada."

**Monitoring post-MVP:** dashboard per alert admin.

### 5.2 Directions cache locale

**Scenario:** utente edita waypoints, cancella uno, aggiunge quello di prima.

**Atteso:**
- Cache client-side con chiave = hash(ordered waypoints).
- TTL 5 min.
- Cache hit: zero chiamata API, polyline istantanea.

### 5.3 Modifica profile routing (driving vs driving-traffic)

**Scenario:** futuro utente sceglie tra routing veloce / panoramico.

**Non MVP.** Default `mapbox/driving`.

---

## Sezione 6 -- Checklist QA

- [ ] Creazione con 2 waypoints.
- [ ] Creazione con 10 waypoints (boundary).
- [ ] Creazione con 11 waypoints -> error.
- [ ] Creazione con 1 waypoint -> error.
- [ ] Creazione con waypoints non raggiungibili -> Directions error.
- [ ] Creazione offline -> opzione salva senza polyline.
- [ ] Update di titolo.
- [ ] Update di waypoints (ricalcolo polyline).
- [ ] Delete.
- [ ] Delete di PlannedRoute referenziata -> PublishedRoute resta.
- [ ] Duplicate.
- [ ] Cache Mapbox Directions (verifica con network inspector).

---

## Sezione 7 -- Open items specifici planning

Nessuno critico. Tutto e' tunable post-MVP.

---

**Fine 10_planning/edge_cases.md**
