# 06 / Garage -- L0.5 Interfaces

**Scopo:** firme Dart delle API pubbliche del modulo garage, types di dominio esportati, eventi tipizzati, exception.

**Cosa NON e' qui:**

- Implementazione concreta (vivra' in `src/application/`).
- Schema DB (in `02_database_schema.md` e `03_local_db.md`).
- Casi limite (in `edge_cases.md`).

**Riferimenti:**

- Architettura modulo: `L0_architecture.md`.
- Pattern convenzioni (Result, freezed, ecc.): `04_tracking/L05_interfaces.md` Sezione 1.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Types di dominio pubblici

Dichiarati in `modules/garage/lib/api.dart` o re-export da `src/domain/`.

### 1.1 `MotorcycleSummary`

Versione leggera usata nelle liste (garage_screen, selettore moto nel tracking).

```dart
@freezed
class MotorcycleSummary with _$MotorcycleSummary {
  const factory MotorcycleSummary({
    required String clientId,
    required String name,
    required String brand,
    required String model,
    required double totalKm,
    required bool isPrimary,
    required String? photoStoragePathThumb,
  }) = _MotorcycleSummary;
}
```

### 1.2 `MotorcycleDetail`

Versione completa per lo schermo di dettaglio.

```dart
@freezed
class MotorcycleDetail with _$MotorcycleDetail {
  const factory MotorcycleDetail({
    required String clientId,
    required String ownerId,
    required String name,
    required String brand,
    required String model,
    required int? year,
    required int? engineCc,
    required String? color,
    required String? photoStoragePath,
    required String? photoStoragePathThumb,
    required double odometerStartKm,
    required double totalKm,
    required bool isPrimary,
    required DateTime createdAt,
    required DateTime updatedAt,
    required int version,
  }) = _MotorcycleDetail;
}
```

### 1.3 `MotorcycleStats`

Statistiche aggregate. Calcolate on-demand sulla lista Activity associate.

```dart
@freezed
class MotorcycleStats with _$MotorcycleStats {
  const factory MotorcycleStats({
    required String motorcycleClientId,
    required int activityCount,
    required double totalDistanceKm,
    required Duration totalDuration,
    required DateTime? lastActivityAt,
    required double? avgSpeedKmh,
    required double? maxSpeedKmh,
  }) = _MotorcycleStats;
}
```

### 1.4 `CreateMotorcycleRequest`

```dart
@freezed
class CreateMotorcycleRequest with _$CreateMotorcycleRequest {
  const factory CreateMotorcycleRequest({
    required String name,
    required String brand,
    required String model,
    int? year,
    int? engineCc,
    String? color,
    double? odometerStartKm,
  }) = _CreateMotorcycleRequest;
}
```

Nota: `is_primary` non e' nel request. Se la moto e' la prima del owner, viene promossa automaticamente a primaria (Sezione 6.1 di L0). Per cambiare primaria si usa `setPrimary(clientId)`.

### 1.5 `UpdateMotorcycleRequest`

Tutti i campi nullable. Solo quelli non-null vengono aggiornati. Campi immutabili post-creazione (se il prodotto lo richiedesse) andrebbero qui esclusi.

```dart
@freezed
class UpdateMotorcycleRequest with _$UpdateMotorcycleRequest {
  const factory UpdateMotorcycleRequest({
    String? name,
    String? brand,
    String? model,
    int? year,
    int? engineCc,
    String? color,
    double? odometerStartKm,
  }) = _UpdateMotorcycleRequest;
}
```

### 1.6 `GarageError`

```dart
sealed class GarageError {
  const GarageError();
}

final class ValidationError extends GarageError {
  final String field;
  final String message;
  const ValidationError(this.field, this.message);
}

final class MotorcycleNotFoundError extends GarageError {
  final String clientId;
  const MotorcycleNotFoundError(this.clientId);
}

final class NotOwnerError extends GarageError {
  final String clientId;
  final String ownerId;
  const NotOwnerError(this.clientId, this.ownerId);
}

final class PhotoTooLargeError extends GarageError {
  final int sizeBytes;
  final int maxBytes;
  const PhotoTooLargeError(this.sizeBytes, this.maxBytes);
}

final class PhotoUploadFailedError extends GarageError {
  final String details;
  const PhotoUploadFailedError(this.details);
}

final class StorageFullError extends GarageError {
  const StorageFullError();
}

final class InternalFailureError extends GarageError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

---

## Sezione 2 -- `MotorcycleApi` (contratto pubblico)

```dart
abstract class MotorcycleApi {
  // ---------- QUERY ----------

  /// Emette la lista delle moto dell'utente (escluse soft-deleted) in tempo reale.
  /// Ordine: primaria prima, poi le altre per createdAt DESC.
  Stream<List<MotorcycleSummary>> watchAllMotorcycles(String ownerId);

  /// Ritorna il dettaglio di una moto o null se inesistente / soft-deleted.
  Future<MotorcycleDetail?> getMotorcycle(String clientId);

  /// Ritorna true se la moto esiste e non e' soft-deleted.
  /// Usato da altri moduli (es. tracking) per validazione.
  Future<bool> exists(String clientId);

  /// Ritorna la moto primaria del owner, o null se non ne ha (o nessuna moto).
  Future<MotorcycleSummary?> getPrimary(String ownerId);

  /// Emette statistiche aggregate in tempo reale per una moto.
  /// Calcolate dalla tabella activities_local associata.
  Stream<MotorcycleStats> watchStats(String clientId);

  // ---------- MUTAZIONI ----------

  /// Crea una nuova moto.
  /// Se l'utente non ha altre moto non-deleted, la nuova diventa automaticamente primaria.
  /// Ritorna il clientId generato.
  Future<Result<String, GarageError>> createMotorcycle(CreateMotorcycleRequest request);

  /// Modifica una moto esistente.
  /// Solo i campi non-null nel request vengono aggiornati.
  Future<Result<void, GarageError>> updateMotorcycle(
    String clientId,
    UpdateMotorcycleRequest request,
  );

  /// Soft delete di una moto.
  /// Se era primaria e ne esistono altre, promuove la piu' vecchia non-deleted a primaria.
  Future<Result<void, GarageError>> deleteMotorcycle(String clientId);

  /// Imposta una moto come primaria. Azzera il flag sulla primaria precedente.
  Future<Result<void, GarageError>> setPrimary(String clientId);

  // ---------- FOTO ----------

  /// Upload foto moto.
  /// - fullBytes: immagine full-res, max 2 MB dopo compressione.
  /// - thumbBytes: thumbnail 256x256 WebP, max 50 KB.
  /// Idempotency garantita via path deterministic su Storage.
  Future<Result<void, GarageError>> uploadPhoto(
    String clientId, {
    required Uint8List fullBytes,
    required Uint8List thumbBytes,
  });

  /// Rimuove la foto della moto (lascia la moto, azzera i campi photo_*).
  /// I file su Storage vengono cancellati (o orphan cleaner pg_cron settimanale, vedi A.18 storage).
  Future<Result<void, GarageError>> removePhoto(String clientId);
}
```

---

## Sezione 3 -- Eventi emessi sul bus

### 3.1 `MotorcycleCreatedEvent`

```dart
@freezed
class MotorcycleCreatedEvent with _$MotorcycleCreatedEvent {
  const factory MotorcycleCreatedEvent({
    required String clientId,
    required String ownerId,
    required String name,
    required DateTime createdAt,
    required bool isPrimary, // true se e' la prima moto del owner
  }) = _MotorcycleCreatedEvent;
}
```

### 3.2 `MotorcycleUpdatedEvent`

```dart
@freezed
class MotorcycleUpdatedEvent with _$MotorcycleUpdatedEvent {
  const factory MotorcycleUpdatedEvent({
    required String clientId,
    required String ownerId,
    required DateTime updatedAt,
    required int version,
    required Set<String> changedFields,
  }) = _MotorcycleUpdatedEvent;
}
```

**Nota su `changedFields`:** e' un insieme di nomi di campo modificati in questa update. Consumatori interessati a certi campi (es. UI home che ascolta cambi `total_km`) filtrano. Evita re-render inutili.

### 3.3 `MotorcycleDeletedEvent`

```dart
@freezed
class MotorcycleDeletedEvent with _$MotorcycleDeletedEvent {
  const factory MotorcycleDeletedEvent({
    required String clientId,
    required String ownerId,
    required DateTime deletedAt,
    required bool wasPrimary,
  }) = _MotorcycleDeletedEvent;
}
```

### 3.4 `PrimaryMotorcycleChangedEvent`

```dart
@freezed
class PrimaryMotorcycleChangedEvent with _$PrimaryMotorcycleChangedEvent {
  const factory PrimaryMotorcycleChangedEvent({
    required String ownerId,
    required String newPrimaryClientId,
    required String? previousPrimaryClientId,
  }) = _PrimaryMotorcycleChangedEvent;
}
```

---

## Sezione 4 -- Eventi consumati

### 4.1 `ActivityCompletedEvent` (dal modulo tracking)

Payload noto, definito in `04_tracking/L05_interfaces.md` Sezione 4.3.

**Reazione garage:** `km_aggregator` ascolta questi eventi. Se `motorcycleClientId != null`, aggiorna `total_km` in optimistic mode:

```dart
final currentTotal = await dao.getTotalKm(motorcycleClientId);
final newTotal = currentTotal + distanceKm;
await dao.updateTotalKm(motorcycleClientId, newTotal);
// emit MotorcycleUpdatedEvent con changedFields = {'totalKm'}
```

Al prossimo sync / rehydration, il server ricalcolera' e il valore locale verra' sovrascritto con quello canonico.

### 4.2 `UserLoggedOutEvent` / `UserLoggedInEvent`

Nessuna reazione specifica. Le moto sono filtrate `WHERE owner_id = currentUserId` in ogni query.

---

## Sezione 5 -- `GarageModule` (manifest)

```dart
class GarageModule extends AppModule {
  @override
  String get name => 'garage';

  @override
  List<String> get dependsOn => [
    'shared.db',
    'shared.event_bus',
    'shared.auth',
    'shared.storage',
  ];

  @override
  List<Type> get provides => [MotorcycleApi];

  @override
  List<Type> get consumes => []; // il garage non dipende da altri moduli

  @override
  void register(ModuleRegistry r) {
    final db = r.resolve<AppDatabase>();
    final bus = r.resolve<EventBus>();
    final auth = r.resolve<AuthService>();
    final storage = r.resolve<StorageClient>();

    final dao = MotorcyclesDao(db);
    final photoService = PhotoService(storage: storage);
    final service = MotorcycleService(
      dao: dao,
      bus: bus,
      auth: auth,
      photoService: photoService,
    );

    // km_aggregator si registra sul bus al bootstrap
    final kmAggregator = KmAggregator(dao: dao, bus: bus);

    r.registerApi<MotorcycleApi>(MotorcycleApiImpl(service));
    r.registerBootstrapTask(kmAggregator.start);
  }
}
```

---

## Sezione 6 -- Thread model

Tutte le operazioni del garage sono su main isolate. Non ci sono callback da background service.

L'unica eccezione e' il `km_aggregator`, che ascolta `ActivityCompletedEvent` -- questo evento viene emesso dal main isolate comunque (il tracking controller ha gia' fatto il bridging background -> main quando transiziona a `idle` post-stop).

---

## Sezione 7 -- Test contracts

Vedi `L0_architecture.md` Sezione 11. In aggiunta:

### 7.1 Test per API Result

Ogni metodo con `Result` deve avere:

1. **Happy path**: ritorna `Ok(...)`.
2. **Validation error**: campi invalidi -> `Err(ValidationError)`.
3. **Not found**: clientId inesistente -> `Err(MotorcycleNotFoundError)` per update/delete/setPrimary/uploadPhoto/removePhoto.
4. **NotOwner**: clientId di moto appartenente a altro owner -> `Err(NotOwnerError)`.

### 7.2 Test per Stream

- `watchAllMotorcycles` emette lista corretta dopo INSERT.
- `watchAllMotorcycles` emette lista aggiornata dopo UPDATE (`total_km` cambia via km_aggregator).
- `watchAllMotorcycles` emette lista senza moto soft-deleted.
- `watchStats` aggrega correttamente activity associate.

---

**Fine 06_garage/L05_interfaces.md**
