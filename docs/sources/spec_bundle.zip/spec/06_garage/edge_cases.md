# 06 / Garage -- Edge Cases

**Scopo:** catalogo dei casi limite del modulo garage, con comportamento atteso.

**Riferimenti:**

- Architettura: `L0_architecture.md`.
- API: `L05_interfaces.md`.
- Invarianti km server: D.17 in `99_open_questions.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Creazione moto

### 1.1 Prima moto dell'utente

**Scenario:** utente non ha nessuna moto. Crea la prima.

**Atteso:**
- Service verifica `getAllMotorcycles(ownerId).isEmpty == true`.
- Crea moto con `is_primary = true` (auto-promozione).
- `MotorcycleCreatedEvent` con `isPrimary = true`.
- `PrimaryMotorcycleChangedEvent` NON viene emesso -- non c'era previous primary. Evita falsi trigger.

### 1.2 Moto con nome duplicato

**Scenario:** utente ha gia' una moto "Ducati Panigale". Tenta crearne un'altra con stesso nome.

**Default:** nessun vincolo DB di unicita'.

**Atteso:**
- Creazione consentita. Due moto con stesso `name` sono lecite (puo' essere cambio di modello, o semplicemente l'utente vuole cosi').
- UI potrebbe mostrare warning soft "Hai gia' una moto con questo nome" ma non bloccare.

### 1.3 Campo `odometer_start_km` negativo

**Scenario:** utente inserisce -500.

**Atteso:** `ValidationError('odometer_start_km', 'Km non validi')` da service. Form non chiude.

### 1.4 Anno > anno corrente + 1

**Scenario:** siamo nel 2026, utente inserisce 2030.

**Atteso:** `ValidationError('year', 'Anno non valido')`. L'anno "anno prossimo" e' ammesso (moto 2027 presentata in anticipo in autunno 2026 e' reale).

### 1.5 Concorrenza crea + sync

**Scenario:** utente crea moto, sync parte, utente modifica foto prima che sync completi.

**Atteso:**
- INSERT enqueued -> in_flight.
- UPDATE accodato dopo. Coalescence decide: poiche' INSERT in_flight, UPDATE viene mantenuto separato.
- INSERT completa, poi UPDATE completa. Server vede moto creata + poi aggiornata foto.

Vedi `05_sync/idempotency.md` Sezione 6.2.

---

## Sezione 2 -- Modifica moto

### 2.1 Modifica di campo mentre sync sta uploading

Gestito da sync coalescence (come 1.5).

### 2.2 Modifica ultra-rapida (doppio tap save)

**Scenario:** utente tap Save due volte in 50ms.

**Atteso:**
- Service con mutex interno (coerente con pattern tracking di `_operationLock`).
- Seconda invocazione aspetta. Al termine della prima, seconda vede version gia' incrementata e applica SUO delta su version attuale. `version+1` alla seconda chiamata e' effettivamente `v_attuale + 1`, non +2.

### 2.3 Modifica di moto soft-deleted

**Scenario:** bug UI espone pulsante modifica su moto soft-deleted.

**Atteso:**
- `getMotorcycle(clientId)` ritorna null per soft-deleted.
- Service: `MotorcycleNotFoundError`.

### 2.4 Modifica di moto di altro owner (bug sicurezza)

**Scenario:** chiamante tenta `updateMotorcycle(clientId)` dove la moto appartiene a un altro utente.

**Atteso:**
- Service verifica `motorcycle.ownerId == currentUserId`. Se no: `NotOwnerError`.
- RLS Postgres bloccherebbe comunque al momento del sync, ma il check client-side e' difesa in profondita'.

### 2.5 `version` non incrementa mai

**Scenario:** bug. Service dimentica di incrementare `version`.

**Mitigazione:** unit test specifici verificano che dopo ogni update `version` sia cresciuto di +1. Inoltre server (post-MVP) rifiuterebbe updates con version stale.

---

## Sezione 3 -- Selezione moto primaria

### 3.1 Set primary su moto gia' primaria

**Scenario:** utente tap "imposta come primaria" sulla moto che e' gia' primaria.

**Atteso:**
- Service no-op. Nessun evento emesso. Nessun DB write.
- Ritorna `Ok(())` (successo logico senza effetti).

### 3.2 Set primary su moto di altro owner

**Atteso:** `NotOwnerError`.

### 3.3 Set primary su moto soft-deleted

**Atteso:** `MotorcycleNotFoundError` -- soft-deleted sono invisibili.

### 3.4 Cambio primary in mezzo a un giro in corso

**Scenario:** utente sta registrando con moto X (primaria al momento dello start). Durante il giro, nelle impostazioni cambia primaria a moto Y.

**Atteso:**
- Il tracking ha gia' registrato `motorcycle_id = X` nel `RecordingSession.motorcycleId` al momento dello start. Non cambia a meta' giro.
- Alla chiusura, l'Activity e' attribuita a X.
- La primary da quel momento in poi e' Y (solo per future registrazioni).

### 3.5 Race: utente elimina moto primaria mentre la sta impostando

Scenario surreale ma:
- Se delete arriva prima: la moto sparisce. setPrimary fallisce con NotFound.
- Se setPrimary arriva prima: l'altra moto diventa primaria, poi delete la cancella.

Mutex di service serializza. Non e' race reale, sono sequenziali.

---

## Sezione 4 -- Eliminazione moto

### 4.1 Eliminazione unica moto

**Scenario:** utente ha una sola moto, la elimina.

**Atteso:**
- Soft delete.
- `wasPrimary = true` nell'evento.
- **Nessuna promozione** (non ci sono altre moto).
- UI mostra garage vuoto. CTA "Aggiungi una moto".
- Activity passate restano con `motorcycle_id` valorizzato (alla moto soft-deleted). Nelle UI statistiche, l'utente vede "Moto: [eliminata]" o l'ultimo nome noto.

### 4.2 Eliminazione moto primaria con altre presenti

**Scenario:** utente ha 3 moto (A primaria, B e C). Elimina A.

**Atteso:**
- Soft delete A.
- Service cerca tra non-deleted quella piu' vecchia (o per `created_at ASC`).
- Promuove B a primary (ipotizzando B creata prima di C).
- Eventi emessi: `MotorcycleDeletedEvent(A, wasPrimary=true)`, `MotorcycleUpdatedEvent(B, changedFields={isPrimary})`, `PrimaryMotorcycleChangedEvent(newPrimary=B, previous=A)`.
- Sync: enqueue 2 UPDATE + 1 DELETE.

### 4.3 Eliminazione moto non primaria

**Scenario:** utente ha 3 moto (A primaria, B e C). Elimina B.

**Atteso:**
- Soft delete B. Nessuna promozione.
- `MotorcycleDeletedEvent(B, wasPrimary=false)`.

### 4.4 Eliminazione con activity associate

**Scenario:** la moto ha 50 activity associate.

**Atteso:**
- Delete procede. Activity non vengono toccate (FK rimane valorizzata anche su moto soft-deleted).
- `total_km` calcolato server-side dal trigger continua a funzionare. Client non piu' visualizza la moto quindi non c'e' UI conseguenza.
- Futuro: se utente "ripristina" moto (feature non MVP), le activity tornano visibili automaticamente.

### 4.5 Eliminazione in corso, sync in volo

Gestito da sync coalescence:
- Se INSERT di B in_flight: DELETE di B accodato, eseguito dopo. Server riceve INSERT poi soft DELETE.
- Se INSERT di B ancora queued: INSERT + DELETE coalescono -> entrambi rimossi dalla coda. La moto non arriva mai al server. Eliminazione pulita.

---

## Sezione 5 -- Foto moto

### 5.1 Upload foto > 2MB dopo compressione

**Atteso:** `PhotoTooLargeError` con size / max.

### 5.2 Upload fallisce a meta'

**Scenario:** network cade durante upload.

**Atteso:**
- `PhotoUploadFailedError` ritornato all'UI.
- UI offre "Riprova" / "Annulla".
- Moto resta con vecchia foto (o nessuna) in drift. Nessun campo aggiornato se upload non completa.

### 5.3 Upload riuscito ma UPDATE drift fallisce

**Scenario:** file gia' su Storage, ma service fallisce a update `motorcycles_local.photo_storage_path`.

**Atteso:**
- Storage ha file "orfano" (path presente ma non referenziato).
- Client ritenta UPDATE drift. Se ripete successo: UPDATE passa. Nessun duplicate upload richiesto (path deterministic, file gia' presente).
- Se ripete failure: errore a UI. File orfano viene catturato da pg_cron settimanale di orphan cleanup (vedi `05_sync/idempotency.md` Sezione 5.4).

### 5.4 Sostituzione foto (upload con foto gia' presente)

**Atteso:**
- Path deterministic: stesso `{owner_id}/{motorcycle_client_id}_full.jpg`.
- `upsert: true` sovrascrive bytes.
- UPDATE `motorcycles_local.photo_storage_path` non cambia (gia' quel path). Forse aggiorno solo `updated_at`, `version + 1` per notificare UI.

### 5.5 Rimozione foto (`removePhoto`)

**Atteso:**
- UPDATE `photo_storage_path = NULL`, `photo_storage_path_thumb = NULL`.
- Opzionalmente: DELETE su Storage immediato (1 API call).
- Fallimento DELETE Storage non blocca: orphan cleaner pg_cron gestira'.

### 5.6 Cache locale foto non disponibile

Vedi D.40 (`local_cache_path`). Se il file locale e' stato pulito dall'OS, al prossimo accesso UI:
- `File(resolveLocalFullPath(...)).exists() == false`.
- Download da Storage via `photo_storage_path_thumb` (thumb e' piu' veloce).
- Salva in cache locale, continua la UI.

---

## Sezione 6 -- km aggregator e total_km

### 6.1 Optimistic update su moto che arriva dall'evento ma non esiste in drift

**Scenario:** `ActivityCompletedEvent` arriva con `motorcycle_client_id = X` ma drift non ha riga X (caso borderline: moto cancellata client-side ma Activity aveva gia' registrato ref).

**Atteso:**
- `kmAggregator` fa `dao.getMotorcycle(X)`. Ritorna null.
- Skip silenzioso. Server (che ha la moto) ricalcolera' comunque al sync.
- Log debug (no error, e' edge atteso).

### 6.2 Double emission stesso evento

**Scenario:** bug emette `ActivityCompletedEvent` due volte per stessa activity.

**Atteso problematico:** `total_km` incrementato due volte.

**Mitigazione:**
- Teniamo un `Set<String>` in-memory di `activity_client_id` gia' processati dall'aggregator. Evita doppi increment.
- Al bootstrap il set e' vuoto -- va bene, se l'utente ha chiuso l'app l'evento e' gia' stato processato a suo tempo.

**Strategia migliore (post-MVP):** non fare optimistic lato aggregator, semplicemente leggere il `total_km` dal server a ogni fetch. Meno reattivo ma piu' robusto.

### 6.3 Optimistic diverge dal server

**Scenario:** client ha accumulato total_km = 1500, server ha 1487 (10 km Activity non ancora sincronizzate + server decimazione che calcola leggermente diversamente).

**Atteso:**
- Alla prossima rehydration / fetch della moto da server (es. pull esplicita per dettaglio), il client sovrascrive il valore locale con quello server.
- Se l'utente ha Activity ancora in `pending`, il server non le ha contate. Divergenza temporanea.
- Dopo sync, server ricalcola. Ricompattamento al prossimo fetch.

**Tradeoff accettato:** MVP fa questa "riconciliazione su fetch" invece di eventi di sync esplicito. Ragionevolmente preciso.

### 6.4 Activity discarded / deleted dopo optimistic increment

**Scenario:** Activity completata (`total_km += 80 km`), ma poi utente la elimina dall'app.

**Atteso:**
- Eliminazione Activity -> `ActivityDeletedEvent` (non ancora definito, futuro).
- `kmAggregator` ascolta anche questo, applica decremento `-80 km`.
- Server trigger ricalcolera' comunque al sync.

**Strategia MVP semplificata:** non ascoltare `ActivityDeletedEvent`. Il client-side optimistic resta gonfiato finche' non arriva il fetch server-side.

**Coerente con Sezione 6.3**: client optimistic e' tentativo, server canonico. Eventual consistency.

---

## Sezione 7 -- Edge su lifecycle

### 7.1 Logout mid-operazione

**Scenario:** utente in form "crea moto", click Save, logout tra validazione e INSERT.

**Atteso:**
- Operazione completa con `owner_id = currentUserId PRE-logout`.
- Dopo logout: moto in drift appartenente a utente A.
- B fa login: `watchAllMotorcycles(B)` non include la moto di A (filtro owner_id).
- Al ri-login di A: moto visibile, in sync_queue con owner_id=A (fix D.37), sync parte.

### 7.2 App kill durante upload foto

**Scenario:** upload foto in progress, app killata.

**Atteso:**
- Alla riapertura, stato moto in drift e' pre-upload (foto non aggiornata).
- File su Storage potrebbe essere parziale / corrotto -- ma bucket Supabase rifiuta upload parziali tipicamente.
- Se per caso e' presente: orphan cleaner lo rimuove.
- UI non mostra foto (campo DB ancora null). Utente puo' ritentare.

### 7.3 Multiple isolate che scrivono su `motorcycles_local`

**Atteso:** impossibile by design. Writer unico e' il service, sul main isolate. Background service non tocca motorcycles.

L'unica eccezione e' sync orchestrator (vedi `03_local_db.md` Sezione 6.2 nota writer), che scrive `sync_state` sulle tabelle sincronizzate. Ma non tocca campi di dominio.

---

## Sezione 8 -- Checklist QA

- [ ] Prima moto creata diventa automaticamente primaria.
- [ ] Seconda moto creata NON diventa primaria (resta la prima).
- [ ] setPrimary cambia flag correttamente sulle due moto.
- [ ] deleteMotorcycle di primaria con altre moto presenti promuove la piu' vecchia.
- [ ] deleteMotorcycle di unica moto lascia utente senza primaria.
- [ ] ActivityCompletedEvent incrementa total_km della moto referenziata.
- [ ] Fetch dopo sync riconcilia total_km con server.
- [ ] Upload foto > 2MB: error.
- [ ] Upload foto con network fail: error UI, moto non aggiornata.
- [ ] Sostituzione foto sovrascrive path deterministic.
- [ ] Validazione: name vuoto, brand vuoto, year fuori range.
- [ ] Soft-deleted moto non compare nel feed ma total_km rimane calcolabile.
- [ ] Logout e ri-login: coda sync conserva item.
- [ ] Modifica moto doppio-tap rapido: nessun incremento version spurio.

---

## Sezione 9 -- Open items specifici garage

Nessuno nuovo. Tutti i temi trasversali sono gia' tracciati in `99_open_questions.md`:

- A.18 per policy foto failed in UI.
- A.20 per batteria critica (impatta anche scritture garage).
- D.40 per `local_cache_path` pattern (applicabile a foto moto).

---

**Fine 06_garage/edge_cases.md**
