# 06 / Garage -- L0 Architecture

**Scopo:** gestione delle moto dell'utente. CRUD moto, foto, selezione moto primaria, calcolo km, aggregati per moto (activity count, distanza totale).

**Cosa NON e' qui:**

- La scelta della moto durante la registrazione di un'attivita' (quello e' in `04_tracking/`).
- Lo schema DB delle motorcycles (in `02_database_schema.md` Sezione 3.2 e `03_local_db.md` Sezione 4.2).
- La sincronizzazione delle moto verso il server (in `05_sync/`).

**Riferimenti:**

- Entita' Motorcycle: `01_data_model.md` Sezione 3.
- Schema Postgres: `02_database_schema.md` Sezione 3.2.
- Schema drift: `03_local_db.md` Sezione 4.2.
- Trigger km: D.17 in `99_open_questions.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Il modulo garage offre un'esperienza "officina personale": l'utente vede le sue moto, ne aggiunge di nuove, tiene traccia dei chilometri per ciascuna, associa foto. Le attivita' registrate nel modulo tracking vengono automaticamente attribuite alla moto selezionata al momento della registrazione.

**Principio guida:** il garage e' **owner** delle moto. Ogni altro modulo che ha bisogno di informazioni su una moto (tracking, community, safety) le legge via `MotorcycleApi`. Solo il garage scrive sulla tabella `motorcycles_local`.

---

## Sezione 2 -- Struttura interna

```
modules/garage/
|-- lib/
|   |-- garage.dart                   (export pubblico)
|   |-- api.dart                      (MotorcycleApi, tipi pubblici)
|   +-- src/
|       |-- domain/
|       |   |-- motorcycle.dart       (value object + invarianti)
|       |   |-- motorcycle_stats.dart (aggregati)
|       |   +-- garage_error.dart
|       |-- application/
|       |   |-- motorcycle_service.dart (CRUD + orchestrazione)
|       |   |-- km_aggregator.dart      (ascolta ActivityCompletedEvent)
|       |   +-- photo_service.dart      (upload foto moto)
|       |-- persistence/
|       |   |-- motorcycles_dao.dart
|       |   +-- motorcycle_repository.dart
|       +-- ui/
|           |-- garage_screen.dart
|           |-- motorcycle_detail_screen.dart
|           |-- motorcycle_form_screen.dart
|           +-- widgets/
|-- test/
+-- pubspec.yaml
```

**Strati:**

- `domain/`: value objects puri, invarianti, zero dipendenze esterne.
- `application/`: logica di business, orchestrazione DAO + eventi.
- `persistence/`: DAO drift (owner writer di `motorcycles_local`).
- `ui/`: screen e widget. Usa solo `MotorcycleApi` pubblica.

---

## Sezione 3 -- API pubblica

Esportata da `modules/garage/lib/api.dart`. Dettagli di firma in `L05_interfaces.md`.

Lista dei metodi offerti (sintesi, non-signature):

**Query (sola lettura):**
- `watchAllMotorcycles(ownerId)` -> Stream<List<MotorcycleSummary>>
- `getMotorcycle(clientId)` -> Future<MotorcycleDetail?>
- `exists(clientId)` -> Future<bool>
- `getPrimary(ownerId)` -> Future<MotorcycleSummary?>
- `watchStats(clientId)` -> Stream<MotorcycleStats>

**Mutazioni:**
- `createMotorcycle(CreateMotorcycleRequest)` -> Future<Result<String, GarageError>>
- `updateMotorcycle(clientId, UpdateMotorcycleRequest)` -> Future<Result<void, GarageError>>
- `deleteMotorcycle(clientId)` -> Future<Result<void, GarageError>>
- `setPrimary(clientId)` -> Future<Result<void, GarageError>>

**Foto:**
- `uploadPhoto(clientId, bytes)` -> Future<Result<void, GarageError>>
- `removePhoto(clientId)` -> Future<Result<void, GarageError>>

---

## Sezione 4 -- Eventi emessi sul bus

### 4.1 `MotorcycleCreatedEvent`

Quando una nuova moto e' stata salvata localmente. Consumatori attesi: modulo sync (enqueue upload).

Payload: `clientId`, `ownerId`, `name`, `createdAt`.

### 4.2 `MotorcycleUpdatedEvent`

Quando una moto e' stata modificata localmente. Consumatori: sync (enqueue update).

Payload: `clientId`, `ownerId`, `updatedAt`, `version`.

### 4.3 `MotorcycleDeletedEvent`

Quando una moto e' stata soft-deleted. Consumatori: sync (enqueue soft delete), notifications (opzionale).

Payload: `clientId`, `ownerId`, `deletedAt`.

### 4.4 `PrimaryMotorcycleChangedEvent`

Quando l'utente cambia moto primaria. Consumatori: UI home screen (aggiorna indicator), eventuale modulo onboarding.

Payload: `ownerId`, `newPrimaryClientId`, `previousPrimaryClientId?`.

---

## Sezione 5 -- Eventi consumati

### 5.1 `ActivityCompletedEvent` (dal modulo tracking)

**Reazione garage:** `km_aggregator` legge l'evento e aggiorna il `total_km` locale della moto referenziata via optimistic update (+distance_km dell'attivita').

**Perche' ottimistico:** il valore server-side e' canonico (calcolato da trigger Postgres `recompute_motorcycle_km`, vedi D.17). Al prossimo sync, il server ricalcolera' e rispondera' con il valore corretto. Nel frattempo, lato UI l'utente vede subito il delta.

**Rischio:** se l'Activity poi viene scartata o non sincronizza mai, il client avra' un valore gonfiato. Mitigazione: al momento di `ActivityDiscardedEvent` (non ancora definito ma simmetrico), decrementare.

**Semplificazione MVP:** il server e' source of truth. Ad ogni rehydration / fetch periodico di `motorcycle.total_km`, il client sovrascrive il valore locale. Non serve orchestrare rollback complessi.

### 5.2 `UserLoggedOutEvent`

Nessuna reazione specifica. Le moto restano in drift, filtrate al prossimo login by `owner_id`.

---

## Sezione 6 -- Interazioni operative

### 6.1 Creazione di una moto

1. UI raccoglie dati in `motorcycle_form_screen`.
2. Tap "Salva" -> `MotorcycleApi.createMotorcycle(request)`.
3. Service:
   - Genera `client_id` UUID v4.
   - Valida i campi (Sezione 7).
   - Verifica invarianti (Sezione 8).
   - Insert in drift con `sync_state = 'pending'`.
   - Emette `MotorcycleCreatedEvent`.
4. Sync orchestrator ascolta e accoda upload.
5. UI rientra al garage_screen, la nuova moto compare tramite stream (drift notifica cambiamento).

### 6.2 Selezione moto primaria

Regola prodotto: ogni utente ha zero o una moto primaria. La prima moto creata e' automaticamente primaria. Cambio primaria:

1. UI tap "Imposta come primaria" su altra moto.
2. `MotorcycleApi.setPrimary(newClientId)`.
3. Service in una transazione drift:
   - `UPDATE motorcycles_local SET is_primary = false WHERE owner_id = ? AND is_primary = true`.
   - `UPDATE motorcycles_local SET is_primary = true WHERE client_id = ?`.
   - `updated_at = now()` + `version + 1` su entrambe.
4. Emette `PrimaryMotorcycleChangedEvent` + 2 `MotorcycleUpdatedEvent` (una per moto).
5. Sync accoda 2 UPDATE.

### 6.3 Upload foto moto

1. UI apre image picker, utente seleziona foto.
2. Thumbnail generato client-side (256x256 WebP).
3. `MotorcycleApi.uploadPhoto(clientId, fullBytes, thumbBytes)`.
4. Photo service:
   - Upload `photo_full.jpg` su Supabase Storage bucket `motorcycle_photos` al path `{user_id}/{motorcycle_client_id}_full.jpg`.
   - Upload thumb analoga.
   - UPDATE motorcycles_local `photo_storage_path = ...`, `photo_storage_path_thumb = ...`.
   - Emette `MotorcycleUpdatedEvent`.

**Idempotency:** upload con `upsert: true`, path deterministic (vedi `05_sync/idempotency.md` Sezione 5.2). Sostituzione foto = sovrascrittura stesso path.

### 6.4 Eliminazione moto

Soft delete. Moto sparisce dalla UI garage ma:
- Activity associate **non** vengono modificate (`motorcycle_id` resta valorizzato anche se moto soft-deleted).
- Trigger server `recompute_motorcycle_km` continua a funzionare su moto soft-deleted (conta le activity).
- UI filtra moto con `deleted_at NOT NULL` dal garage_screen. Le vede solo admin (se mai consultasse).

---

## Sezione 7 -- Validazione campi

| Campo | Regola | Messaggio errore |
|---|---|---|
| `name` | 1-50 caratteri, non solo whitespace | "Nome obbligatorio" |
| `brand` | 1-50 caratteri | "Marca obbligatoria" |
| `model` | 1-100 caratteri | "Modello obbligatorio" |
| `year` | nullable, se presente: 1900-anno corrente+1 | "Anno non valido" |
| `engine_cc` | nullable, se presente: 1-3000 | "Cilindrata non valida" |
| `color` | nullable, max 30 caratteri | "Colore troppo lungo" |
| `odometer_start_km` | >= 0, default 0 | "Km non validi" |

Validazione avviene in `MotorcycleService` prima di toccare il DB. Errori ritornano `GarageError.validation(field, message)`.

---

## Sezione 8 -- Invarianti

### I.1 -- Max una moto primaria per owner

**Enforced da:** unique index parziale `(owner_id) WHERE is_primary = true AND deleted_at IS NULL` su `motorcycles_local` + stesso su Postgres.

### I.2 -- Se owner ha >= 1 moto non soft-deleted, deve esisterne una primaria

**NON enforced a livello DB** (troppo restrittivo). Enforced lato application:
- Dopo `deleteMotorcycle`, se la moto era primaria e ne esiste almeno un'altra non-deleted, service promuove a primary la piu' vecchia non-deleted (o la prima in lista).
- Dopo `createMotorcycle`, se l'utente non aveva altre moto, la nuova diventa automaticamente primaria.

### I.3 -- `total_km >= odometer_start_km`

Server trigger `recompute_motorcycle_km` calcola sempre `total_km = odometer_start_km + SUM(distance_km activity)`. Quindi >= odometer_start_km by construction.

Client-side optimistic update preserva questa relazione semplicemente sommando.

### I.4 -- Foto appartiene alla moto

Storage path deve iniziare con `{owner_id}/` che corrisponde all'`owner_id` della moto. RLS policies Storage enforceranno. Client scrive path deterministic, non errate.

---

## Sezione 9 -- Dipendenze del modulo

### Consumes:

- `shared/db/AppDatabase` per tabella `motorcycles_local`.
- `shared/event_bus/EventBus` per emit/listen.
- `shared/auth/AuthService` per `currentUserId`.
- `shared/storage/StorageClient` per upload foto.

### Provides:

- `MotorcycleApi` (principale).

### No direct dependency su altri moduli.**

Per leggere le activity count aggregata per moto: consuma `ActivitiesReadRepository` condiviso in `shared/db/repositories/` (vedi `03_local_db.md` Sezione 2.3), non direttamente dal modulo tracking.

---

## Sezione 10 -- Performance

**Dimensioni tipiche:** un utente ha in media 1-3 moto. Max realistico: 20 (collezionista). Query garage e' O(N) su N piccolo -> nessuna ottimizzazione specifica.

**Stream drift:** `watchAllMotorcycles` -> emissione a ogni INSERT/UPDATE/DELETE su `motorcycles_local`. In pratica: rarissimi.

**Foto:**
- File completo: max 2 MB dopo compressione client-side (85% JPEG quality).
- Thumbnail: max 50 KB.
- Upload quando online; in offline, la foto sta in filesystem locale via `local_cache_path` pattern (analogo a `activity_media` D.40).

**Calcolo km ottimistico:** operazione O(1), zero impatto performance.

---

## Sezione 11 -- Testing

### 11.1 Unit test

- Validazione campi (tutti i casi di Sezione 7).
- Invarianti (creazione prima moto -> primaria; cancellazione primaria con altre presenti -> promozione; cancellazione ultima moto -> nessuna primaria).
- km_aggregator: simula ActivityCompletedEvent con moto X -> total_km di X incrementato.

### 11.2 Integration test (drift in-memory)

- Create + read + update + delete cycle.
- Set primary with multiple motorcycles.
- Soft delete non nasconde activity associate.

### 11.3 UI test

- garage_screen: lista vuota -> CTA "Aggiungi la prima moto".
- Form completo flow.
- Upload foto flow (con mock Storage).

---

**Fine 06_garage/L0_architecture.md**
