# 02 -- Database Schema (Postgres / Supabase)

**Scopo:** schema completo del database Supabase. DDL di tutte le tabelle, enum, funzioni, trigger, RLS policies, storage, pg_cron jobs.

**Cosa NON e' in questo documento:**

- Tabelle drift locali puramente client (vivono in `03_local_db.md`). In particolare: `recording_sessions`, `track_point_buffer`, `sync_queue`.
- Tabelle drift che sono replica delle server-side: le dichiareremo in `03_local_db.md` con la stessa shape ma driver-specific (colonne drift, JSON serialization, ecc.).

**Riferimenti:**
- Entita' logiche: `01_data_model.md`.
- Matrice RLS alto livello: `00_overview.md` Sezione 6.
- Decisioni di setup: `00_overview.md` Sezione 5.

**Convenzioni:**
- Tutto snake_case.
- Identificatori `client_id` e `id` come da overview Sezione 5.12.
- Soft delete via `deleted_at TIMESTAMPTZ NULL` dove previsto.
- Timestamp sempre `TIMESTAMPTZ` (mai `TIMESTAMP` senza timezone).

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Estensioni Postgres richieste

```sql
-- Abilitate in Supabase dashboard prima di applicare migrations.
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";
CREATE EXTENSION IF NOT EXISTS "pg_cron";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";   -- per trigram search su username
CREATE EXTENSION IF NOT EXISTS "btree_gin"; -- per GIN su text[] tags
```

---

## Sezione 2 -- Enum types

Raggruppati all'inizio del progetto per chiarezza.

```sql
CREATE TYPE profile_role AS ENUM ('user', 'admin');

CREATE TYPE activity_visibility AS ENUM ('private', 'followers', 'public');

CREATE TYPE planned_route_source AS ENUM ('drawn', 'imported_gpx', 'generated');

CREATE TYPE published_route_source_type AS ENUM ('activity', 'planned_route');

CREATE TYPE live_session_state AS ENUM (
  'active',
  'ended_normal',
  'ended_timeout',
  'ended_by_leader'
);

CREATE TYPE safety_event_type AS ENUM (
  'sos_manual',
  'long_silence',
  'crash_detected'
);

CREATE TYPE notification_type AS ENUM (
  'new_follower',
  'new_comment_on_route',
  'new_like_on_route',
  'live_session_invite',
  'safety_event_triggered',
  'system_message'
);

CREATE TYPE error_log_level AS ENUM ('warn', 'error', 'fatal');

CREATE TYPE platform_type AS ENUM ('android', 'ios');

CREATE TYPE track_point_state AS ENUM (
  'normal',
  'tunnel_entry',
  'tunnel_exit',
  'paused_marker',
  'recovered_marker'
);
-- Nota: track_point_state vive in realta' dentro il jsonb track_points_data,
-- quindi l'enum Postgres e' informativo. In drift locale e' enum vero
-- sulla colonna di track_point_buffer (vedi 03_local_db.md).
```

---

## Sezione 3 -- Tabelle

### 3.1 `profiles`

```sql
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE
    CHECK (username ~ '^[a-z0-9_]{3,30}$'),
  display_name TEXT NOT NULL
    CHECK (length(display_name) BETWEEN 1 AND 50),
  bio TEXT
    CHECK (bio IS NULL OR length(bio) <= 500),
  avatar_storage_path TEXT,
  role profile_role NOT NULL DEFAULT 'user',
  is_public BOOLEAN NOT NULL DEFAULT TRUE,
  feature_flags JSONB NOT NULL DEFAULT '{}'::jsonb,
  -- Stato moderazione account (vedi Sezione 4.8 + moderazione base in 07_community/).
  -- Valori: 'active' | 'suspended' | 'banned' | 'deleted_pending_hard'.
  -- RLS policies filtrano automaticamente account non-active da letture pubbliche.
  account_status TEXT NOT NULL DEFAULT 'active'
    CHECK (account_status IN ('active', 'suspended', 'banned', 'deleted_pending_hard')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_profiles_username_trgm
  ON profiles USING gin (username gin_trgm_ops);

CREATE INDEX idx_profiles_is_public
  ON profiles (is_public) WHERE deleted_at IS NULL;

CREATE INDEX idx_profiles_account_status
  ON profiles (account_status) WHERE account_status != 'active';
```

**Trigger dedicato alla creazione automatica:**

```sql
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    username,
    display_name
  ) VALUES (
    NEW.id,
    -- username provvisorio basato su email, user puo' cambiarlo entro 7 giorni
    'user_' || substring(replace(NEW.id::text, '-', '') from 1 for 12),
    coalesce(NEW.raw_user_meta_data->>'display_name', 'Rider')
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```

### 3.2 `motorcycles`

```sql
CREATE TABLE motorcycles (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  name TEXT NOT NULL
    CHECK (length(name) BETWEEN 1 AND 50),
  brand TEXT NOT NULL
    CHECK (length(brand) BETWEEN 1 AND 50),
  model TEXT NOT NULL
    CHECK (length(model) BETWEEN 1 AND 100),
  year INTEGER
    CHECK (year IS NULL OR (year BETWEEN 1900 AND 2100)),
  engine_cc INTEGER
    CHECK (engine_cc IS NULL OR (engine_cc BETWEEN 50 AND 3000)),
  color TEXT,
  photo_storage_path TEXT,
  odometer_start_km NUMERIC(10,2) NOT NULL DEFAULT 0
    CHECK (odometer_start_km >= 0),
  total_km NUMERIC(10,2) NOT NULL DEFAULT 0,
  is_primary BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 0
);

-- Invariante I.5: massimo una moto primary per owner.
CREATE UNIQUE INDEX idx_motorcycles_one_primary
  ON motorcycles (owner_id)
  WHERE is_primary = TRUE AND deleted_at IS NULL;

CREATE INDEX idx_motorcycles_owner
  ON motorcycles (owner_id) WHERE deleted_at IS NULL;
```

### 3.3 `activities`

```sql
CREATE TABLE activities (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  motorcycle_id UUID REFERENCES motorcycles(client_id) ON DELETE SET NULL,

  -- temporalita'
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ NOT NULL,
  duration_seconds INTEGER NOT NULL
    CHECK (duration_seconds >= 0),
  duration_total_seconds INTEGER NOT NULL
    CHECK (duration_total_seconds >= duration_seconds),

  -- metriche spaziali
  distance_km NUMERIC(10,3) NOT NULL
    CHECK (distance_km >= 0),
  avg_speed_kmh NUMERIC(6,2) NOT NULL
    CHECK (avg_speed_kmh >= 0),
  max_speed_kmh NUMERIC(6,2) NOT NULL
    CHECK (max_speed_kmh >= 0),
  elevation_gain_m NUMERIC(7,1),
  bbox GEOMETRY(Polygon, 4326) NOT NULL,

  -- tracciato
  polyline_encoded TEXT NOT NULL,
  track_points_data JSONB NOT NULL,

  -- metadata
  title TEXT NOT NULL
    CHECK (length(title) BETWEEN 1 AND 100),
  notes TEXT
    CHECK (notes IS NULL OR length(notes) <= 2000),
  tags TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  visibility activity_visibility NOT NULL DEFAULT 'private',
  was_recovered BOOLEAN NOT NULL DEFAULT FALSE,

  -- standard
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 0,

  CHECK (ended_at > started_at)
);

-- Indici per feed e query comuni
CREATE INDEX idx_activities_owner_not_deleted
  ON activities (owner_id, ended_at DESC)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_activities_public_feed
  ON activities (visibility, ended_at DESC)
  WHERE deleted_at IS NULL AND visibility IN ('public', 'followers');

CREATE INDEX idx_activities_bbox
  ON activities USING GIST (bbox)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_activities_tags
  ON activities USING GIN (tags)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_activities_motorcycle
  ON activities (motorcycle_id)
  WHERE motorcycle_id IS NOT NULL AND deleted_at IS NULL;
```

### 3.4 `activity_media`

```sql
CREATE TABLE activity_media (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  activity_id UUID NOT NULL REFERENCES activities(client_id) ON DELETE CASCADE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,

  storage_path_full TEXT NOT NULL,
  storage_path_thumb TEXT NOT NULL,
  caption TEXT CHECK (caption IS NULL OR length(caption) <= 500),
  captured_at TIMESTAMPTZ,
  captured_latitude NUMERIC(9,6),
  captured_longitude NUMERIC(9,6),
  width_px INTEGER NOT NULL CHECK (width_px > 0),
  height_px INTEGER NOT NULL CHECK (height_px > 0),
  size_bytes BIGINT NOT NULL CHECK (size_bytes > 0),
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_activity_media_activity
  ON activity_media (activity_id, order_index);

-- Trigger che enforce I.6: owner_id denormalizzato coerente con activity.owner_id
CREATE OR REPLACE FUNCTION enforce_activity_media_owner_consistency()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  expected_owner UUID;
BEGIN
  SELECT owner_id INTO expected_owner
    FROM activities WHERE client_id = NEW.activity_id;
  IF expected_owner IS NULL THEN
    RAISE EXCEPTION 'Activity % does not exist', NEW.activity_id;
  END IF;
  IF NEW.owner_id <> expected_owner THEN
    RAISE EXCEPTION 'activity_media.owner_id must match activity.owner_id';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_activity_media_owner_consistency
  BEFORE INSERT OR UPDATE OF owner_id, activity_id ON activity_media
  FOR EACH ROW EXECUTE FUNCTION enforce_activity_media_owner_consistency();
```

### 3.5 `planned_routes`

```sql
CREATE TABLE planned_routes (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  motorcycle_id UUID REFERENCES motorcycles(client_id) ON DELETE SET NULL,

  title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 100),
  description TEXT CHECK (description IS NULL OR length(description) <= 2000),
  polyline_encoded TEXT NOT NULL,
  waypoints JSONB NOT NULL,
  distance_km_estimate NUMERIC(10,3) NOT NULL CHECK (distance_km_estimate >= 0),
  duration_seconds_estimate INTEGER NOT NULL CHECK (duration_seconds_estimate >= 0),
  bbox GEOMETRY(Polygon, 4326) NOT NULL,
  tags TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  source planned_route_source NOT NULL,
  visibility activity_visibility NOT NULL DEFAULT 'private',

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 0,

  CHECK (jsonb_array_length(waypoints) >= 2)
);

CREATE INDEX idx_planned_routes_owner
  ON planned_routes (owner_id, created_at DESC)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_planned_routes_bbox
  ON planned_routes USING GIST (bbox)
  WHERE deleted_at IS NULL;
```

### 3.6 `published_routes`

```sql
CREATE TABLE published_routes (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,

  source_type published_route_source_type NOT NULL,
  source_client_id UUID,

  title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 100),
  description TEXT CHECK (description IS NULL OR length(description) <= 2000),
  polyline_encoded TEXT NOT NULL,
  bbox GEOMETRY(Polygon, 4326) NOT NULL,
  distance_km NUMERIC(10,3) NOT NULL,
  duration_seconds INTEGER,
  tags TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  cover_media_id UUID REFERENCES activity_media(client_id) ON DELETE SET NULL,
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  is_published BOOLEAN NOT NULL DEFAULT TRUE,

  -- Counter cache denormalizzati, aggiornati da trigger su route_likes / route_comments.
  -- Motivazione: evitare JOIN o COUNT() nel feed community. Vedi 07_community/L0_architecture.md Sezione 10.
  like_count INTEGER NOT NULL DEFAULT 0 CHECK (like_count >= 0),
  comment_count INTEGER NOT NULL DEFAULT 0 CHECK (comment_count >= 0),

  -- Flag moderazione: contenuto segnalato / sotto revisione. True = nascosto da feed pubblici, visibile solo a owner + admin. Vedi Sezione 4.8.
  is_flagged BOOLEAN NOT NULL DEFAULT FALSE,
  flagged_reason TEXT,
  flagged_at TIMESTAMPTZ,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 0
);

-- Invariante: max una published route attiva per source.
CREATE UNIQUE INDEX idx_published_routes_source_unique
  ON published_routes (source_client_id)
  WHERE deleted_at IS NULL AND source_client_id IS NOT NULL;

CREATE INDEX idx_published_routes_feed
  ON published_routes (published_at DESC)
  WHERE deleted_at IS NULL AND is_published = TRUE;

CREATE INDEX idx_published_routes_owner
  ON published_routes (owner_id, created_at DESC)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_published_routes_bbox
  ON published_routes USING GIST (bbox)
  WHERE deleted_at IS NULL AND is_published = TRUE;

CREATE INDEX idx_published_routes_tags
  ON published_routes USING GIN (tags)
  WHERE deleted_at IS NULL AND is_published = TRUE;
```

**Nota su FK polymorphic:** `source_client_id` non ha REFERENCES perche' punta polimorficamente ad `activities.client_id` o `planned_routes.client_id` a seconda di `source_type`. L'integrita' referenziale viene garantita da trigger applicativo (insert time check) e dalla regola "ON DELETE SET NULL" implementata come trigger (vedi Sezione 4.3).

### 3.7 `route_comments`

```sql
CREATE TABLE route_comments (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  published_route_id UUID NOT NULL REFERENCES published_routes(client_id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  body TEXT NOT NULL CHECK (length(body) BETWEEN 1 AND 1000),
  -- Flag moderazione (vedi Sezione 4.8).
  is_flagged BOOLEAN NOT NULL DEFAULT FALSE,
  flagged_reason TEXT,
  flagged_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_route_comments_route
  ON route_comments (published_route_id, created_at DESC)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_route_comments_author
  ON route_comments (author_id)
  WHERE deleted_at IS NULL;

-- Trigger di soft-delete che sovrascrive body per evitare leak
CREATE OR REPLACE FUNCTION wipe_comment_body_on_soft_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL THEN
    NEW.body := '[commento eliminato]';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_route_comments_wipe_on_delete
  BEFORE UPDATE OF deleted_at ON route_comments
  FOR EACH ROW EXECUTE FUNCTION wipe_comment_body_on_soft_delete();
```

### 3.8 `route_likes`

```sql
CREATE TABLE route_likes (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  published_route_id UUID NOT NULL REFERENCES published_routes(client_id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (published_route_id, author_id)
);

CREATE INDEX idx_route_likes_route
  ON route_likes (published_route_id);

CREATE INDEX idx_route_likes_author
  ON route_likes (author_id);
```

### 3.9 `follow_relationships`

```sql
CREATE TABLE follow_relationships (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  follower_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  followed_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (follower_id, followed_id),
  CHECK (follower_id <> followed_id)
);

CREATE INDEX idx_follow_relationships_follower
  ON follow_relationships (follower_id);

CREATE INDEX idx_follow_relationships_followed
  ON follow_relationships (followed_id);
```

### 3.10 `live_sessions`

```sql
CREATE TABLE live_sessions (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  activity_client_id UUID NOT NULL,
  title TEXT CHECK (title IS NULL OR length(title) <= 100),
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  state live_session_state NOT NULL DEFAULT 'active',
  share_token TEXT NOT NULL UNIQUE,
  invited_profile_ids UUID[] NOT NULL DEFAULT ARRAY[]::UUID[],
  -- Colonne predisposte per watchdog safety (B.7).
  -- Se B.7 decide "si" (MVP o v1.1), queste colonne sono gia' pronte. Se "no", restano NULL/false senza impatto.
  notify_contacts_on_gps_inactivity BOOLEAN NOT NULL DEFAULT FALSE,
  viewer_safety_contact_ids UUID[] NOT NULL DEFAULT ARRAY[]::UUID[],
  end_reason TEXT CHECK (end_reason IS NULL OR end_reason IN ('manual_stop', 'gps_inactivity', 'failsafe_24h')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Solo una live_session attiva per owner (invariante I.3)
CREATE UNIQUE INDEX idx_live_sessions_one_active
  ON live_sessions (owner_id)
  WHERE state = 'active';

CREATE INDEX idx_live_sessions_share_token
  ON live_sessions (share_token) WHERE state = 'active';

CREATE INDEX idx_live_sessions_invited
  ON live_sessions USING GIN (invited_profile_ids)
  WHERE state = 'active';
```

### 3.11 `live_positions`

```sql
CREATE TABLE live_positions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  live_session_id UUID NOT NULL REFERENCES live_sessions(id) ON DELETE CASCADE,
  captured_at TIMESTAMPTZ NOT NULL,
  latitude NUMERIC(9,6) NOT NULL,
  longitude NUMERIC(9,6) NOT NULL,
  speed_kmh NUMERIC(6,2),
  heading_deg NUMERIC(5,2),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '5 minutes')
);

CREATE INDEX idx_live_positions_session
  ON live_positions (live_session_id, captured_at DESC);

CREATE INDEX idx_live_positions_expires
  ON live_positions (expires_at);
```

### 3.12 `safety_contacts`

```sql
CREATE TABLE safety_contacts (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  phone_e164 TEXT
    CHECK (phone_e164 IS NULL OR phone_e164 ~ '^\+[1-9][0-9]{6,14}$'),
  email TEXT
    CHECK (email IS NULL OR email ~* '^[^@]+@[^@]+\.[^@]+$'),
  notify_on_sos BOOLEAN NOT NULL DEFAULT TRUE,
  notify_on_long_ride_silence BOOLEAN NOT NULL DEFAULT FALSE,
  priority INTEGER NOT NULL DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CHECK (phone_e164 IS NOT NULL OR email IS NOT NULL)
);

CREATE INDEX idx_safety_contacts_owner
  ON safety_contacts (owner_id, priority);
```

### 3.13 `safety_events`

```sql
CREATE TABLE safety_events (
  client_id UUID PRIMARY KEY,
  id UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  event_type safety_event_type NOT NULL,
  triggered_at TIMESTAMPTZ NOT NULL,
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  notified_contact_ids UUID[] NOT NULL DEFAULT ARRAY[]::UUID[],
  notification_channels_used TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  resolved_at TIMESTAMPTZ,
  resolution_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_safety_events_owner
  ON safety_events (owner_id, triggered_at DESC);
```

### 3.14 `notifications`

```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type notification_type NOT NULL,
  payload JSONB NOT NULL,
  deep_link TEXT,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_notifications_recipient_unread
  ON notifications (recipient_id, created_at DESC)
  WHERE read_at IS NULL;

CREATE INDEX idx_notifications_recipient_all
  ON notifications (recipient_id, created_at DESC);
```

### 3.15 `error_logs`

```sql
CREATE TABLE error_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  platform platform_type NOT NULL,
  app_version TEXT NOT NULL,
  module TEXT NOT NULL,
  level error_log_level NOT NULL,
  message TEXT NOT NULL,
  stack_trace TEXT,
  context JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_error_logs_created
  ON error_logs (created_at DESC);

CREATE INDEX idx_error_logs_level_created
  ON error_logs (level, created_at DESC)
  WHERE level IN ('error', 'fatal');
```

### 3.16 `reports`

Tabella per le segnalazioni di contenuto / utenti. Alimentata da `07_community/` tramite `CommunityApi.reportContent()`. Processata da admin tool (scope minimale MVP, vedi B.2).

```sql
CREATE TABLE reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  reporter_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,

  -- Polymorphic reference: kind indica tabella target
  entity_kind TEXT NOT NULL
    CHECK (entity_kind IN ('published_route', 'route_comment', 'profile')),
  entity_client_id UUID NOT NULL,   -- client_id o id dell'entita' segnalata

  reason TEXT NOT NULL
    CHECK (reason IN ('spam', 'inappropriate', 'harassment', 'other')),
  notes TEXT CHECK (notes IS NULL OR length(notes) <= 1000),

  -- Workflow admin
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'reviewed', 'dismissed', 'action_taken')),
  action_taken TEXT,   -- libero: 'content_flagged', 'user_suspended', 'user_banned', 'content_deleted', ecc.
  reviewer_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Dedup client-side di report identici dello stesso reporter sulla stessa entity.
CREATE UNIQUE INDEX idx_reports_dedup
  ON reports (reporter_id, entity_kind, entity_client_id)
  WHERE status = 'pending';

CREATE INDEX idx_reports_pending
  ON reports (created_at DESC)
  WHERE status = 'pending';

CREATE INDEX idx_reports_entity
  ON reports (entity_kind, entity_client_id);

CREATE INDEX idx_reports_reviewer
  ON reports (reviewer_id, reviewed_at DESC)
  WHERE reviewer_id IS NOT NULL;
```

**Note di uso:**

- Il client non modifica mai `status` / `reviewer_id` / `reviewed_at`. Solo admin via UI dedicata (B.2).
- La UNIQUE parziale evita spam di report duplicati dello stesso reporter su stessa entity mentre il report e' ancora `pending`. Dopo `reviewed`, un secondo report diventa possibile.
- `entity_client_id` e' polymorphic senza FK. Integrita' garantita a livello applicativo al momento della creazione del report (verifica che l'entita' esista).

---

## Sezione 4 -- Funzioni e trigger trasversali

### 4.1 Trigger generico `updated_at`

```sql
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- Applicato a tutte le tabelle con updated_at.
DO $$
DECLARE
  t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'profiles', 'motorcycles', 'activities', 'activity_media',
    'planned_routes', 'published_routes', 'live_sessions',
    'safety_contacts'
  ] LOOP
    EXECUTE format(
      'CREATE TRIGGER trg_%I_updated_at
         BEFORE UPDATE ON %I
         FOR EACH ROW EXECUTE FUNCTION set_updated_at();',
      t, t);
  END LOOP;
END $$;
```

### 4.2 Trigger `recompute_motorcycle_km`

Invariante I.1 di `01_data_model.md`: `total_km = odometer_start_km + SUM(activities.distance_km non-deleted)`.

```sql
CREATE OR REPLACE FUNCTION recompute_motorcycle_km(p_motorcycle_id UUID)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  v_start NUMERIC(10,2);
  v_sum NUMERIC(10,3);
BEGIN
  IF p_motorcycle_id IS NULL THEN
    RETURN;
  END IF;

  SELECT odometer_start_km INTO v_start
    FROM motorcycles
    WHERE client_id = p_motorcycle_id;

  IF v_start IS NULL THEN
    -- moto non esistente (cancellata hard). niente da fare.
    RETURN;
  END IF;

  SELECT coalesce(sum(distance_km), 0) INTO v_sum
    FROM activities
    WHERE motorcycle_id = p_motorcycle_id
      AND deleted_at IS NULL;

  UPDATE motorcycles
    SET total_km = v_start + v_sum,
        updated_at = now()
    WHERE client_id = p_motorcycle_id;
END;
$$;

-- Trigger che chiama recompute su insert / update / soft delete di activities
CREATE OR REPLACE FUNCTION trg_activities_recompute_km()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM recompute_motorcycle_km(NEW.motorcycle_id);
  ELSIF TG_OP = 'UPDATE' THEN
    -- cambio motorcycle_id: ricompute su entrambe
    IF OLD.motorcycle_id IS DISTINCT FROM NEW.motorcycle_id THEN
      PERFORM recompute_motorcycle_km(OLD.motorcycle_id);
      PERFORM recompute_motorcycle_km(NEW.motorcycle_id);
    -- soft delete / restore: ricompute
    ELSIF OLD.deleted_at IS DISTINCT FROM NEW.deleted_at THEN
      PERFORM recompute_motorcycle_km(NEW.motorcycle_id);
    -- distance cambia (rarissimo, solo post-hoc edit): ricompute
    ELSIF OLD.distance_km IS DISTINCT FROM NEW.distance_km THEN
      PERFORM recompute_motorcycle_km(NEW.motorcycle_id);
    END IF;
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM recompute_motorcycle_km(OLD.motorcycle_id);
  END IF;
  RETURN NULL;
END;
$$;

CREATE TRIGGER trg_activities_km
  AFTER INSERT OR UPDATE OR DELETE ON activities
  FOR EACH ROW EXECUTE FUNCTION trg_activities_recompute_km();
```

### 4.3 Trigger cleanup `published_routes.source_client_id` polymorphic

Quando una Activity o PlannedRoute viene hard-deleted, dobbiamo azzerare `source_client_id` nelle PublishedRoute collegate. Non possiamo usare FK reale perche' source e' polimorfico.

```sql
CREATE OR REPLACE FUNCTION null_published_source_on_parent_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE published_routes
    SET source_client_id = NULL,
        updated_at = now()
    WHERE source_client_id = OLD.client_id;
  RETURN OLD;
END;
$$;

CREATE TRIGGER trg_activities_null_published_source
  AFTER DELETE ON activities
  FOR EACH ROW EXECUTE FUNCTION null_published_source_on_parent_delete();

CREATE TRIGGER trg_planned_routes_null_published_source
  AFTER DELETE ON planned_routes
  FOR EACH ROW EXECUTE FUNCTION null_published_source_on_parent_delete();
```

**Nota:** soft delete di Activity / PlannedRoute NON azzera `source_client_id`. La PublishedRoute continua a referenziare la sorgente; se l'utente ripristina la sorgente, il link e' ancora li'. Solo hard delete rompe il link.

### 4.4 Trigger anonimizzazione su soft-delete profile

Quando un profile viene soft-deleted (utente cancella account), username e display_name sostituiti.

```sql
CREATE OR REPLACE FUNCTION anonymize_profile_on_soft_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL THEN
    NEW.username := 'deleted_user_' || substring(replace(NEW.id::text, '-', '') from 1 for 12);
    NEW.display_name := 'Utente eliminato';
    NEW.bio := NULL;
    NEW.avatar_storage_path := NULL;
    NEW.is_public := FALSE;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_profiles_anonymize_on_delete
  BEFORE UPDATE OF deleted_at ON profiles
  FOR EACH ROW EXECUTE FUNCTION anonymize_profile_on_soft_delete();
```

### 4.5 Funzione helper `is_admin()`

Usata in policy RLS.

```sql
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
      WHERE id = auth.uid()
        AND role = 'admin'
        AND deleted_at IS NULL
  );
$$;
```

### 4.6 Funzione helper `is_following(target_id)`

Per RLS che mostra activity "followers".

```sql
CREATE OR REPLACE FUNCTION is_following(target_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM follow_relationships
      WHERE follower_id = auth.uid()
        AND followed_id = target_id
  );
$$;
```

### 4.7 Trigger counter cache su `published_routes`

Mantiene `like_count` e `comment_count` denormalizzati coerenti con le tabelle `route_likes` e `route_comments`. Evita COUNT() o JOIN nel feed community.

```sql
-- Aggiornamento like_count
CREATE OR REPLACE FUNCTION update_published_route_like_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE published_routes
      SET like_count = like_count + 1,
          updated_at = now()
      WHERE client_id = NEW.published_route_client_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE published_routes
      SET like_count = GREATEST(like_count - 1, 0),
          updated_at = now()
      WHERE client_id = OLD.published_route_client_id;
  END IF;
  RETURN NULL;
END;
$$;

CREATE TRIGGER trg_route_likes_after_ins
  AFTER INSERT ON route_likes
  FOR EACH ROW EXECUTE FUNCTION update_published_route_like_count();

CREATE TRIGGER trg_route_likes_after_del
  AFTER DELETE ON route_likes
  FOR EACH ROW EXECUTE FUNCTION update_published_route_like_count();

-- Aggiornamento comment_count
-- Commenti hanno soft delete: usiamo UPDATE su deleted_at + INSERT / HARD DELETE.
CREATE OR REPLACE FUNCTION update_published_route_comment_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE published_routes
      SET comment_count = comment_count + 1,
          updated_at = now()
      WHERE client_id = NEW.published_route_client_id;
  ELSIF TG_OP = 'UPDATE' THEN
    -- Se il commento e' stato appena soft-deleted: decrementa.
    IF OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL THEN
      UPDATE published_routes
        SET comment_count = GREATEST(comment_count - 1, 0),
            updated_at = now()
        WHERE client_id = NEW.published_route_client_id;
    -- Se stato ripristinato (raro, post-MVP): incrementa.
    ELSIF OLD.deleted_at IS NOT NULL AND NEW.deleted_at IS NULL THEN
      UPDATE published_routes
        SET comment_count = comment_count + 1,
            updated_at = now()
        WHERE client_id = NEW.published_route_client_id;
    END IF;
  ELSIF TG_OP = 'DELETE' THEN
    -- Hard delete (raro): decrementa solo se era attivo.
    IF OLD.deleted_at IS NULL THEN
      UPDATE published_routes
        SET comment_count = GREATEST(comment_count - 1, 0),
            updated_at = now()
        WHERE client_id = OLD.published_route_client_id;
    END IF;
  END IF;
  RETURN NULL;
END;
$$;

CREATE TRIGGER trg_route_comments_after_ins
  AFTER INSERT ON route_comments
  FOR EACH ROW EXECUTE FUNCTION update_published_route_comment_count();

CREATE TRIGGER trg_route_comments_after_upd
  AFTER UPDATE OF deleted_at ON route_comments
  FOR EACH ROW EXECUTE FUNCTION update_published_route_comment_count();

CREATE TRIGGER trg_route_comments_after_del
  AFTER DELETE ON route_comments
  FOR EACH ROW EXECUTE FUNCTION update_published_route_comment_count();
```

**Riferimenti:** `07_community/L0_architecture.md` Sezione 10.

### 4.8 Moderazione base -- schema predisposto

Supporto minimale di moderazione distribuito su 3 elementi:

**1. `profiles.account_status`** (definito in 3.1):

- `active`: stato normale.
- `suspended`: bloccato temporaneamente da admin. Utente puo' leggere ma non pubblicare / commentare / SOS.
- `banned`: bloccato permanente. Come suspended + contenuti automaticamente flagged.
- `deleted_pending_hard`: soft delete con hard delete programmato (gestito post-MVP via batch job admin).

**2. `published_routes.is_flagged` + `route_comments.is_flagged`** (definiti in 3.6 e 3.7):

- `is_flagged = true`: contenuto nascosto dal feed pubblico, visibile solo a owner + admin.
- `flagged_reason`: stringa libera (es. "reported_spam", "auto_flag_banned_user").
- `flagged_at`: timestamp.

**3. Tabella `reports`** (definita in 3.16): traccia le segnalazioni.

**Trigger automatico quando utente viene `banned`:**

```sql
CREATE OR REPLACE FUNCTION auto_flag_banned_user_content()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.account_status = 'banned' AND OLD.account_status != 'banned' THEN
    -- Flag tutti i contenuti pubblici dell'utente.
    UPDATE published_routes
      SET is_flagged = TRUE,
          flagged_reason = 'auto_flag_banned_user',
          flagged_at = now()
      WHERE owner_id = NEW.id AND is_flagged = FALSE;

    UPDATE route_comments
      SET is_flagged = TRUE,
          flagged_reason = 'auto_flag_banned_user',
          flagged_at = now()
      WHERE author_id = NEW.id AND is_flagged = FALSE;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_profiles_auto_flag_on_ban
  AFTER UPDATE OF account_status ON profiles
  FOR EACH ROW EXECUTE FUNCTION auto_flag_banned_user_content();
```

**Uso in RLS:**

Le policies di SELECT su `published_routes` e `route_comments` filtrano `is_flagged = FALSE` per utenti non-admin. Il proprietario puo' sempre vedere i propri contenuti flagged (con banner UI "Questo contenuto e' sotto revisione"). Vedi Sezione 5.

**Cosa NON e' qui in MVP:**

- UI admin per processare reports (scope B.2).
- Audit log delle azioni admin (post-MVP).
- Appeal flow (post-MVP).
- Hard delete batch job di `deleted_pending_hard` (post-MVP).

**Principio di predisposizione:** tutte le colonne e la tabella esistono in v1. Se B.2 resta minimale per 6 mesi, zero impatto. Quando l'admin tool verra' costruito, non servono migration.

---

## Sezione 5 -- Row Level Security (RLS)

Abilitazione RLS su tutte le tabelle. Nessuna eccezione.

```sql
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE motorcycles ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE planned_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE published_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE route_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE route_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE follow_relationships ENABLE ROW LEVEL SECURITY;
ALTER TABLE live_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE live_positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE safety_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE safety_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE error_logs ENABLE ROW LEVEL SECURITY;
```

### 5.1 `profiles`

```sql
-- SELECT: self + profili public (non eliminati)
CREATE POLICY profiles_select ON profiles
  FOR SELECT USING (
    id = auth.uid()
    OR (is_public = TRUE AND deleted_at IS NULL)
    OR is_admin()
  );

-- INSERT: mai dal client. Il trigger handle_new_user fa l'insert via SECURITY DEFINER.
-- Nessuna policy INSERT esplicita -> default deny.

-- UPDATE: solo self (escluso il campo role che e' protetto)
CREATE POLICY profiles_update_self ON profiles
  FOR UPDATE USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Trigger che blocca update di role da parte del client
CREATE OR REPLACE FUNCTION prevent_role_self_update()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.role IS DISTINCT FROM OLD.role AND NOT is_admin() THEN
    RAISE EXCEPTION 'role can only be changed by admins';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_profiles_prevent_role_self_update
  BEFORE UPDATE OF role ON profiles
  FOR EACH ROW EXECUTE FUNCTION prevent_role_self_update();

-- DELETE: mai (solo soft delete via UPDATE deleted_at).
-- Nessuna policy DELETE -> default deny.
```

### 5.2 `motorcycles`

```sql
CREATE POLICY motorcycles_select ON motorcycles
  FOR SELECT USING (owner_id = auth.uid() OR is_admin());

CREATE POLICY motorcycles_insert ON motorcycles
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY motorcycles_update ON motorcycles
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Hard DELETE non prevista dal client (solo soft). Policy DELETE assente.
```

### 5.3 `activities`

```sql
CREATE POLICY activities_select ON activities
  FOR SELECT USING (
    owner_id = auth.uid()
    OR (
      deleted_at IS NULL
      AND (
        visibility = 'public'
        OR (visibility = 'followers' AND is_following(owner_id))
      )
    )
    OR is_admin()
  );

CREATE POLICY activities_insert ON activities
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY activities_update ON activities
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Solo soft delete client-side.
```

### 5.4 `activity_media`

```sql
CREATE POLICY activity_media_select ON activity_media
  FOR SELECT USING (
    owner_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM activities a
        WHERE a.client_id = activity_media.activity_id
          AND a.deleted_at IS NULL
          AND (
            a.visibility = 'public'
            OR (a.visibility = 'followers' AND is_following(a.owner_id))
          )
    )
    OR is_admin()
  );

CREATE POLICY activity_media_insert ON activity_media
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY activity_media_update ON activity_media
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY activity_media_delete ON activity_media
  FOR DELETE USING (owner_id = auth.uid());
```

### 5.5 `planned_routes`

```sql
CREATE POLICY planned_routes_select ON planned_routes
  FOR SELECT USING (owner_id = auth.uid() OR is_admin());

CREATE POLICY planned_routes_insert ON planned_routes
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY planned_routes_update ON planned_routes
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());
```

### 5.6 `published_routes`

```sql
CREATE POLICY published_routes_select ON published_routes
  FOR SELECT USING (
    owner_id = auth.uid()
    OR (deleted_at IS NULL AND is_published = TRUE)
    OR is_admin()
  );

CREATE POLICY published_routes_insert ON published_routes
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY published_routes_update ON published_routes
  FOR UPDATE USING (owner_id = auth.uid() OR is_admin())
  WITH CHECK (
    -- owner puo' editare tutto tranne imporre role=admin etc
    owner_id = auth.uid() OR is_admin()
  );
```

### 5.7 `route_comments`

```sql
CREATE POLICY route_comments_select ON route_comments
  FOR SELECT USING (
    -- vedi il commento se vedi la route
    EXISTS (
      SELECT 1 FROM published_routes pr
      WHERE pr.client_id = route_comments.published_route_id
    )
  );

CREATE POLICY route_comments_insert ON route_comments
  FOR INSERT WITH CHECK (author_id = auth.uid());

CREATE POLICY route_comments_update ON route_comments
  FOR UPDATE USING (author_id = auth.uid())
  WITH CHECK (author_id = auth.uid());

-- Delete: autore OR proprietario della route OR admin
CREATE POLICY route_comments_delete ON route_comments
  FOR DELETE USING (
    author_id = auth.uid()
    OR is_admin()
    OR EXISTS (
      SELECT 1 FROM published_routes pr
      WHERE pr.client_id = route_comments.published_route_id
        AND pr.owner_id = auth.uid()
    )
  );
```

### 5.8 `route_likes`

```sql
CREATE POLICY route_likes_select ON route_likes
  FOR SELECT USING (TRUE);  -- chiunque vede chi ha likato (considerare se restringere)

CREATE POLICY route_likes_insert ON route_likes
  FOR INSERT WITH CHECK (author_id = auth.uid());

CREATE POLICY route_likes_delete ON route_likes
  FOR DELETE USING (author_id = auth.uid());

-- no UPDATE.
```

### 5.9 `follow_relationships`

```sql
CREATE POLICY follow_select ON follow_relationships
  FOR SELECT USING (
    follower_id = auth.uid() OR followed_id = auth.uid() OR is_admin()
  );

CREATE POLICY follow_insert ON follow_relationships
  FOR INSERT WITH CHECK (follower_id = auth.uid());

CREATE POLICY follow_delete ON follow_relationships
  FOR DELETE USING (follower_id = auth.uid());
```

### 5.10 `live_sessions`

```sql
CREATE POLICY live_sessions_select ON live_sessions
  FOR SELECT USING (
    owner_id = auth.uid()
    OR auth.uid() = ANY(invited_profile_ids)
    OR is_admin()
  );

CREATE POLICY live_sessions_insert ON live_sessions
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY live_sessions_update ON live_sessions
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY live_sessions_delete ON live_sessions
  FOR DELETE USING (owner_id = auth.uid());
```

### 5.11 `live_positions`

```sql
-- SELECT: partecipanti della live session
CREATE POLICY live_positions_select ON live_positions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM live_sessions ls
      WHERE ls.id = live_positions.live_session_id
        AND (
          ls.owner_id = auth.uid()
          OR auth.uid() = ANY(ls.invited_profile_ids)
        )
    )
  );

-- INSERT: solo via Edge Function (client non puo' inserire direttamente)
-- Nessuna policy INSERT per authenticated. Policy per service_role separata.
```

### 5.12 `safety_contacts`

```sql
CREATE POLICY safety_contacts_select ON safety_contacts
  FOR SELECT USING (owner_id = auth.uid());

CREATE POLICY safety_contacts_insert ON safety_contacts
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY safety_contacts_update ON safety_contacts
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY safety_contacts_delete ON safety_contacts
  FOR DELETE USING (owner_id = auth.uid());
```

### 5.13 `safety_events`

```sql
CREATE POLICY safety_events_select ON safety_events
  FOR SELECT USING (
    owner_id = auth.uid()
    -- in futuro: contacts che hanno ricevuto notifica
    OR is_admin()
  );

CREATE POLICY safety_events_insert ON safety_events
  FOR INSERT WITH CHECK (owner_id = auth.uid());

CREATE POLICY safety_events_update ON safety_events
  FOR UPDATE USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());
```

### 5.14 `notifications`

```sql
CREATE POLICY notifications_select ON notifications
  FOR SELECT USING (recipient_id = auth.uid());

-- INSERT: solo service_role (Edge Function). Nessuna policy authenticated.

CREATE POLICY notifications_update_read ON notifications
  FOR UPDATE USING (recipient_id = auth.uid())
  WITH CHECK (recipient_id = auth.uid());

-- Trigger che blocca update di altri campi oltre a read_at
CREATE OR REPLACE FUNCTION prevent_notification_field_change()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.type IS DISTINCT FROM OLD.type
     OR NEW.payload IS DISTINCT FROM OLD.payload
     OR NEW.deep_link IS DISTINCT FROM OLD.deep_link
     OR NEW.recipient_id IS DISTINCT FROM OLD.recipient_id
     OR NEW.created_at IS DISTINCT FROM OLD.created_at
  THEN
    RAISE EXCEPTION 'notifications: only read_at can be modified client-side';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_notifications_guard_update
  BEFORE UPDATE ON notifications
  FOR EACH ROW EXECUTE FUNCTION prevent_notification_field_change();

CREATE POLICY notifications_delete ON notifications
  FOR DELETE USING (recipient_id = auth.uid());
```

### 5.15 `error_logs`

```sql
-- INSERT: authenticated (tutti possono segnalare errori per se stessi)
CREATE POLICY error_logs_insert ON error_logs
  FOR INSERT WITH CHECK (
    user_id = auth.uid() OR user_id IS NULL
  );

-- SELECT: solo admin
CREATE POLICY error_logs_select ON error_logs
  FOR SELECT USING (is_admin());

-- UPDATE e DELETE client: nessuna policy -> default deny.
-- DELETE via pg_cron (service_role).
```

---

## Sezione 6 -- Storage buckets e policies

### 6.1 Buckets

Configurati via Supabase Dashboard o CLI. Elenco:

- **`avatars`** -- immagini profilo. Path: `{user_id}/avatar.{ext}`. File singolo per utente (sovrascrive).
- **`motorcycle_photos`** -- foto moto. Path: `{user_id}/motorcycles/{motorcycle_client_id}.{ext}`.
- **`activity_media`** -- foto activity. Path: `{user_id}/media/{activity_client_id}/{media_client_id}_{variant}.jpg`. Due file per media (`thumb` + `full`).

Tutti i bucket **privati**. Accesso tramite signed URL (15 minuti di validita') generato da Edge Function o da client autenticato con check RLS.

### 6.2 Policy Storage SQL

```sql
-- Avatars: proprietario scrive/cancella, authenticated leggono (sono pubblici in UI)
CREATE POLICY avatars_select ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

CREATE POLICY avatars_insert ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY avatars_update ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY avatars_delete ON storage.objects
  FOR DELETE USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- Motorcycle photos: proprietario accesso completo
CREATE POLICY motorcycle_photos_all ON storage.objects
  FOR ALL USING (
    bucket_id = 'motorcycle_photos'
    AND (storage.foldername(name))[1] = auth.uid()::text
  ) WITH CHECK (
    bucket_id = 'motorcycle_photos'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- Activity media: lettura segue visibilita' activity, scrittura solo owner
CREATE POLICY activity_media_select ON storage.objects
  FOR SELECT USING (
    bucket_id = 'activity_media'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR EXISTS (
        SELECT 1 FROM activities a
        WHERE a.client_id::text = (storage.foldername(name))[3]
          AND a.deleted_at IS NULL
          AND (
            a.visibility = 'public'
            OR (a.visibility = 'followers' AND is_following(a.owner_id))
          )
      )
    )
  );

CREATE POLICY activity_media_write ON storage.objects
  FOR ALL USING (
    bucket_id = 'activity_media'
    AND (storage.foldername(name))[1] = auth.uid()::text
  ) WITH CHECK (
    bucket_id = 'activity_media'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
```

---

## Sezione 7 -- pg_cron jobs

```sql
-- Cleanup live_positions scadute (ogni 5 minuti)
SELECT cron.schedule(
  'cleanup-live-positions',
  '*/5 * * * *',
  $$ DELETE FROM live_positions WHERE expires_at < now(); $$
);

-- Cleanup notifications lette e vecchie (ogni giorno alle 4 AM UTC)
SELECT cron.schedule(
  'cleanup-read-notifications',
  '0 4 * * *',
  $$ DELETE FROM notifications
     WHERE read_at IS NOT NULL
       AND created_at < now() - INTERVAL '30 days'; $$
);

-- Cleanup error_logs vecchi (ogni giorno alle 4:15 AM UTC)
SELECT cron.schedule(
  'cleanup-error-logs',
  '15 4 * * *',
  $$ DELETE FROM error_logs
     WHERE created_at < now() - INTERVAL '90 days'; $$
);

-- Auto-close LiveSession per timeout GPS leader (ogni 10 minuti)
SELECT cron.schedule(
  'auto-close-stale-live-sessions',
  '*/10 * * * *',
  $$ UPDATE live_sessions
     SET state = 'ended_timeout',
         ended_at = now()
     WHERE state = 'active'
       AND NOT EXISTS (
         SELECT 1 FROM live_positions lp
         WHERE lp.live_session_id = live_sessions.id
           AND lp.captured_at > now() - INTERVAL '10 minutes'
       ); $$
);

-- Auto-close LiveSession oltre 24h (failsafe)
SELECT cron.schedule(
  'auto-close-old-live-sessions',
  '0 */2 * * *',
  $$ UPDATE live_sessions
     SET state = 'ended_timeout',
         ended_at = now()
     WHERE state = 'active'
       AND started_at < now() - INTERVAL '24 hours'; $$
);
```

---

## Sezione 8 -- Realtime subscriptions

Supabase Realtime usato solo per `live_positions` (overview Sezione 5.3).

```sql
-- Abilita replica per live_positions
ALTER PUBLICATION supabase_realtime ADD TABLE live_positions;
```

**Config lato client:** il modulo live (nel submodulo safety) sottoscrive:
```
supabase
  .channel('live_session_' || session.id)
  .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'live_positions',
        filter: 'live_session_id=eq.' || session.id },
      handler)
  .subscribe();
```

Le altre tabelle NON sono in realtime publication. Notifiche su like/comment/follow arrivano via FCM + Edge Function trigger su insert.

---

## Sezione 9 -- Edge Functions necessarie (elenco)

Elenco delle Edge Functions che il backend deve esporre. Dettagli implementativi in futuri documenti di ciascun modulo.

| Nome | Scopo | Chiamata da |
|---|---|---|
| `create-notification` | Inserisce riga in `notifications` per utente target. Bypass RLS. | Trigger DB (su nuovo like / comment / follow / safety event). |
| `push-live-position` | Inserisce riga in `live_positions` (bypass RLS insert). | Client durante LiveSession attiva. |
| `send-safety-notifications` | Triggera Twilio/SendGrid sui SafetyContact. | Trigger DB su insert `safety_events`. |
| `sign-storage-url` | Genera signed URL per bucket privato. | Client quando serve mostrare foto. |

Non implementiamo ancora. Dichiarate qui per tracciabilita'.

---

## Sezione 10 -- Ordine delle migration files

Prima migration (`00001_initial.sql`) contiene:
1. Sezione 1 (extensions).
2. Sezione 2 (enum types).
3. Sezione 3 (tables in ordine di dipendenza FK: profiles, motorcycles, activities, activity_media, planned_routes, published_routes, route_comments, route_likes, follow_relationships, live_sessions, live_positions, safety_contacts, safety_events, notifications, error_logs).

Seconda migration (`00002_triggers_and_functions.sql`):
4. Sezione 4 (trigger e funzioni).

Terza migration (`00003_rls.sql`):
5. Sezione 5 (RLS enable + policies).

Quarta migration (`00004_storage.sql`):
6. Sezione 6 (buckets via codice o manuale + policies).

Quinta migration (`00005_cron_jobs.sql`):
7. Sezione 7 (pg_cron jobs).

Sesta migration (`00006_realtime.sql`):
8. Sezione 8 (realtime publication).

Motivazione split: ogni migration e' atomica per "tema". Se una parte fallisce (es. cron job su env dove pg_cron non e' installato), le altre migration precedenti restano applicate.

---

## Sezione 11 -- Convenzioni da rispettare in future migration

Per non rompere coerenza quando si aggiungono tabelle:

1. **Ogni nuova tabella** deve avere policy RLS esplicite. Senza policy, tutte le operazioni sono deny (default Postgres con RLS on). Se vuoi una tabella "libera", documentalo con commento SQL.
2. **Soft delete vs hard delete**: decisione documentata in `01_data_model.md` Sezione 20. Una nuova tabella che non e' in quella lista deve aggiungersi.
3. **`client_id` obbligatorio** su entita' user-generated. Non ci sono eccezioni silenti.
4. **Nomi campi coerenti**: `created_at`, `updated_at`, `deleted_at`, `owner_id`, `client_id`, `id`. Sinonimi (`author_id`, `user_id`, `recipient_id`) ammessi solo quando denotano ruoli diversi.
5. **Trigger `set_updated_at`** sulle tabelle con `updated_at`.
6. **Indici su FK** -- Postgres non crea indici automatici sulle FK. Aggiungerli manualmente dove query frequenti li richiedono.

---

## Sezione 12 -- Open items

Da aggiungere a `99_open_questions.md`:

- **A.11** -- Policy `route_likes_select` attualmente consente a chiunque autenticato di vedere la lista dei likers. E' la scelta giusta o vogliamo restringere solo al route owner e all'autore del like? Standard social diversi.
- **A.12** -- Live session timeout da inattivita': proposta 10 minuti (Sezione 7 cron). Confermare con Lollo.
- **A.13** -- Policy `safety_events_select`: in futuro i contact notificati dovrebbero poter vedere gli eventi che hanno ricevuto? Oggi nessuna policy per loro. Da progettare quando useremo SafetyContact come profili "lite" (post-MVP).
- **A.14** -- Username modificabile: check policy "entro 7 giorni". Oggi CHECK constraint non impone il limite temporale. Implementarlo come trigger oppure lasciare come "policy di prodotto solo UI"? Se UI e' l'unica barriera, utente tecnico puo' aggirare. Decidere se accettabile.

---

**Fine 02_database_schema.md**
