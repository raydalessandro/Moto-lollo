# 01 -- Data Model

**Scopo:** definizione logica delle entita' del dominio. Campi, tipi, invarianti, relazioni.

**Cosa NON e' questo documento:**

- Non e' lo schema SQL (vive in `02_database_schema.md`).
- Non e' lo schema drift locale (vive in `03_local_db.md`).
- Non e' interfaccia pubblica di moduli (vive negli `L05_interfaces.md` di ciascun modulo).

**Cosa E' questo documento:**

- Definizione delle entita' come concetti di dominio.
- Campi logici che ogni entita' deve esporre, con tipi astratti (String, UUID, Timestamp, DateTime, Enum, etc.) e vincoli.
- Invarianti strutturali (regole che devono sempre valere, indipendenti dallo storage).
- Relazioni tra entita'.

Le implementazioni specifiche (Postgres column types, drift Column definitions, tipi Dart) derivano da qui ma vivono nei documenti successivi.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 0 -- Convenzioni trasversali

Queste convenzioni si applicano a TUTTE le entita' user-generated. Non vengono ripetute in ogni sezione per evitare rumore.

### 0.1 Identificatori

Ogni entita' user-generated espone DUE identificatori:

- **`client_id: UUID v4`** -- generato client-side nel costruttore del modello Dart, prima di qualsiasi persistenza. E' la chiave di business. E' usato in tutte le comunicazioni client-server. E' UNIQUE.
- **`id: UUID`** -- generato server-side (`gen_random_uuid()` in Postgres) al primo insert. E' la chiave interna del server, usata per FK tra tabelle lato Postgres. Lato client puo' essere `null` fino a primo sync completato.

Motivazione: vedi overview Sezione 5.12.

**Eccezioni (entita' che hanno solo `id`, no `client_id`):**

- `Profile` -- identita' e' gestita da Supabase Auth, `id` = `auth.users.id`.
- `Notification` -- generata server-side tramite Edge Function, mai dal client.
- `LivePosition` -- ephemeral, generata dal client ma non ha valore persistente oltre la sessione live.
- `ErrorLog` -- puramente tecnico, nessuna logica di idempotency client-lato necessaria.

### 0.2 Timestamp standard

Ogni entita' persistente espone:

- **`created_at: Timestamp`** -- quando la riga e' stata creata. Generato client-side per entita' con `client_id` (cosi' riflette il momento reale dell'azione utente, non il momento di arrivo server). Server-side per eccezioni.
- **`updated_at: Timestamp`** -- ultima modifica. Aggiornato automaticamente (trigger Postgres, gestione esplicita in drift).

### 0.3 Soft delete

Entita' con valore storico espongono:

- **`deleted_at: Timestamp NULL`** -- se valorizzato, la riga e' cancellata logicamente ma presente in DB.

Entita' soft-delete: `Profile`, `Motorcycle`, `Activity`, `PlannedRoute`, `PublishedRoute`.
Entita' hard-delete (niente `deleted_at`): tutte le altre. Vedi overview Sezione 6 per dettaglio.

### 0.4 Proprieta' (ownership)

Entita' legate a un utente espongono:

- **`owner_id: UUID`** -- FK a `profiles.id`. Chi ha creato la riga.

Al momento dell'eliminazione account (soft delete del profile), `owner_id` rimane valorizzato (verso il profile anonimizzato). Regola coerente con Strategia A, overview Sezione 5.5.

### 0.5 Versionamento leggero

Entita' che possono essere modificate post-creazione e sincronizzate bidirezionalmente espongono:

- **`version: Integer`** -- contatore incrementato ad ogni update lato client. Usato per conflict detection in futuro (post-MVP multi-device). Per MVP single-device il valore esiste ma non e' usato per logica.

Entita' con `version`: `Activity`, `Motorcycle`, `PlannedRoute`, `PublishedRoute`, `Profile`.
Entita' senza `version`: append-only (non si modificano dopo creazione) -- `RouteComment`, `RouteLike`, `SafetyEvent`, `Notification`.

---

## Sezione 1 -- Profile

**Scopo:** rappresenta l'utente. E' il centro di gravita' del modello -- praticamente ogni altra entita' riferisce a un Profile come owner.

**Invariante fondamentale:** esiste un Profile per ogni `auth.users` di Supabase. Creato automaticamente via trigger Postgres su insert in `auth.users`.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `id` | UUID | no | = `auth.users.id`. PK. |
| `username` | String (3-30 char) | no | UNIQUE, lowercase, alfanumerico + underscore. Case-insensitive per ricerche. |
| `display_name` | String (1-50 char) | no | Nome visibile, modificabile liberamente. |
| `bio` | String (max 500 char) | si | Bio testuale. |
| `avatar_storage_path` | String | si | Path relativo in Supabase Storage. Null = avatar di default. |
| `role` | Enum `user \| admin` | no | Default `user`. Cambio manuale server-side. |
| `account_status` | Enum `active \| suspended \| banned \| deleted_pending_hard` | no | Default `active`. Gestito da admin (vedi `02_database_schema.md` Sezione 4.8). |
| `is_public` | Boolean | no | Default `true`. Se `false`, profilo non cercabile e activity non visibili a non-follower. |
| `feature_flags` | JSON object | no | Default `{}`. Vedi overview Sezione 5.9. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |
| `deleted_at` | Timestamp | si | Soft delete: profilo anonimizzato. |
| `version` | Integer | no | Default 0. |

### Invarianti

1. `username` UNIQUE, immutabile dopo la prima settimana di vita account (policy prodotto per evitare impersonation). Nel MVP questa regola e' applicata lato UI, non in DB.
2. Se `deleted_at IS NOT NULL`: `username` e `display_name` vengono sovrascritti con valori anonimizzati sistemici (`deleted_user_<random_suffix>`). Evita leak di identita' residua.
3. `role = admin` non e' impostabile dal client -- solo via modifica diretta DB da amministratore tecnico.

### Relazioni

- 1 -> N con: `Motorcycle`, `Activity`, `PlannedRoute`, `PublishedRoute`, `SafetyContact`, `Notification`.
- M -> N con: `Profile` tramite `FollowRelationship` (self-referencing).

---

## Sezione 2 -- Motorcycle

**Scopo:** moto registrata nel garage dell'utente. Puo' essere associata a una Activity o a una PlannedRoute.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | Business key. |
| `id` | UUID | si | Server-side id. |
| `owner_id` | UUID | no | FK `profiles.id`. |
| `name` | String (1-50 char) | no | Nome dato dall'utente (es. "La rossa"). |
| `brand` | String (1-50 char) | no | Casa costruttrice (es. "Ducati"). |
| `model` | String (1-100 char) | no | Modello (es. "Panigale V4"). |
| `year` | Integer | si | Anno immatricolazione. |
| `engine_cc` | Integer | si | Cilindrata. |
| `color` | String | si | Colore principale. Puo' essere hex o nome. |
| `photo_storage_path` | String | si | Path relativo in Storage. |
| `odometer_start_km` | Decimal | no | Default 0. Km della moto al momento della registrazione nell'app (es. moto usata comprata con 15000 km). |
| `total_km` | Decimal | no | Default `odometer_start_km`. Calcolato da trigger `recompute_motorcycle_km()`. Vedi overview D.17. |
| `is_primary` | Boolean | no | Default `false`. Moto predefinita per nuove activity. Esattamente una moto per utente puo' avere `is_primary=true`. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |
| `deleted_at` | Timestamp | si | |
| `version` | Integer | no | |

### Invarianti

1. `total_km = odometer_start_km + SUM(activities.distance_km WHERE motorcycle_id = this.id AND deleted_at IS NULL)`. Mantenuta dal trigger, non modificabile direttamente dal client.
2. Al massimo una Motorcycle per utente puo' avere `is_primary = true`. Constraint UNIQUE parziale: `UNIQUE (owner_id) WHERE is_primary = true AND deleted_at IS NULL`.
3. Soft delete di una Motorcycle NON cancella le Activity associate. L'Activity mantiene il `motorcycle_id` storico.
4. Se l'utente cancella una moto e poi la "ripristina" (future feature, non MVP), i km storici sono recuperabili perche' le activity non sono state toccate.

### Relazioni

- N -> 1 con `Profile` (owner).
- 1 -> N con `Activity`, `PlannedRoute`.

---

## Sezione 3 -- RecordingSession

**Scopo:** sessione di registrazione GPS attualmente attiva o recentemente chiusa. E' la "Activity in corso di formazione". Esiste solo come tabella drift locale (MAI sincronizzata con Supabase) -- e' stato volatile del client.

**Motivazione separazione:** una Activity completa e' un'entita' immutabile (post-stop). La RecordingSession e' un'entita' in evoluzione. Mescolarle in una sola tabella richiederebbe migrazioni di stato confuse. Vedi overview Sezione 5.11.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | PK. Sara' il `client_id` della Activity finale quando la sessione si chiude. |
| `owner_id` | UUID | no | FK `profiles.id`. |
| `motorcycle_id` | UUID | si | FK a `motorcycles.client_id`. Null se utente non ha selezionato moto. |
| `state` | Enum | no | `active \| closed_unsynced \| closed_synced`. Default `active` alla creazione. |
| `started_at` | Timestamp | no | |
| `ended_at` | Timestamp | si | Valorizzato quando state passa a `closed_unsynced`. |
| `title_draft` | String | si | Titolo proposto dall'utente durante la registrazione o a chiusura. |
| `notes_draft` | String | si | |
| `was_recovered` | Boolean | no | Default `false`. Passa a `true` se la sessione viene chiusa via dialog di recovery post-crash. |
| `created_at` | Timestamp | no | = `started_at`. |
| `updated_at` | Timestamp | no | |

### Invarianti

1. **Solo UNA RecordingSession alla volta puo' avere `state = active` per owner_id.** Vincolo UNIQUE parziale: `UNIQUE (owner_id) WHERE state = 'active'`. Attivare due registrazioni in parallelo e' proibito.
2. Transizioni di stato permesse: `active -> closed_unsynced -> closed_synced`. Nessun'altra transizione ammessa. Non si torna mai da `closed_*` a `active`.
3. Quando `state = closed_synced`, la RecordingSession puo' essere cancellata localmente (purge). Viene conservata per qualche ora per consentire eventuale debug, poi pulita da una routine interna.
4. `ended_at >= started_at` sempre.
5. Non sincronizzata con Supabase. Esiste solo in drift.

### Relazioni

- N -> 1 con `Profile`.
- N -> 1 con `Motorcycle`.
- 1 -> N con `TrackPointBuffer` (punti GPS raccolti).
- 1 -> 1 (futuro) con `Activity` creata alla chiusura. La Activity nasce con lo stesso `client_id` della RecordingSession.

---

## Sezione 4 -- TrackPointBuffer

**Scopo:** punti GPS registrati durante una RecordingSession attiva. Tabella drift locale. Mai sincronizzata direttamente con Supabase -- viene impacchettata in `activities.track_points_data` al momento della chiusura.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `id` | Integer | no | PK auto-increment locale. Puramente tecnico. |
| `recording_session_id` | UUID | no | FK a `recording_session.client_id`. |
| `seq` | Integer | no | Progressivo dentro la session. Usato per ordinamento robusto. |
| `captured_at` | Timestamp | no | Timestamp di ricezione dal sensore GPS. |
| `latitude` | Decimal | no | WGS84. |
| `longitude` | Decimal | no | WGS84. |
| `altitude_m` | Decimal | si | Sopra livello del mare. |
| `speed_ms` | Decimal | si | Metri al secondo (come riporta `geolocator`). Conversione a km/h fatta in UI. |
| `heading_deg` | Decimal | si | Direzione in gradi (0-360). |
| `accuracy_m` | Decimal | si | Errore orizzontale stimato dal sensore. |
| `point_state` | Enum | no | `normal \| tunnel_entry \| tunnel_exit \| paused_marker \| recovered_marker`. Default `normal`. |

### Invarianti

1. `seq` e' strettamente crescente dentro una `recording_session_id`. Nessun riuso.
2. Relazione con `recording_session`: cascade hard delete. Se la session e' scartata via dialog di recovery, i suoi punti spariscono con lei.
3. Quando la RecordingSession passa a `closed_unsynced`: i punti del buffer vengono letti in ordine di `seq`, convertiti in polyline_encoded + array jsonb + calcolo bbox + calcolo metriche (distance_km, duration, max_speed), e il risultato e' persistito in `activities`. Il buffer viene mantenuto fino a `closed_synced` (serve come backup se la conversione andasse male).
4. Dopo `closed_synced`: buffer puo' essere cancellato (routine di purge).

### Note sugli enum `point_state`

- **normal**: punto regolare.
- **tunnel_entry**: ultimo punto prima della perdita segnale attribuita a galleria (heuristica: perdita fix GPS combinata con velocita' stabile pre-perdita).
- **tunnel_exit**: primo punto dopo riacquisizione segnale post-galleria.
- **paused_marker**: punto virtuale che segna pausa dichiarata dall'utente (tap "pause"). Non riflette posizione reale, ha lat/lon uguali all'ultimo punto `normal`.
- **recovered_marker**: punto virtuale che segna la ripresa da pausa.

Logica di detection di tunnel_entry/tunnel_exit vive in `04_tracking/gps_filters.md`. Qui interessa solo che lo stato esiste e viene persistito.

### Relazioni

- N -> 1 con `RecordingSession`.
- Non ha relazione diretta con altre entita' -- al termine della session i dati confluiscono in Activity.

---

## Sezione 5 -- Activity

**Scopo:** uscita completata. Immutabile nei tratti essenziali (tracciato), modificabile in metadata (titolo, descrizione, moto associata, tag).

**Transizione da RecordingSession:** quando una RecordingSession passa da `active` a `closed_unsynced`, nasce una Activity con lo stesso `client_id`.

### Campi

#### Identita' e ownership
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | = `recording_session.client_id` originaria. |
| `id` | UUID | si | Server-side. |
| `owner_id` | UUID | no | FK `profiles.id`. |
| `motorcycle_id` | UUID | si | FK `motorcycles.client_id`. Null se utente rimuove associazione. |

#### Temporalita'
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `started_at` | Timestamp | no | |
| `ended_at` | Timestamp | no | |
| `duration_seconds` | Integer | no | Durata effettiva (al netto pause). Derivata ma persistita per query veloci. |
| `duration_total_seconds` | Integer | no | Durata totale inclusa pause. |

#### Metriche spaziali
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `distance_km` | Decimal | no | Chilometri percorsi. Calcolata dalla somma dei segmenti tra punti `normal` consecutivi (no pause). |
| `avg_speed_kmh` | Decimal | no | `distance_km / duration_seconds * 3600`. |
| `max_speed_kmh` | Decimal | no | Massima velocita' puntuale registrata. |
| `elevation_gain_m` | Decimal | si | Dislivello positivo. Null se sensore altimetrico non affidabile. |
| `bbox` | Geometry (PostGIS polygon) | no | Bounding box del tracciato. In drift salvata come 4 decimali (`bbox_min_lat`, `bbox_min_lon`, `bbox_max_lat`, `bbox_max_lon`). |

#### Tracciato
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `polyline_encoded` | String (text) | no | Polyline Google encoded, dai punti `normal`. Usato per rendering mappa feed. |
| `track_points_data` | JSON (array) | no | Array completo `[{t, lat, lon, speed, ele, point_state, acc}, ...]`. Vedi overview Sezione 5.1. Gzippato prima di upload. |

#### Metadata utente
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `title` | String (1-100 char) | no | Default "Uscita del <data>" se utente non specifica. |
| `notes` | String (max 2000 char) | si | |
| `tags` | Array of String | no | Default `[]`. Ciascun tag 1-30 char, lowercase, alfanumerico + dash. |
| `visibility` | Enum `private \| followers \| public` | no | Default `private`. Determina RLS read. |
| `was_recovered` | Boolean | no | Default `false`. True se nata da dialog di recovery post-crash. |

#### Sync state (solo drift locale, non server)
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `sync_state` | Enum `pending \| syncing \| synced \| failed` | no | Solo client-side. |
| `sync_retry_count` | Integer | no | Default 0. |
| `sync_last_error` | String | si | Ultimo errore di sync se `failed`. |

#### Timestamp standard
| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |
| `deleted_at` | Timestamp | si | |
| `version` | Integer | no | |

### Invarianti

1. `ended_at > started_at`.
2. `duration_seconds <= duration_total_seconds` (la seconda include pause).
3. `distance_km >= 0`.
4. `track_points_data` e `polyline_encoded` sono derivabili uno dall'altro se si filtrano solo i `normal`. Entrambi persistiti per evitare ricalcolo a ogni read.
5. Modifica post-facto da parte dell'utente: permessa su `title`, `notes`, `tags`, `visibility`, `motorcycle_id`. NON permessa su `started_at`, `ended_at`, metriche, tracciato. Questi ultimi sono immutabili.
6. Se `visibility = private`: l'Activity NON puo' essere sorgente di una PublishedRoute.
7. Cambio `motorcycle_id` triggera `recompute_motorcycle_km` sulle due moto coinvolte (vecchia e nuova). Vedi overview D.17.

### Relazioni

- N -> 1 con `Profile` (owner).
- N -> 1 con `Motorcycle`.
- 1 -> N con `ActivityMedia`.
- 1 -> 0..1 con `PublishedRoute` (una Activity puo' generare al piu' una PublishedRoute attiva).
- 1 -> 0..1 con `LiveSession` (una Activity puo' avere associata una live session durante la registrazione).

---

## Sezione 6 -- ActivityMedia

**Scopo:** foto (ed eventualmente in futuro video) associate a una Activity. Vedi overview Sezione 5.7.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `activity_id` | UUID | no | FK `activities.client_id`. |
| `owner_id` | UUID | no | = `activity.owner_id`, denormalizzato per RLS. |
| `storage_path_full` | String | no | Path full-size in Storage. |
| `storage_path_thumb` | String | no | Path thumbnail. |
| `caption` | String (max 500 char) | si | |
| `captured_at` | Timestamp | si | Da EXIF se disponibile; altrimenti null. |
| `captured_latitude` | Decimal | si | Da EXIF. |
| `captured_longitude` | Decimal | si | Da EXIF. |
| `width_px` | Integer | no | Del file full. |
| `height_px` | Integer | no | |
| `size_bytes` | Integer | no | Del file full. |
| `order_index` | Integer | no | Default 0. Ordine visualizzazione. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |

### Invarianti

1. Massimo 20 media per Activity (soft limit client-lato, overview Sezione 5.7). Check lato app prima di insert.
2. Hard delete su delete dell'Activity parent (cascade).
3. `owner_id` denormalizzato per performance RLS -- non puo' divergere da `activity.owner_id`. Gestito da trigger che rifiuta update se inconsistente.
4. Se caricata foto con EXIF geotag, `captured_latitude`/`longitude` vengono salvate ma NON sono esposte a utenti esterni nella visualizzazione (solo al proprietario) per privacy.

### Relazioni

- N -> 1 con `Activity`.
- N -> 1 con `Profile` (owner).

---

## Sezione 7 -- PlannedRoute

**Scopo:** percorso pianificato prima di partire. Non ha tracciato GPS reale; e' un itinerario disegnato dall'utente (o importato da GPX) prima di guidarlo. Vedi overview Sezione 3.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `owner_id` | UUID | no | |
| `motorcycle_id` | UUID | si | Moto scelta per il percorso (opzionale). |
| `title` | String (1-100 char) | no | |
| `description` | String (max 2000 char) | si | |
| `polyline_encoded` | String | no | Polyline del percorso progettato. |
| `waypoints` | JSON array | no | Array di `{lat, lon, name, order}` con i punti chiave definiti dall'utente. |
| `distance_km_estimate` | Decimal | no | Stima da routing API Mapbox. |
| `duration_seconds_estimate` | Integer | no | Stima durata. |
| `bbox` | Geometry / 4 decimali | no | Come Activity. |
| `tags` | Array of String | no | |
| `source` | Enum `drawn \| imported_gpx \| generated` | no | Origine del percorso. |
| `visibility` | Enum `private \| followers \| public` | no | Default `private`. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |
| `deleted_at` | Timestamp | si | |
| `version` | Integer | no | |

### Invarianti

1. `waypoints` ha almeno 2 elementi (start + end).
2. `polyline_encoded` coerente con `waypoints` (la polyline passa per tutti i waypoint in ordine). Non enforced a livello DB; validato lato app a tempo di creazione/update.
3. Al piu' 50 waypoint per route. Soft limit.
4. Se `visibility = private`, non puo' essere base di una PublishedRoute.

### Relazioni

- N -> 1 con `Profile` (owner), `Motorcycle`.
- 1 -> 0..1 con `PublishedRoute` (puo' essere fonte di pubblicazione).

---

## Sezione 8 -- PublishedRoute

**Scopo:** snapshot di un percorso condiviso con la community. Vedi overview Sezione 3 e open question A.2.

**Natura snapshot:** al momento della pubblicazione, i dati di tracciato e metadata vengono COPIATI da Activity o PlannedRoute sorgente. La PublishedRoute vive di vita propria dopo.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `owner_id` | UUID | no | |
| `source_type` | Enum `activity \| planned_route` | no | Da cosa e' stata pubblicata. |
| `source_client_id` | UUID | si | `client_id` della Activity o PlannedRoute sorgente. FK con `ON DELETE SET NULL`. Se la sorgente viene cancellata la PublishedRoute sopravvive. |
| `title` | String (1-100 char) | no | Copiato dalla sorgente, poi modificabile indipendentemente. |
| `description` | String (max 2000 char) | si | |
| `polyline_encoded` | String | no | Snapshot. |
| `bbox` | Geometry / 4 decimali | no | |
| `distance_km` | Decimal | no | |
| `duration_seconds` | Integer | si | Null se fonte e' PlannedRoute (non ha durata reale). |
| `tags` | Array of String | no | |
| `cover_media_id` | UUID | si | FK opzionale a una `activity_media.client_id` da usare come copertina. |
| `published_at` | Timestamp | no | Data di prima pubblicazione. |
| `is_published` | Boolean | no | Default `true`. Se `false`, la route e' stata "nascosta" ma non cancellata (es. auto-unpublish per utente bannato). |
| `like_count` | Integer | no | Counter cache, aggiornato da trigger. |
| `comment_count` | Integer | no | Counter cache, aggiornato da trigger. |
| `is_flagged` | Boolean | no | Default `false`. Contenuto segnalato / sotto revisione. Vedi moderazione in `02_database_schema.md` Sezione 4.8. |
| `flagged_reason` | String | si | Motivo del flag (es. `reported_spam`, `auto_flag_banned_user`). |
| `flagged_at` | Timestamp | si | Quando e' stato flagged. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |
| `deleted_at` | Timestamp | si | |
| `version` | Integer | no | |

### Invarianti

1. Quando creata, copia integrale dei campi spaziali e tipo da sorgente. Cambiamenti successivi alla sorgente NON si propagano.
2. Al massimo UNA PublishedRoute attiva per `source_client_id`. Se l'utente ri-pubblica, la vecchia viene soft-deleted e se ne crea una nuova. Vincolo: `UNIQUE (source_client_id) WHERE deleted_at IS NULL`.
3. Se `is_published = false`, nessun utente (tranne owner e admin) la vede. Usato per moderazione.
4. `cover_media_id` se valorizzato, deve riferire a un `ActivityMedia` della stessa `source_client_id` (quando source_type = activity). Validazione a tempo di creazione.

### Relazioni

- N -> 1 con `Profile` (owner).
- 0..1 -> 1 con `Activity` o `PlannedRoute` (sorgente, via `source_client_id` polymorphic).
- 1 -> N con `RouteComment`, `RouteLike`.

---

## Sezione 9 -- RouteComment

**Scopo:** commento a una PublishedRoute. Append-only (non modificabile). L'utente puo' cancellare i propri commenti. L'owner della route puo' cancellare qualsiasi commento sulla propria route (moderazione).

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `published_route_id` | UUID | no | FK `published_routes.client_id`. |
| `author_id` | UUID | no | FK `profiles.id`. |
| `body` | String (1-1000 char) | no | |
| `is_flagged` | Boolean | no | Default `false`. Contenuto segnalato / sotto revisione. Vedi `02_database_schema.md` Sezione 4.8. |
| `flagged_reason` | String | si | Motivo del flag. |
| `flagged_at` | Timestamp | si | Quando e' stato flagged. |
| `created_at` | Timestamp | no | |
| `deleted_at` | Timestamp | si | Soft delete (conserva il thread, mostra "commento eliminato"). |

### Invarianti

1. No `updated_at` -- append-only.
2. No `version`.
3. Se `deleted_at` valorizzato, il `body` viene sovrascritto con stringa sistemica "[commento eliminato]" al momento del delete. Evita leak del contenuto.
4. Cascade soft-delete se la PublishedRoute parent viene eliminata.

### Relazioni

- N -> 1 con `PublishedRoute`.
- N -> 1 con `Profile` (author).

---

## Sezione 10 -- RouteLike

**Scopo:** like di un utente a una PublishedRoute. Unicita' per coppia (route, author).

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `published_route_id` | UUID | no | |
| `author_id` | UUID | no | |
| `created_at` | Timestamp | no | |

### Invarianti

1. UNIQUE `(published_route_id, author_id)`. Un utente non puo' likare due volte la stessa route.
2. Hard delete (non soft). Un "unlike" cancella il record.
3. Append-only -- non si modificano.

### Relazioni

- N -> 1 con `PublishedRoute`.
- N -> 1 con `Profile` (author).

---

## Sezione 11 -- FollowRelationship

**Scopo:** relazione "A segue B". Direzionale.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `follower_id` | UUID | no | Chi segue. FK `profiles.id`. |
| `followed_id` | UUID | no | Chi e' seguito. FK `profiles.id`. |
| `created_at` | Timestamp | no | |

### Invarianti

1. UNIQUE `(follower_id, followed_id)`.
2. CHECK `follower_id != followed_id` (non si segue se stessi).
3. Hard delete (unfollow = cancella record).
4. Se `follower_id` o `followed_id` viene soft-deleted (profilo anonimizzato), il record viene hard-deleted. Vedi overview Sezione 5.5.

### Relazioni

- N -> 1 con `Profile` (follower).
- N -> 1 con `Profile` (followed).

---

## Sezione 12 -- LiveSession

**Scopo:** sessione di condivisione posizione in tempo reale durante una Activity in corso. Vedi overview Sezione 5.3.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `owner_id` | UUID | no | Leader della sessione (chi sta guidando). |
| `activity_client_id` | UUID | no | = `recording_session.client_id` attiva all'avvio. |
| `title` | String (max 100 char) | si | |
| `started_at` | Timestamp | no | |
| `ended_at` | Timestamp | si | Null se ancora attiva. |
| `state` | Enum | no | `active \| ended_normal \| ended_timeout \| ended_by_leader`. |
| `share_token` | String | no | Token opaco usato per invitare partecipanti (link o QR). UNIQUE. Scade con la sessione. |
| `invited_profile_ids` | Array of UUID | no | Default `[]`. Profiles invitati esplicitamente. Gli altri vedono la live solo se hanno il `share_token`. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |

### Invarianti

1. Solo UNA LiveSession `active` per `owner_id` alla volta.
2. Transizioni di `state`: `active` -> uno tra `ended_normal` (leader stop), `ended_timeout` (10 min inattivita' GPS, vedi B.1), `ended_by_leader` (leader interrompe esplicitamente).
3. Scade automaticamente 24h dopo `started_at` se non gia' chiusa (failsafe).
4. `share_token` hard-deletable via revoca esplicita.

### Relazioni

- N -> 1 con `Profile` (owner).
- 1 -> 1 con `Activity` (via `activity_client_id`).
- 1 -> N con `LivePosition`.

---

## Sezione 13 -- LivePosition

**Scopo:** posizione istantanea condivisa durante una LiveSession. Effimera. TTL automatico.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `id` | UUID | no | Server-side, auto-generato. No client_id necessario -- fire-and-forget, idempotency non serve. |
| `live_session_id` | UUID | no | FK `live_sessions.id`. |
| `captured_at` | Timestamp | no | |
| `latitude` | Decimal | no | |
| `longitude` | Decimal | no | |
| `speed_kmh` | Decimal | si | |
| `heading_deg` | Decimal | si | |
| `expires_at` | Timestamp | no | Default `now() + interval '5 minutes'`. Cleanup automatico via pg_cron. |

### Invarianti

1. Hard delete automatico via TTL. pg_cron job orario cancella `live_positions WHERE expires_at < now()`.
2. NON vengono conservate dopo fine LiveSession. Il valore storico e' nulla.
3. Scrittura solo via Edge Function (RLS INSERT riservata), lettura per partecipanti della sessione.

### Relazioni

- N -> 1 con `LiveSession`.

---

## Sezione 14 -- SafetyContact

**Scopo:** contatto di sicurezza. Chi viene avvisato via SMS/email se l'utente scatena un SafetyEvent.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `owner_id` | UUID | no | |
| `name` | String (1-100 char) | no | |
| `phone_e164` | String | si | Formato E.164. |
| `email` | String | si | |
| `notify_on_sos` | Boolean | no | Default `true`. |
| `notify_on_long_ride_silence` | Boolean | no | Default `false`. Future feature (utente non si muove da X minuti -> notifica). |
| `priority` | Integer | no | 1-10, usato per ordinamento notifiche. Default 5. |
| `created_at` | Timestamp | no | |
| `updated_at` | Timestamp | no | |

### Invarianti

1. Almeno uno tra `phone_e164` e `email` deve essere valorizzato.
2. Massimo 5 SafetyContact per owner_id (soft limit).
3. NON soft delete -- se l'utente rimuove un contatto, cancellazione hard. Un contatto eliminato non deve ricevere accidentalmente notifiche future.

### Relazioni

- N -> 1 con `Profile` (owner).

---

## Sezione 15 -- SafetyEvent

**Scopo:** evento di sicurezza triggerato. Append-only. Log di tutti gli SOS e notifiche di sicurezza emesse.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `client_id` | UUID | no | |
| `id` | UUID | si | |
| `owner_id` | UUID | no | |
| `event_type` | Enum `sos_manual \| long_silence \| crash_detected` | no | `crash_detected` non usato in MVP (B.5). |
| `triggered_at` | Timestamp | no | |
| `latitude` | Decimal | si | Posizione al momento del trigger se disponibile. |
| `longitude` | Decimal | si | |
| `notified_contact_ids` | Array of UUID | no | `client_id` dei SafetyContact che hanno ricevuto la notifica. |
| `notification_channels_used` | Array of String | no | `["sms", "email"]` secondo cosa e' stato effettivamente mandato. |
| `resolved_at` | Timestamp | si | Quando l'utente marca l'evento come risolto (falso allarme o situazione gestita). |
| `resolution_note` | String | si | |
| `created_at` | Timestamp | no | = `triggered_at`. |

### Invarianti

1. Append-only tranne i campi di risoluzione (`resolved_at`, `resolution_note`).
2. `notified_contact_ids` e' snapshot -- se un SafetyContact viene cancellato dopo il trigger, il record SafetyEvent conserva lo storico.

### Relazioni

- N -> 1 con `Profile` (owner).

---

## Sezione 16 -- Notification

**Scopo:** notifica in-app per l'utente. Generata server-side via Edge Function. Client legge, aggiorna solo `read_at`.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `id` | UUID | no | Server-side. |
| `recipient_id` | UUID | no | FK `profiles.id`. |
| `type` | Enum | no | `new_follower \| new_comment_on_route \| new_like_on_route \| live_session_invite \| safety_event_triggered \| system_message`. |
| `payload` | JSON | no | Dati strutturati del tipo di notifica (chi ha commentato, testo commento, ecc.). |
| `deep_link` | String | si | Rotta in-app dove porta il tap. |
| `read_at` | Timestamp | si | Null se non letta. |
| `created_at` | Timestamp | no | |

### Invarianti

1. Creata solo da Edge Function -- mai dal client direttamente (vedi RLS matrix overview Sezione 6).
2. Client puo' UPDATE solo `read_at`. Nessun altro campo modificabile.
3. Hard delete da pg_cron se `read_at IS NOT NULL` e `created_at < now() - interval '30 days'`.
4. Hard delete immediato su richiesta utente (cestinamento).

### Relazioni

- N -> 1 con `Profile` (recipient).

---

## Sezione 17 -- ErrorLog

**Scopo:** log tecnico errori. Solo inserimento client, lettura admin. Vedi overview Sezione 5.10.

### Campi

| Campo | Tipo | Nullable | Note |
|---|---|---|---|
| `id` | UUID | no | Server-side. |
| `user_id` | UUID | si | `profiles.id`. Null se errore pre-login. |
| `platform` | Enum `android \| ios` | no | |
| `app_version` | String | no | |
| `module` | String | no | Nome del modulo dove e' avvenuto l'errore. |
| `level` | Enum `warn \| error \| fatal` | no | |
| `message` | String | no | |
| `stack_trace` | String | si | |
| `context` | JSON | no | Default `{}`. Metadati aggiuntivi. |
| `created_at` | Timestamp | no | |

### Invarianti

1. Append-only. Nessun update, nessun delete client-side.
2. pg_cron pulisce `created_at < now() - interval '90 days'`.

### Relazioni

- N -> 1 con `Profile` (user, opzionale).

---

## Sezione 17.bis -- Report

Segnalazione di contenuto o utente, alimentata da `CommunityApi.reportContent()` e processata da admin.

### Campi principali

- `id` UUID PK.
- `reporter_id` FK a Profile.
- `entity_kind` enum: `published_route | route_comment | profile`.
- `entity_client_id` UUID (polymorphic, no FK reale).
- `reason` enum: `spam | inappropriate | harassment | other`.
- `notes` TEXT opzionale, max 1000 char.
- `status` enum: `pending | reviewed | dismissed | action_taken`.
- `action_taken` TEXT libero (es. "content_flagged", "user_banned").
- `reviewer_id` FK opzionale a Profile (admin).
- `reviewed_at` TIMESTAMPTZ opzionale.
- `created_at`.

### Invarianti

- Un reporter non puo' avere piu' di un report `pending` per la stessa (entity_kind, entity_client_id). UNIQUE parziale (vedi `02_database_schema.md` Sezione 3.16).
- Il reporter non modifica `status` / `action_taken` / `reviewer_id`. Solo admin via UI dedicata.

### Relazioni

- N -> 1 con `Profile` (reporter).
- N -> 1 con `Profile` (reviewer, opzionale).
- Riferimento polymorphic a `PublishedRoute | RouteComment | Profile` via `entity_client_id`.

### Nota moderazione

Insieme a `Profile.account_status` e `PublishedRoute.is_flagged` / `RouteComment.is_flagged`, costituisce la base minima per un sistema di moderazione estensibile. L'admin UI MVP e' minimale (vedi B.2). Lo schema e' dimensionato per sostenere evoluzioni senza migration.

---

## Sezione 18 -- Mappa relazionale globale

```
                        Profile (1)
                        /  |  |  \  \  \  \
                       /   |  |   \  \  \  \
                      /    |  |    \  \  \  \
             Motorcycle  Activity  PlannedRoute
               (N)        (N)         (N)
                            |           |
                            |           |
                      ActivityMedia     |
                          (N)           |
                            |           |
                       RecordingSession |
                            |           |
                       TrackPointBuffer |
                            (N)         |
                                        |
                    +-------------------+
                    |
              PublishedRoute (N per profile)
                  /      \
           RouteComment  RouteLike
              (N)          (N)

     FollowRelationship: Profile <-> Profile (self M:N)

     LiveSession (N per profile)
         |
       LivePosition (N, effimera)

     SafetyContact (N per profile)
         |
       SafetyEvent (N per profile, riferisce contacts snapshot)

     Notification (N per profile, tutte server-generated)
     ErrorLog     (N per profile, technical)
```

### FK critiche con politica ON DELETE

- `motorcycles.owner_id -> profiles.id`: ON DELETE RESTRICT (non si cancella un profile se ha ancora moto attive). In pratica il soft-delete del profile anonimizza ma mantiene le moto.
- `activities.motorcycle_id -> motorcycles.client_id`: ON DELETE SET NULL (moto cancellata, activity conservata senza moto).
- `activities.owner_id -> profiles.id`: ON DELETE RESTRICT (coerente: soft-delete profile, activity conservata ma anonimizzata).
- `published_routes.source_client_id`: ON DELETE SET NULL (sorgente cancellata, published sopravvive).
- `route_comments.published_route_id -> published_routes.client_id`: ON DELETE CASCADE (se la route sparisce, i commenti spariscono).
- `route_likes.published_route_id -> published_routes.client_id`: ON DELETE CASCADE.
- `follow_relationships.*`: ON DELETE CASCADE (cancellato un utente, cancellate le sue relationship).
- `live_positions.live_session_id -> live_sessions.id`: ON DELETE CASCADE.
- `activity_media.activity_id -> activities.client_id`: ON DELETE CASCADE.

Dettagli SQL delle FK in `02_database_schema.md`.

---

## Sezione 19 -- Invarianti cross-entita'

Queste invarianti non vivono in una singola entita' ma riguardano relazioni tra piu' entita'. Vengono enforced da trigger Postgres (dettaglio in `02_database_schema.md`) o da logica applicativa.

### I.1 -- Somma km moto
Per ogni `motorcycle` non soft-deleted:
```
total_km = odometer_start_km + SUM(activity.distance_km
                                    WHERE activity.motorcycle_id = motorcycle.client_id
                                    AND activity.deleted_at IS NULL)
```
Mantenuta dal trigger `recompute_motorcycle_km`.

### I.2 -- Unicita' recording attiva
Per ogni `profile`: al massimo una `recording_session` con `state = 'active'`.

### I.3 -- Unicita' live session attiva
Per ogni `profile`: al massimo una `live_session` con `state = 'active'`.

### I.4 -- Coerenza published vs source
Una `published_route` con `source_type = 'activity'` deve avere `source_client_id` valorizzato o null (se la sorgente e' stata cancellata). Mai puntare a una sorgente di tipo sbagliato.

### I.5 -- Primary motorcycle
Per ogni `profile`: al massimo una `motorcycle` con `is_primary = true` e `deleted_at IS NULL`.

### I.6 -- Denormalizzazione owner in media
`activity_media.owner_id = (activity WHERE client_id = activity_media.activity_id).owner_id`. Enforced da trigger su INSERT/UPDATE di `activity_media`.

### I.7 -- No self-follow
`follow_relationship.follower_id != followed_id`. Enforced da CHECK constraint.

### I.8 -- Visibility e PublishedRoute
Una Activity o PlannedRoute con `visibility = private` non puo' essere sorgente di una PublishedRoute attiva. Enforced a livello applicativo (check client + Edge Function al momento del publish).

---

## Sezione 20 -- Riepilogo entita' e classificazione

| Entita' | Client-gen ID? | Soft delete? | Sincronizzata? | Note |
|---|---|---|---|---|
| `Profile` | No (auth) | Si | Si | |
| `Motorcycle` | Si | Si | Si | |
| `RecordingSession` | Si | No | **No** | Solo drift |
| `TrackPointBuffer` | No (autoincrement) | No | No | Solo drift |
| `Activity` | Si | Si | Si | |
| `ActivityMedia` | Si | No (hard) | Si | |
| `PlannedRoute` | Si | Si | Si | |
| `PublishedRoute` | Si | Si | Si | |
| `RouteComment` | Si | Si | Si | Append-only eccetto delete |
| `RouteLike` | Si | No (hard) | Si | Append-only, toggle |
| `FollowRelationship` | Si | No (hard) | Si | Append-only, toggle |
| `LiveSession` | Si | No | Si (Realtime) | |
| `LivePosition` | No | No (TTL) | Si (Realtime) | Effimera |
| `SafetyContact` | Si | No (hard) | Si | |
| `SafetyEvent` | Si | No | Si | Append-only |
| `Notification` | No (server) | No (TTL) | Si | Server-generated |
| `ErrorLog` | No (server) | No (pg_cron) | Si | Technical |

---

## Sezione 21 -- Domande che emergono verso moduli successivi

Alcune decisioni locali sono state deferite a documenti piu' specifici. Le elenco qui per tracciabilita':

- **Algoritmo calcolo distance_km** (gestione tunnel, pause, GPS noise): `04_tracking/gps_filters.md`.
- **Quando si decide la transizione `closed_unsynced -> closed_synced`**: `05_sync/L0_architecture.md`.
- **Shape del payload di upload Activity**: `05_sync/queue_design.md`.
- **Come il client gestisce il caso "conflict 409" durante sync** (non dovrebbe mai accadere grazie a idempotency ma gestione difensiva): `05_sync/edge_cases.md`.
- **Rehydration dal server a nuovo device**: `05_sync/L0_architecture.md`.
- **Trigger SQL `recompute_motorcycle_km` completo**: `02_database_schema.md`.

---

**Fine 01_data_model.md**
