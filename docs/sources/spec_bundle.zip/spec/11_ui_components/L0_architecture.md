# 11 / UI Components -- L0 Architecture

**Scopo:** pacchetto trasversale con design tokens, widget riusabili, pattern UI comuni a tutta l'app. Non una feature verticale, ma la **fondazione visuale** dei moduli UI.

**Cosa NON e' qui:**

- Widget specifici di un modulo (es. `tracking/widgets/tracking_metrics_display.dart`). Quelli restano nei rispettivi moduli.
- Logica di business. Questo modulo e' puramente presentational.

**Riferimenti:**

- Principio modulare: `00_overview.md` Sezione 4.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Centralizzare gli elementi di interfaccia comuni per garantire coerenza visiva, manutenibilita', e refattorizzabilita' della UI. Ogni modulo UI importa da `ui_components` invece di reinventare.

**Principi:**

1. **Token-first.** Colori, spacing, typography definiti come costanti, mai hardcoded.
2. **Composition over inheritance.** Widget componibili, non gerarchie profonde.
3. **Accessibility by default.** Ogni widget ha contrasto WCAG AA, supporta screen reader, supporta testo ingrandito.
4. **Theme-aware.** Light mode + Dark mode di base, piu' una palette "high-visibility" per uso in moto sotto sole forte.

---

## Sezione 2 -- Struttura

```
modules/ui_components/
|-- lib/
|   |-- ui_components.dart                  (export pubblico)
|   +-- src/
|       |-- tokens/
|       |   |-- colors.dart                 (AppColors class con tutti i token)
|       |   |-- typography.dart             (AppTypography)
|       |   |-- spacing.dart                (AppSpacing)
|       |   |-- radius.dart
|       |   |-- elevation.dart
|       |   +-- durations.dart              (animazioni)
|       |-- theme/
|       |   |-- app_theme.dart              (ThemeData builder)
|       |   |-- theme_mode_notifier.dart
|       |   +-- high_visibility_theme.dart
|       |-- widgets/
|       |   |-- buttons/
|       |   |   |-- primary_button.dart
|       |   |   |-- secondary_button.dart
|       |   |   |-- destructive_button.dart
|       |   |   +-- icon_button.dart
|       |   |-- inputs/
|       |   |   |-- app_text_field.dart
|       |   |   |-- search_field.dart
|       |   |   +-- tags_input.dart
|       |   |-- surfaces/
|       |   |   |-- card.dart
|       |   |   |-- bottom_sheet.dart
|       |   |   +-- modal.dart
|       |   |-- feedback/
|       |   |   |-- snackbar_service.dart
|       |   |   |-- empty_state.dart
|       |   |   |-- error_state.dart
|       |   |   +-- loading_indicator.dart
|       |   |-- navigation/
|       |   |   |-- app_bar.dart
|       |   |   |-- bottom_nav.dart
|       |   |   +-- tab_bar.dart
|       |   |-- data_display/
|       |   |   |-- stat_badge.dart
|       |   |   |-- polyline_preview.dart   (rendering polyline ridotto)
|       |   |   |-- avatar.dart
|       |   |   +-- user_chip.dart
|       |   |-- dialogs/
|       |   |   |-- confirmation_dialog.dart
|       |   |   |-- countdown_dialog.dart   (per SOS)
|       |   |   +-- sos_button.dart
|       |   +-- motion/
|       |       +-- page_transition.dart
|       |-- accessibility/
|       |   +-- a11y_helpers.dart
|       +-- platform/
|           |-- safe_area_aware.dart
|           +-- platform_ui.dart
|-- test/
+-- pubspec.yaml
```

---

## Sezione 3 -- Design tokens

### 3.1 Colors

Palette di base + semantic naming:

```dart
class AppColors {
  // Semantic
  static const primary = Color(0xFF1E88E5);    // blu (esempio)
  static const secondary = Color(0xFF00ACC1);
  static const danger = Color(0xFFE53935);
  static const warning = Color(0xFFFB8C00);
  static const success = Color(0xFF43A047);
  static const info = Color(0xFF1976D2);

  // Surfaces (light)
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF5F5F5);
  static const background = Color(0xFFFFFFFF);
  static const onSurface = Color(0xFF212121);
  static const onSurfaceMuted = Color(0xFF757575);
  static const divider = Color(0xFFE0E0E0);

  // Dark mode equivalents
  // ...

  // High-visibility mode (uso in moto)
  static const hiVizBackground = Color(0xFF000000);
  static const hiVizText = Color(0xFFFFFFFF);
  static const hiVizAccent = Color(0xFFFFEB3B);   // giallo safety

  // Domain-specific
  static const mapPolyline = Color(0xFF00838F);
  static const sosRed = Color(0xFFB71C1C);
}
```

Palette esatta da definire con design lead (non MVP critical -- inizialmente usiamo Material 3 default).

### 3.2 Typography

```dart
class AppTypography {
  static const display = TextStyle(fontSize: 32, fontWeight: FontWeight.w700);
  static const headline = TextStyle(fontSize: 24, fontWeight: FontWeight.w600);
  static const title = TextStyle(fontSize: 18, fontWeight: FontWeight.w600);
  static const body = TextStyle(fontSize: 16, fontWeight: FontWeight.w400);
  static const bodySmall = TextStyle(fontSize: 14, fontWeight: FontWeight.w400);
  static const caption = TextStyle(fontSize: 12, fontWeight: FontWeight.w400);
  static const button = TextStyle(fontSize: 16, fontWeight: FontWeight.w600);

  // Monospace per metriche live (allineamento numeri)
  static const metric = TextStyle(
    fontSize: 24,
    fontFamily: 'RobotoMono',
    fontWeight: FontWeight.w500,
  );
}
```

### 3.3 Spacing

Scala a multipli di 4:

```dart
class AppSpacing {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 16.0;
  static const lg = 24.0;
  static const xl = 32.0;
  static const xxl = 48.0;
}
```

### 3.4 Radius

```dart
class AppRadius {
  static const sm = 4.0;
  static const md = 8.0;
  static const lg = 16.0;
  static const full = 999.0;   // pill shape
}
```

### 3.5 Durations (animazioni)

```dart
class AppDurations {
  static const fast = Duration(milliseconds: 150);
  static const medium = Duration(milliseconds: 300);
  static const slow = Duration(milliseconds: 500);
}
```

---

## Sezione 4 -- Theme builder

```dart
class AppTheme {
  static ThemeData light() => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
    textTheme: _buildTextTheme(),
    // ... integrazione tokens
  );

  static ThemeData dark() => ThemeData(/* ... */);

  static ThemeData highVisibility() => ThemeData(/* ... */);
}
```

Theme selection: `ThemeModeNotifier` (ChangeNotifier + Provider) ascolta preference utente e ricostruisce MaterialApp.

---

## Sezione 5 -- Widget principali

### 5.1 `PrimaryButton`, `SecondaryButton`, `DestructiveButton`

Wrapping di `FilledButton` / `OutlinedButton` / `TextButton` con:
- Stato loading (spinner interno).
- Stato disabled con opacity.
- onPressed async support con disabling automatico durante future.

### 5.2 `AppTextField`

Wrapping di `TextFormField` con:
- Label, hint, error consistenti.
- Validator helper comuni (email, required, min/max length).
- Countdown caratteri opzionale.

### 5.3 `StatBadge`

Widget per mostrare una metrica (es. distance, duration, avg speed).

```dart
StatBadge(
  label: 'Distanza',
  value: '145.2',
  unit: 'km',
  icon: Icons.route,
)
```

### 5.4 `PolylinePreview`

Rendering polyline statica su SVG (no Mapbox chiamata). Usato in feed community, history activity, detail PlannedRoute.

Input: polyline_encoded. Decodifica, proietta bbox su canvas, disegna line.

Opzioni: color, stroke width, background.

### 5.5 `EmptyState`, `ErrorState`

Widget standard per stato vuoto (lista empty) e stato di errore. Icon + testo + optional CTA.

### 5.6 `ConfirmationDialog`, `CountdownDialog`

Dialog standard "Sei sicuro?" e timed (per SOS 5s countdown).

### 5.7 `SosButton`

Riusato in safety_screen e opzionalmente in floating overlay durante tracking. Red pulsating circle. onPressed -> triggerSos flow.

### 5.8 `SnackbarService`

Service globale per mostrare snackbar consistenti. Chiamato via context extension `context.showSnackbar(message, type)`.

Types: success, info, warning, error.

---

## Sezione 6 -- Accessibility

Standard:

- Ogni bottone ha `Semantics` label.
- Ogni input ha `semanticLabel`.
- Testo rispetta `MediaQuery.textScaleFactor` (OS font size setting).
- Contrasto minimo 4.5:1 per testo, 3:1 per elementi grafici.
- Aree interattive min 44x44 pt (touch target Apple HIG / Material).

Tests lint: `flutter_a11y_test` o check manuale con Accessibility Scanner.

---

## Sezione 7 -- Non ha API tradizionale

`ui_components` non espone una classe `Api`. Espone widget, tokens, theme builder. I moduli UI importano direttamente.

**Convenzione:** `import 'package:ui_components/ui_components.dart' as ui;` e uso `ui.PrimaryButton(...)`, `ui.AppColors.primary`, ecc. Oppure import diretto se preferito.

Niente eventi, niente DAO, niente Result. E' puro presentational.

---

## Sezione 8 -- Theme mode persistence

Preference salvata in `profile.feature_flags.theme_mode` (`light` | `dark` | `system` | `high_visibility`). Sync con server.

Cambio theme mode applicato immediatamente via `ThemeModeNotifier.setMode(newMode)`.

---

## Sezione 9 -- Dependencies

- Solo Flutter SDK + Material 3.
- Nessuna dipendenza su altri moduli.
- **Altri moduli UI dipendono da ui_components**, non viceversa.

---

## Sezione 10 -- Testing

### 10.1 Golden tests

Widget visuali testati con golden files (snapshot pixel). Check su 3 temi x device typical (Pixel 5, iPhone 12).

### 10.2 Widget tests

- Button: loading state funziona.
- AppTextField: validator triggerano.
- PolylinePreview: render corretto con polyline nota.
- CountdownDialog: completa dopo N secondi, cancel rimuove.

### 10.3 Accessibility tests

- Semantics labels presenti.
- Contrasto WCAG su tutti i tokens.

---

## Sezione 11 -- Nota sul design

Il disegno visivo esatto (palette colori finale, iconografia, sorelle di componenti) e' **decisione di design lead**. Questa spec fornisce la **struttura** del pacchetto e i principi. Il polish visivo arriva dopo.

**Per MVP:** Material 3 default con accent color blu. Dark mode funzionante. High-visibility mode come feature differentiante futura (non MVP blocco).

---

**Fine 11_ui_components/L0_architecture.md**
