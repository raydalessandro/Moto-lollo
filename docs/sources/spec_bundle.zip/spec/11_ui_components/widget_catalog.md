# 11 / UI Components -- Widget Catalog

**Scopo:** firme Dart dei widget pubblici esportati da `ui_components`. Non e' un L0.5 classico (niente API verticale) ma un catalogo.

**Riferimenti:** `L0_architecture.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Buttons

```dart
class PrimaryButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final FutureOr<void> Function()? onPressed;
  final bool fullWidth;
  final bool loading;

  const PrimaryButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.fullWidth = false,
    this.loading = false,
  });
}

class SecondaryButton extends StatelessWidget { /* stessa shape */ }

class DestructiveButton extends StatelessWidget { /* stessa shape */ }

class AppIconButton extends StatelessWidget {
  final IconData icon;
  final FutureOr<void> Function()? onPressed;
  final String? tooltip;
  final double size;
}
```

**Comportamento loading:** quando `loading == true` il bottone mostra spinner interno, `onPressed` ignorato. Usato automaticamente se `onPressed` ritorna un Future (async): durante l'esecuzione il bottone diventa auto-loading.

---

## Sezione 2 -- Inputs

```dart
class AppTextField extends StatelessWidget {
  final TextEditingController? controller;
  final String label;
  final String? hint;
  final String? helperText;
  final String? errorText;
  final TextInputType keyboardType;
  final bool obscureText;
  final int? maxLength;
  final int? minLines;
  final int? maxLines;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final Widget? suffixIcon;
  final bool showCounter;
}

class SearchField extends StatelessWidget {
  final TextEditingController? controller;
  final String hint;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onClear;
}

class TagsInput extends StatelessWidget {
  final List<String> tags;
  final ValueChanged<List<String>> onChanged;
  final int maxTags;
  final List<String>? suggestions;
}
```

---

## Sezione 3 -- Surfaces

```dart
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final double elevation;
}

Future<T?> showAppBottomSheet<T>({
  required BuildContext context,
  required Widget Function(BuildContext) builder,
  bool isDismissible = true,
  bool isScrollControlled = false,
});

Future<T?> showAppModal<T>({
  required BuildContext context,
  required Widget Function(BuildContext) builder,
});
```

---

## Sezione 4 -- Feedback

```dart
// Service globale (register in ModuleRegistry, accesso via context extension).
class SnackbarService {
  void show({
    required String message,
    SnackbarType type = SnackbarType.info,
    Duration duration = const Duration(seconds: 3),
    SnackBarAction? action,
  });
}

enum SnackbarType { success, info, warning, error }

// Extension per comodita'
extension SnackbarContext on BuildContext {
  void showSnackbar(String message, {SnackbarType type = SnackbarType.info}) {
    SnackbarService.instance.show(message: message, type: type);
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;    // tipicamente PrimaryButton
}

class ErrorState extends StatelessWidget {
  final String title;
  final String? message;
  final VoidCallback? onRetry;
}

class LoadingIndicator extends StatelessWidget {
  final double size;
  final String? message;
}
```

---

## Sezione 5 -- Data Display

```dart
class StatBadge extends StatelessWidget {
  final String label;
  final String value;
  final String? unit;
  final IconData? icon;
  final TextStyle? valueStyle;
}

class PolylinePreview extends StatelessWidget {
  final String polylineEncoded;
  final double aspectRatio;
  final Color lineColor;
  final double strokeWidth;
  final Color? backgroundColor;
}

class Avatar extends StatelessWidget {
  final String? imageUrl;
  final String? initials;
  final double size;
}

class UserChip extends StatelessWidget {
  final String username;
  final String? avatarUrl;
  final VoidCallback? onTap;   // navigate to profile
}
```

---

## Sezione 6 -- Navigation

```dart
class AppBarStandard extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Widget? leading;
  final List<Widget>? actions;
  final bool centerTitle;
}

class AppBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onChanged;
  final List<BottomNavItem> items;
}
```

---

## Sezione 7 -- Dialogs

```dart
Future<bool?> showConfirmationDialog({
  required BuildContext context,
  required String title,
  required String message,
  String confirmLabel = 'Conferma',
  String cancelLabel = 'Annulla',
  bool destructive = false,
});

Future<bool?> showCountdownDialog({
  required BuildContext context,
  required String title,
  required String message,
  required Duration countdown,
  required String confirmLabel,   // es. "Invia SOS ora"
  String cancelLabel = 'Annulla',
});

class SosButton extends StatefulWidget {
  final FutureOr<void> Function() onTriggered;
  final double size;
  final bool pulsating;
}
```

`showCountdownDialog` e' usato da SafetyApi per conferma SOS (5s di countdown).

---

## Sezione 8 -- Theme

```dart
class AppTheme {
  static ThemeData light();
  static ThemeData dark();
  static ThemeData highVisibility();
}

class ThemeModeNotifier extends ChangeNotifier {
  AppThemeMode get mode;
  void setMode(AppThemeMode newMode);
}

enum AppThemeMode { system, light, dark, highVisibility }
```

---

## Sezione 9 -- Tokens export

Esportati come classi statiche dal barrel `ui_components.dart`:

- `AppColors`
- `AppTypography`
- `AppSpacing`
- `AppRadius`
- `AppDurations`

---

## Sezione 10 -- Uso da altri moduli

Esempio in `modules/tracking/lib/src/ui/tracking_screen.dart`:

```dart
import 'package:ui_components/ui_components.dart';

class TrackingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBarStandard(title: 'Registrazione'),
      body: Padding(
        padding: EdgeInsets.all(AppSpacing.md),
        child: Column(
          children: [
            StatBadge(label: 'Distanza', value: '24.3', unit: 'km'),
            SizedBox(height: AppSpacing.sm),
            PrimaryButton(
              label: 'Ferma registrazione',
              onPressed: () => api.stopRecording(),
            ),
          ],
        ),
      ),
    );
  }
}
```

---

**Fine 11_ui_components/widget_catalog.md**
