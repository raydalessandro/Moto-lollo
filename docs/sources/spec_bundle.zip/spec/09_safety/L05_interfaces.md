# 09 / Safety -- L0.5 Interfaces

**Scopo:** firme Dart modulo safety.

**Riferimenti:** `L0_architecture.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Types di dominio

### 1.1 `SafetyContact`

```dart
@freezed
class SafetyContact with _$SafetyContact {
  const factory SafetyContact({
    required String clientId,
    required String ownerId,
    required String name,
    required String? phone,      // formato E.164 (+39...)
    required String? email,
    required DateTime createdAt,
    required DateTime updatedAt,
    required int version,
  }) = _SafetyContact;
}
```

### 1.2 `SafetyEvent`

```dart
@freezed
class SafetyEvent with _$SafetyEvent {
  const factory SafetyEvent({
    required String clientId,
    required String ownerId,
    required DateTime triggeredAt,
    required double latitude,
    required double longitude,
    required String? activityClientId,
    required List<String> notifiedContactIds,
    required List<String> notificationChannelsUsed,   // ['sms', 'email']
    required Map<String, NotificationStatus> notificationStatuses,
  }) = _SafetyEvent;
}

@freezed
class NotificationStatus with _$NotificationStatus {
  const factory NotificationStatus({
    required String contactClientId,
    required String channel,       // 'sms' | 'email'
    required NotificationResult result,
    required DateTime? sentAt,
    required String? errorCode,
  }) = _NotificationStatus;
}

enum NotificationResult { pending, sent, failed }
```

### 1.3 `LiveSession`

```dart
@freezed
class LiveSession with _$LiveSession {
  const factory LiveSession({
    required String clientId,
    required String ownerId,
    required DateTime startedAt,
    required DateTime? endedAt,
    required LiveSessionState state,
    required String shareableUrl,
    required String? activityClientId,
  }) = _LiveSession;
}

enum LiveSessionState { active, ended }
```

### 1.4 `CreateSafetyContactRequest`

```dart
@freezed
class CreateSafetyContactRequest with _$CreateSafetyContactRequest {
  const factory CreateSafetyContactRequest({
    required String name,
    String? phone,
    String? email,
  }) = _CreateSafetyContactRequest;
}
```

### 1.5 `SafetyError`

```dart
sealed class SafetyError {
  const SafetyError();
}

final class ValidationError extends SafetyError {
  final String field;
  final String message;
  const ValidationError(this.field, this.message);
}

final class MaxContactsReachedError extends SafetyError {
  // Piu' di 5 contatti
  const MaxContactsReachedError();
}

final class NoContactsConfiguredError extends SafetyError {
  // SOS triggerato ma 0 SafetyContact configurati
  const NoContactsConfiguredError();
}

final class LocationUnavailableError extends SafetyError {
  // SOS triggerato ma GPS non disponibile
  const LocationUnavailableError();
}

final class OfflineSosError extends SafetyError {
  // SOS offline: record creato ma non inviato
  final String safetyEventClientId;
  const OfflineSosError(this.safetyEventClientId);
}

final class LiveSessionAlreadyActiveError extends SafetyError {
  final String activeClientId;
  const LiveSessionAlreadyActiveError(this.activeClientId);
}

final class ContactNotFoundError extends SafetyError {
  final String clientId;
  const ContactNotFoundError(this.clientId);
}

final class PartialDispatchError extends SafetyError {
  // Qualche invio SOS fallito
  final String safetyEventClientId;
  final int successCount;
  final int failureCount;
  const PartialDispatchError(
    this.safetyEventClientId,
    this.successCount,
    this.failureCount,
  );
}

final class InternalFailureError extends SafetyError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

---

## Sezione 2 -- `SafetyApi` (contratto)

```dart
abstract class SafetyApi {
  // ========== CONTACTS ==========

  Stream<List<SafetyContact>> watchContacts();

  Future<List<SafetyContact>> getContacts();

  Future<Result<String, SafetyError>> addContact(
    CreateSafetyContactRequest request,
  );

  Future<Result<void, SafetyError>> updateContact(
    String clientId, {
    String? name,
    String? phone,
    String? email,
  });

  Future<Result<void, SafetyError>> removeContact(String clientId);

  // ========== SOS ==========

  /// Triggera SOS. Invia messaggi a tutti i SafetyContact configurati.
  /// Ritorna il clientId del SafetyEvent creato.
  ///
  /// Errori attesi:
  /// - NoContactsConfiguredError: utente non ha contatti.
  /// - LocationUnavailableError: GPS non disponibile.
  /// - OfflineSosError: device offline (ma SafetyEvent e' comunque persistito).
  /// - PartialDispatchError: alcuni invii falliti, altri ok.
  Future<Result<String, SafetyError>> triggerSos();

  /// Storia SafetyEvent dell'utente (ultimi 30 giorni).
  Future<List<SafetyEvent>> getRecentSafetyEvents();

  Stream<SafetyEvent?> watchMostRecentSafetyEvent();

  // ========== LIVE SESSION ==========

  /// Avvia una live session. Genera share URL.
  /// Errore: LiveSessionAlreadyActiveError se c'e' gia' una session attiva.
  Future<Result<LiveSession, SafetyError>> startLiveSession({
    String? activityClientId,
  });

  /// Ferma la live session in corso.
  Future<Result<void, SafetyError>> endLiveSession();

  /// Session attiva, o null.
  Future<LiveSession?> getActiveLiveSession();

  Stream<LiveSession?> watchActiveLiveSession();
}
```

---

## Sezione 3 -- Eventi emessi

```dart
@freezed
class SafetyEventTriggeredEvent with _$SafetyEventTriggeredEvent {
  const factory SafetyEventTriggeredEvent({
    required String clientId,
    required String ownerId,
    required DateTime triggeredAt,
    required double latitude,
    required double longitude,
    required int contactsNotifiedCount,
  }) = _SafetyEventTriggeredEvent;
}

@freezed
class LiveSessionStartedEvent with _$LiveSessionStartedEvent {
  const factory LiveSessionStartedEvent({
    required String clientId,
    required String ownerId,
    required String shareableUrl,
    required DateTime startedAt,
  }) = _LiveSessionStartedEvent;
}

@freezed
class LiveSessionEndedEvent with _$LiveSessionEndedEvent {
  const factory LiveSessionEndedEvent({
    required String clientId,
    required DateTime endedAt,
    required LiveSessionEndReason reason,
  }) = _LiveSessionEndedEvent;
}

enum LiveSessionEndReason { manualStop, gpsInactivity, failsafe24h }

@freezed
class SafetyContactAddedEvent with _$SafetyContactAddedEvent {
  const factory SafetyContactAddedEvent({
    required String clientId,
    required String ownerId,
    required DateTime createdAt,
  }) = _SafetyContactAddedEvent;
}

// analoghi Updated / Removed
```

---

## Sezione 4 -- `SafetyModule` (manifest)

```dart
class SafetyModule extends AppModule {
  @override
  String get name => 'safety';

  @override
  List<String> get dependsOn => [
    'shared.db',
    'shared.event_bus',
    'shared.auth',
    'shared.supabase',
  ];

  @override
  List<Type> get provides => [SafetyApi];

  @override
  List<Type> get consumes => [TrackingApi, ProfileApi];

  @override
  void register(ModuleRegistry r) {
    // instanziazione dei 3 service (contacts, sos, live_sharing)
    // aggregazione in SafetyApiImpl
  }
}
```

---

## Sezione 5 -- Thread model

Tutte le operazioni su main isolate. Realtime Supabase gestisce Subscribe internamente su thread native ma marshalling a main isolate.

---

## Sezione 6 -- Test contracts

- CRUD SafetyContact + max 5 + invariante phone XOR email (almeno uno).
- triggerSos happy + offline + partial failure + no contacts.
- LiveSession start + end + timeout 10 min + failsafe 24h.

---

**Fine 09_safety/L05_interfaces.md**
