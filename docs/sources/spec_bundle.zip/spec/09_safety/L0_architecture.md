# 09 / Safety -- L0 Architecture

**Scopo:** meccanismi di sicurezza: contatti di emergenza, pulsante SOS, condivisione posizione live durante un giro.

**Cosa NON e' qui:**

- Crash detection (fuori scope MVP, vedi B.5).
- Trigger di SOS da hardware esterno (bluetooth button -- post-MVP).
- Tracking GPS del giro stesso (modulo 04).

**Riferimenti:**

- Entita' SafetyContact, SafetyEvent, LiveSession: `01_data_model.md` Sezioni 12-14.
- Policy MVP: `00_overview.md` Sezione 5.3 e 5.11.
- Twilio SMS + SendGrid email: `00_overview.md` stack.
- LiveSession timeout: D.36.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

**Tre sotto-funzioni indipendenti ma correlate:**

1. **SafetyContacts**: anagrafica dei contatti di emergenza dell'utente (nome, telefono, email). Persistenti.
2. **SOS**: pulsante che invia alert ai SafetyContacts con posizione attuale e profilo dell'utente.
3. **LiveSession**: condivisione continua posizione a contatti scelti durante un giro, con link shareable.

Il modulo e' **owner** di SafetyContact, SafetyEvent, LiveSession.

**Principio chiave:** **nessuna falsa sicurezza**. Se una funzione non puo' garantire recapito del messaggio (no connessione, Twilio fail), l'utente deve saperlo chiaramente. Mai indicare "inviato" se non e' stato inviato.

---

## Sezione 2 -- Struttura interna

```
modules/safety/
|-- lib/
|   |-- safety.dart
|   |-- api.dart
|   +-- src/
|       |-- domain/
|       |   |-- safety_contact.dart
|       |   |-- safety_event.dart
|       |   |-- live_session.dart
|       |   +-- safety_error.dart
|       |-- application/
|       |   |-- contacts_service.dart
|       |   |-- sos_service.dart
|       |   |-- live_sharing_service.dart
|       |   +-- emergency_dispatcher.dart
|       |-- persistence/
|       |   |-- safety_contacts_dao.dart
|       |   |-- safety_events_dao.dart
|       |   +-- live_sessions_dao.dart
|       +-- ui/
|           |-- safety_screen.dart
|           |-- sos_button.dart
|           |-- live_share_screen.dart
|           |-- contacts_management_screen.dart
|           +-- widgets/
|-- test/
+-- pubspec.yaml
```

---

## Sezione 3 -- SafetyContacts

### 3.1 Modello

Max 5 contatti per utente (CHECK constraint gia' in schema). Campi: `name`, `phone` (nullable), `email` (nullable), con invariante "almeno uno tra phone/email" (CHECK).

**Non sono utenti dell'app.** Sono contatti esterni (moglie, genitore, amico). L'email e il telefono sono endpoint esterni.

### 3.2 Operazioni

- `addContact(CreateSafetyContactRequest)`.
- `updateContact(clientId, Update)`.
- `removeContact(clientId)`.
- `getContacts()` -> List<SafetyContact>.
- `watchContacts()` -> Stream.

### 3.3 Sync

SafetyContact fa parte delle entita' sincronizzate (server source of truth). Sync orchestrator enqueue con priorita' alta (coerente con `05_sync/queue_design.md` Sezione 2: priority 2).

---

## Sezione 4 -- SOS

### 4.1 Trigger

Il pulsante SOS e' un widget grande, rosso, prominente nell'app:

- Tipicamente in bottom-nav o header della dashboard.
- Tap singolo apre dialog di conferma (5 secondi countdown con "Annulla" / "Invia ora").
- Default auto-invio dopo 5s se utente non tocca niente (difesa anti-panic: se ha attivato e non puo' toccare, va inviato).

**Alternative discussi ma rinviati:**

- Triple tap del power button: richiede intent Android nativo, rinviato post-MVP.
- Hardware Bluetooth (pulsante al casco): post-MVP.

### 4.2 Payload del SOS

Quando triggerato:

1. Raccoglie posizione GPS corrente (richiede permessi attivi).
2. Raccoglie metadata:
   - Nome + username dell'utente.
   - Timestamp.
   - URL mappa con coordinate (Google Maps deep link).
   - Ultimo update posizione (se non e' quello corrente: "posizione vecchia X minuti").
3. Costruisce messaggi:
   - **SMS** (via Twilio): "URGENTE: {nome} ha attivato SOS. Posizione: {maps_url}. Ricevuto: {timestamp}."
   - **Email** (via SendGrid): versione piu' lunga con piu' contesto.

### 4.3 Invio

`emergency_dispatcher` orchestrano:

1. Invia a ciascun SafetyContact: SMS se phone presente, email se email presente, entrambi se entrambi.
2. Ciascun invio e' un'Edge Function call (Twilio/SendGrid integrations vivono server-side per proteggere API keys).
3. Edge Function ritorna status per canale.

**Parallelismo:** tutti gli invii paralleli. Se 3 contatti con SMS + email = 6 invii paralleli.

### 4.4 `SafetyEvent` record

Prima dell'invio, insert `safety_events_local` con:

- `triggered_at`: now.
- `latitude`, `longitude`: posizione.
- `notified_contact_ids`: list di safety_contact_client_ids.
- `notification_channels_used`: inizialmente empty.
- `notification_statuses`: JSONB con per-canale-per-contatto status.

Dopo invio: update `notification_channels_used` + `notification_statuses` con esito per ciascun invio.

### 4.5 Feedback UI

Durante invio:

- UI mostra schermata "SOS INVIATO" + lista contatti con status per-channel (spinner, check, X).
- Al completamento: totale "3 contatti notificati via SMS + email".
- Se qualche invio fallisce: "ATTENZIONE: 1 contatto non raggiunto via SMS. Chiamalo direttamente."

**Principio:** mai silenzio. L'utente deve sapere cosa ha funzionato e cosa no.

### 4.6 Fallback offline

Se device e' offline quando viene triggerato SOS:

- SafetyEvent viene comunque scritto in drift.
- Dispatch fallisce, tutti gli invii in `failed`.
- UI mostra "OFFLINE. SOS SALVATO MA NON INVIATO. Chiama direttamente i contatti."
- Al ritorno online: sync orchestrator processa la SafetyEvent, **ma NON reinvia SMS/email automaticamente** (troppo tardi, potrebbero creare confusione). L'utente deve decidere se riemettere SOS manualmente.

**Decisione di design:** SafetyEvent e' record storico, non coda di invio. I messaggi sono azioni one-shot che non si ritentano automaticamente.

---

## Sezione 5 -- LiveSession

### 5.1 Concetto

Durante un giro, utente puo' attivare "condivisione live". Genera un link shareable (URL firmato) che permette a chi lo riceve di vedere la posizione aggiornata dell'utente in tempo reale, senza bisogno di account.

**Durata:** fino a stop manuale, o auto-close dopo 10 min GPS inattivita' leader (D.36), o dopo 24h failsafe.

### 5.2 Trigger

Da safety_screen: "Avvia condivisione live". Se tracking attivo: seed session con `activity_client_id` corrente. Altrimenti: standalone session.

### 5.3 Persistenza server

- Insert `live_sessions` server-side con `access_token` (UUID casuale).
- Link shareable: `https://app-moto.example.com/live/{session_id}?token={access_token}`.
- Tracking module continua a emettere punti; live_sharing_service subscribe ai punti e insert in `live_positions` server-side via Realtime Supabase (vedi D.22).
- Viewer (non autenticato) apre link -> pagina web o deep link app -> subscribe a Realtime per quella session_id.

### 5.4 Invio link

- Share sheet OS nativo: utente sceglie WhatsApp, iMessage, email, ecc.
- Non inviamo noi il link via Twilio/SendGrid automaticamente (differente da SOS).
- Opzionalmente in futuro: "Invia link automaticamente ai miei SafetyContacts".

### 5.5 Stop

Da UI: "Ferma condivisione". Chiude session, ultimo punto live invia flag "ended". Viewer vede "Sessione terminata".

### 5.6 Privacy

- Chi ha il link vede posizione. L'utente deve fidarsi del destinatario.
- Link include `access_token` random: non guessable.
- Alla chiusura session: token invalidato. Link vecchio non funziona piu'.

### 5.7 Watchdog: schema predisposto, feature condizionale (B.7)

La tabella `live_sessions` **include gia' le colonne necessarie** per il watchdog su `gpsInactivity` (vedi `02_database_schema.md` Sezione 3.10 e `09_safety/edge_cases.md` Sezione 3.5.bis):

- `notify_contacts_on_gps_inactivity` BOOLEAN default false
- `viewer_safety_contact_ids` UUID[] default empty
- `end_reason` TEXT (valori: `manual_stop | gps_inactivity | failsafe_24h`)

**Comportamento MVP se B.7 = "no" (default MVP minimale):**

- `notify_contacts_on_gps_inactivity` resta `false` su ogni sessione.
- Nessun SMS automatico.
- `end_reason` comunque viene valorizzato (utile per analytics + UX del viewer testo differenziato, gia' implementato).

**Comportamento se B.7 = "si" (MVP v1 o v1.1):**

- UI al momento di `startLiveSession(activityClientId, watchdog: true)` consente all'utente di selezionare SafetyContact come "viewer watchdog".
- Selezione salvata in `viewer_safety_contact_ids`.
- `notify_contacts_on_gps_inactivity = true`.
- Edge Function `notify-live-session-lost` (da implementare):
  - Ascoltata da pg_cron che chiude `gps_inactivity` session.
  - Per ogni `viewer_safety_contact_id`: invia SMS via Twilio con testo "{username} ha perso segnale GPS alle {endedAt}. Ultima posizione nota: {lastKnownLocation}. Verifica se sta bene."
- Lato owner: al riavvio app, se session chiusa per `gps_inactivity` e `notify_contacts_on_gps_inactivity = true`, UI mostra "I tuoi contatti sono stati avvisati che hai perso segnale. Vuoi rassicurarli?" -> pulsante "Invia OK" -> Edge Function invia SMS "Tutto OK, sono al sicuro".

**Schema zero-cost:** le 3 colonne esistono da v1. Attivazione feature = sviluppo UI + Edge Functions, senza migration.

---

## Sezione 6 -- Eventi emessi

- `SafetyEventTriggeredEvent(clientId, triggeredAt, lat, lon)`.
- `LiveSessionStartedEvent(clientId, accessToken, sharedUrl)`.
- `LiveSessionEndedEvent(clientId, reason)` dove reason: manualStop, gpsInactivity, failsafe24h.
- `SafetyContactAddedEvent / UpdatedEvent / RemovedEvent` (standard CRUD).

---

## Sezione 7 -- Eventi consumati

### 7.1 `RecordingStateChangedEvent` (dal tracking)

Se `newState = recording_active` e viene data la preferenza "live sharing automatico" (settings futuro): avvia LiveSession. MVP non include auto-start.

### 7.2 `AppLifecycleTerminatedEvent`

Se LiveSession attiva: continua (Mapbox continua a emettere punti). Alla riapertura app: riconnette Realtime.

---

## Sezione 8 -- Dipendenze

### Consumes:

- `shared/db/AppDatabase` per 3 tabelle.
- `shared/event_bus/EventBus`.
- `shared/auth/AuthService`.
- `shared/supabase/SupabaseClient` per realtime.
- `TrackingApi` (readonly) per leggere posizione GPS corrente per SOS.
- `ProfileApi` (readonly) per metadata utente nei messaggi SOS.

### Provides:

- `SafetyApi`.

### Edge Functions server-side (invocate dal client):

- `send-sos-sms` (Twilio).
- `send-sos-email` (SendGrid).
- `generate-live-session` (crea session + access_token).

---

## Sezione 9 -- Testing

### 9.1 Unit

- ContactsService CRUD + invariante "almeno 1 tra phone/email".
- SOS payload construction.
- Emergency dispatcher status aggregation.

### 9.2 Integration

- SOS end-to-end con mock Edge Functions.
- SafetyEvent record creato correttamente.
- LiveSession start/stop.

### 9.3 Campo

- SOS reale a un numero di prova (non farlo in produzione, avvisare ricevente).
- LiveSession e verifica link su browser.

---

## Sezione 10 -- Open items specifici safety

- **A.18 gia' coperta** (foto failed UI X vs Y) -- analogo per safety_events non serve (record permanente, non retriable).
- **Post-MVP:** trigger SOS via hardware bluetooth.
- **Post-MVP B.6:** visibility SafetyEvent per contact loggati con credenziali proprie.

---

**Fine 09_safety/L0_architecture.md**
