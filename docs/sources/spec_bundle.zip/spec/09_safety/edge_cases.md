# 09 / Safety -- Edge Cases

**Scopo:** casi limite modulo safety.

**Riferimenti:** `L0_architecture.md`, `L05_interfaces.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- SafetyContacts

### 1.1 Aggiunta 6a contatto

**Atteso:** `MaxContactsReachedError`. UI: "Hai raggiunto il massimo di 5 contatti. Rimuovine uno per aggiungerne un altro."

### 1.2 Contact con phone e email null

**Atteso:** `ValidationError('contact', 'Inserisci almeno un numero o email')`.

### 1.3 Phone non in formato E.164

**Scenario:** utente inserisce "3281234567" (formato italiano senza prefisso).

**Atteso:**
- Client normalizza: se inizia con "3" e ha 10 cifre -> prepend "+39".
- Se inizia con "+" o "00" -> accetta as-is.
- Se non ambiguo: errore `ValidationError('phone', 'Formato non riconosciuto. Usa formato internazionale (+39...)')`.

### 1.4 Email non valido

**Atteso:** `ValidationError('email', 'Email non valida')`. Check regex base.

### 1.5 Telefono duplicato tra contatti

**Atteso:** consentito. Utente puo' legittimamente avere due contatti che chiamano lo stesso telefono familiare.

### 1.6 Rimozione contatto durante SOS in corso

**Scenario:** SOS triggerato, mentre messaggi in invio utente apre settings e rimuove un contatto.

**Atteso:**
- Edge Function ha gia' la lista contact_ids al momento del trigger (snapshot).
- Rimozione locale del contatto non annulla invii in corso.
- `SafetyEvent.notification_statuses` referenzia il contact_id rimosso -- lecito, il record e' storico.

---

## Sezione 2 -- SOS trigger

### 2.1 Zero SafetyContact configurati

**Atteso:** `NoContactsConfiguredError`. UI: dialog "Non hai contatti di emergenza configurati. Aggiungi almeno un contatto nelle impostazioni."

### 2.2 GPS non disponibile

**Scenario:** permessi location off, OS location services off, oppure primo fix ancora in corso.

**Atteso:** `LocationUnavailableError`. UI: "Posizione GPS non disponibile. Attivala o attendi il fix."

**Alternative pragmatica (non MVP):** inviare SOS senza posizione, con disclaimer "posizione non disponibile" nel messaggio.

### 2.2.bis GPS disponibile ma accuracy scadente

**Scenario:** fix GPS presente ma `accuracy_m` > 50 (canyon urbano, zona fitta di edifici, copertura parziale).

**Principio:** SOS deve partire. Una posizione approssimativa e' sempre meglio di nessuna posizione in un'emergenza. Ma il messaggio ai contatti deve riflettere l'incertezza.

**Atteso:**

- `triggerSos()` procede anche con accuracy scadente. NON errore.
- Il messaggio SMS include disclaimer accuracy:
  - Se `accuracy_m <= 50`: "Posizione: {maps_url}"
  - Se `50 < accuracy_m <= 200`: "Posizione approssimativa (entro ~{round(accuracy_m)}m): {maps_url}"
  - Se `accuracy_m > 200`: "Posizione molto approssimativa (entro ~{round(accuracy_m)}m, potrebbe essere impreciso): {maps_url}"
- Il messaggio email include stesso disclaimer + nota "Se il destinatario non riesce a localizzare, chiamare direttamente l'utente."
- `SafetyEvent.notification_statuses[].context` include `accuracy_m_at_trigger` per log/debug.

**UI post-trigger:** schermata "SOS INVIATO" mostra: "Posizione inviata con precisione ~{accuracy_m}m". Se > 100m: indicatore ambra "precisione limitata".

### 2.3 Offline

**Atteso:**
- SafetyEvent record creato in drift con tutti gli status `pending`.
- `OfflineSosError(safetyEventClientId)` ritornato.
- UI critica: "OFFLINE. L'SOS NON E' STATO INVIATO. Chiama direttamente i tuoi contatti."
- La SafetyEvent resta visibile nella history come "pending".

### 2.4 Parziale: Twilio OK, SendGrid fail

**Scenario:** Twilio SMS inviati, SendGrid ha outage.

**Atteso:**
- `notification_statuses` mostra SMS `sent`, email `failed`.
- `PartialDispatchError(successCount=3, failureCount=2)` ritornato.
- UI: schermata "SOS INVIATO CON PROBLEMI" con lista per contatto per canale, + suggerimento "Alcuni canali non hanno funzionato. Chiama direttamente."

### 2.5 Utente tappa "Annulla" durante countdown 5s

**Atteso:**
- SafetyEvent NON creato.
- Nessun evento bus emesso.
- UI torna a safety_screen.

### 2.6 Utente ritappa SOS subito dopo uno invio

**Scenario:** primo SOS inviato 10 secondi fa. Utente in panico tappa di nuovo.

**Atteso:**
- Consentito. Nuovo SafetyEvent record, nuova chiamata Edge Functions.
- Contatti ricevono un secondo messaggio. Ridondanza accettabile in emergenza.
- Nessun rate limit client-side MVP.

### 2.7 Twilio 429 (rate limited)

**Scenario:** troppi SOS simultanei da utenti diversi -> Twilio rate limit.

**Atteso:**
- Edge Function riceve 429 da Twilio.
- Ritorna al client un retry-after.
- Client marca `NotificationStatus = failed`, non re-enqueue auto.
- UI informa "alcune notifiche saranno riprovate fra X secondi".
- Retry manuale dall'UI (pulsante "Reinvia").

### 2.8 Numero telefono non valido Twilio-side

**Scenario:** +39 numero inesistente.

**Atteso:** Twilio ritorna 400 con error code. Client marca `failed` con error_code specifico. UI mostra: "SMS a {nome}: numero non valido. Verifica e riprova."

---

## Sezione 3 -- LiveSession

### 3.1 Start mentre session gia' attiva

**Atteso:** `LiveSessionAlreadyActiveError(activeClientId)`. UI: "Hai gia' una sessione live attiva. Fermala prima di iniziarne un'altra."

### 3.2 Start senza connessione

**Atteso:** session non puo' essere creata (serve server per URL shareable). Errore `InternalFailureError('offline')`. UI: "Serve connessione per avviare la condivisione."

### 3.3 GPS lost durante live session

**Atteso:**
- Nessun punto nuovo in `live_positions`.
- Dopo 10 minuti silenzio: server pg_cron auto-close (D.36).
- Viewer vede "In attesa di posizione..." poi "Sessione terminata".
- `LiveSessionEndedEvent(reason: gpsInactivity)` ricevuto dal client al prossimo contatto col server.

### 3.4 App killata durante live session

**Scenario:** OS killa app mentre live session attiva.

**Atteso:**
- Senza app in esecuzione, nessun nuovo punto viene inviato.
- Stesso trattamento di GPS lost: dopo 10 min silenzio, server auto-close.
- Al riavvio app: state `ended` gia' segnato server-side. UI non vede session attiva.

### 3.5 24h failsafe

**Scenario:** utente dimentica session attiva per 24h (bug app client che non ferma, o altro).

**Atteso:** server pg_cron force-close dopo 24h dall'inizio. `LiveSessionEndedEvent(reason: failsafe24h)`.

### 3.5.bis Utente svanisce durante LiveSession (caso critico safety)

**Scenario:** utente in moto con LiveSession attiva. A un certo punto il GPS smette di aggiornarsi. Potrebbe essere:

- (a) Tunnel o zona senza copertura -- **benigno**, torna da solo.
- (b) App killata dall'OS -- **ambiguo**, utente sta bene ma app e' giu'.
- (c) Device spento / distrutto -- **potenzialmente grave**, l'utente potrebbe essere in emergenza.

**Problema UX:** il viewer del link vede "In attesa di posizione..." poi dopo 10 min "Sessione terminata" (caso 3.3). Non ha modo di distinguere (a) / (b) / (c). Puo' presumere erroneamente che l'utente abbia semplicemente chiuso la condivisione, quando invece potrebbe essere in pericolo.

**Principio:** **nessuna falsa sicurezza**. Il viewer deve capire che "sessione terminata" non significa "utente al sicuro".

**Atteso MVP:**

- Testo della terminazione lato viewer differenziato per reason:
  - `reason: manualStop` -> "L'utente ha terminato la condivisione. Ultimo aggiornamento: {endedAt}."
  - `reason: gpsInactivity` -> "**Segnale perso.** L'utente potrebbe essere in area senza copertura, ma potrebbe anche essere in difficolta'. Ultimo aggiornamento: {endedAt}. Ultima posizione: {maps_url}. Se non torna online entro breve, contatta direttamente l'utente o le autorita'."
  - `reason: failsafe24h` -> "Sessione automaticamente chiusa dopo 24 ore. Se non hai piu' avuto contatti, contatta l'utente."
- UI del viewer include sempre numero di telefono dell'utente (se condiviso via PublicProfile) o CTA "Contatta {username}".

**Atteso MVP, lato owner app:**

- Se la live session si chiude per `gpsInactivity` e la app torna online, la UI mostra subito: "La tua sessione di condivisione si e' interrotta per segnale perso. I contatti che stavano seguendo potrebbero essere preoccupati. Vuoi avvisarli che stai bene?"
- Pulsante "Invia messaggio di OK" -> invia SMS/push di conferma (via Edge Function separata) ai contacts-viewer registrati (se registrati -- feature base MVP).

**Post-MVP (B.6 espanso):** "watchdog" attivo lato contatti. Se il viewer e' un SafetyContact registrato e la session chiude per `gpsInactivity`, un'Edge Function puo' inviare SMS automatico al contatto con "L'utente X ha perso segnale GPS alle ore Y, ultima posizione Z. Non siamo sicuri dello stato. Contattalo."

**Non MVP ma importante per roadmap:** questo e' il gap che separa "condivisione live casual" da "safety feature affidabile". La decisione se includerlo in MVP o v1.1 e' di prodotto (vedi sezione 9 Open items).

### 3.6 Viewer apre link dopo session end

**Atteso:** pagina/app mostra "Sessione terminata. Ultimo aggiornamento: {endedAt}. Percorso registrato: {bbox}." Eventualmente polyline statica se utente ha autorizzato visibility post-mortem (non MVP).

### 3.7 Condivisione link via share sheet fallisce

**Atteso:** OS notifica errore. Session resta attiva lato server, ma nessun viewer conosce il link. Utente puo' ricopiare link da UI live_share_screen.

### 3.8 Token leak

**Scenario:** utente ha condiviso link in gruppo WhatsApp "sbagliato".

**Mitigazione:** utente puo' fermare session. Token invalidato. I destinatari sbagliati non hanno piu' accesso.

**Non MVP:** rigenerazione token senza stop session.

---

## Sezione 4 -- Integrazione

### 4.1 Tracking attivo + SOS

**Atteso:**
- SOS usa posizione corrente (ultimo fix da tracking, se disponibile, o geolocator ad-hoc).
- SafetyEvent include `activity_client_id` del tracking in corso.
- Non interferisce col tracking.

### 4.2 Tracking attivo + LiveSession

**Atteso:**
- LiveSession subscribe agli stessi punti GPS del tracking (via event bus interno oppure callback).
- Doppio write: tracking in `track_point_buffer`, safety in `live_positions` server.
- Nessuna duplicazione di GPS fetch (un solo stream geolocator).

### 4.3 SOS + LiveSession simultanei

**Atteso:** consentiti indipendentemente. Semantica ortogonale.

---

## Sezione 5 -- Edge Functions server-side

### 5.1 Twilio webhook fail

**Scenario:** Twilio accetta richiesta ma il webhook di status callback fallisce.

**Atteso:**
- Status iniziale `sent` (accettato da Twilio).
- Se mai arriva update `failed` via webhook tardivo: update `NotificationStatus`. UI reagisce mostrando nuovo errore.
- Webhook non arriva mai: status resta `sent`. Accettabile: Twilio accettato, presunto OK.

### 5.2 Edge Function timeout

**Scenario:** Edge Function impiega > 10s (limite Supabase).

**Atteso:** client riceve 504 / timeout. Marca `failed`. UI: "Invio non confermato. Chiama direttamente per sicurezza."

### 5.3 Account Supabase sospeso / fuori quota

**Atteso:** Edge Function ritorna error. Nessun canale alternativo. UI critica: "Sistema notifiche non disponibile. Contatta direttamente."

---

## Sezione 6 -- Checklist QA

- [ ] Aggiungi / modifica / rimuovi contatto.
- [ ] Max 5 contatti.
- [ ] Almeno uno tra phone/email.
- [ ] SOS con 0 contatti -> errore chiaro.
- [ ] SOS con permessi GPS off -> errore chiaro.
- [ ] SOS offline -> SafetyEvent persistito + UI critica.
- [ ] SOS OK -> tutti i canali sent.
- [ ] SOS partial -> UI lista per canale.
- [ ] Start live session + share link.
- [ ] Live session auto-close dopo GPS inactivity.
- [ ] Live session failsafe 24h (simulato).
- [ ] Viewer aperto dopo end -> "Sessione terminata".
- [ ] Rimozione contatto durante SOS in corso: record storico coerente.

---

## Sezione 7 -- Open items specifici safety

- **Post-MVP:** trigger SOS hardware (bluetooth button).
- **Post-MVP B.6:** contacts con login dedicato per vedere SafetyEvent.
- **Post-MVP:** rate limiting client-side per SOS doppio (es. 1 ogni 30s).
- **Open UX:** nell'SMS SOS includere durata ride o solo posizione? Default solo posizione per brevita'.
- **Open di prodotto (alta priorita' per roadmap):** **watchdog su LiveSession gpsInactivity**. Viewer di una live session e' un SafetyContact registrato nell'app: se la session chiude per inattivita' GPS, sistema invia automaticamente SMS di alert al contact. Trasforma LiveSession da "condivisione casual" a "safety feature affidabile". Decisione: MVP o MVP v1.1. Vedi Sezione 3.5.bis.

---

**Fine 09_safety/edge_cases.md**
