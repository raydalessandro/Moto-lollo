# 07 / Community -- Edge Cases

**Scopo:** casi limite community.

**Riferimenti:** `L0_architecture.md`, `L05_interfaces.md`, matrice RLS `00_overview.md` Sezione 6.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Publishing

### 1.1 Publish di Activity con `source_client_id` soft-deleted

**Scenario:** utente ha cancellato Activity. Tenta publish tramite deep-link o vecchio stato UI.

**Atteso:** `UnpublishedSourceError`. Service verifica `activity.deletedAt == null`.

### 1.2 Publish duplicato della stessa sorgente

**Scenario:** utente pubblica stessa Activity due volte.

**Atteso:** consentito. `PublishedRoute.clientId` e' diverso per ogni publish. L'utente puo' avere la stessa Activity pubblicata con titoli/descrizioni diverse (edit vs re-publish). Se vuole una sola, prima unpublish -> poi publish.

**Alternative:** UI mostra warning "Hai gia' pubblicato questa Activity. Modificare invece?". Non bloccante.

### 1.3 Snapshot diverge dalla sorgente

**Scenario:** utente publica Activity, poi modifica il titolo della Activity. Il PublishedRoute ha ancora il vecchio titolo (snapshot, D.32).

**Atteso:** comportamento by design. UI route_detail mostra link "Aggiorna da sorgente" se Activity source presente non soft-deleted e `source.updatedAt > publishedRoute.updatedAt`. Click -> `resyncFromSource(clientId)`.

### 1.4 Sorgente hard-deleted dal server (admin)

**Scenario:** admin cancella Activity dal server. Trigger `null_published_source_on_parent_delete` (D.19) azzera `source_client_id`.

**Atteso:**
- Client al prossimo fetch vede `source_client_id = null`.
- UI route_detail: nasconde "Aggiorna da sorgente" / CTA "Vai alla Activity".
- PublishedRoute resta consultabile (snapshot completo).

### 1.5 Utente bannato tenta publish

**Atteso:** `BannedError`. Verifica server-side via RLS policy (admin ha flaggato profile). Lato client, `profile.role` o `profile.feature_flags.banned` riflette.

---

## Sezione 2 -- Feed

### 2.1 Feed personale vuoto (utente segue zero)

**Atteso:** lista vuota. UI mostra CTA "Segui qualcuno per vedere contenuti qui" + link a feed pubblico.

### 2.2 Fetch feed senza connessione

**Contesto critico per app moto:** i giri in moto avvengono spesso in zone a copertura variabile (valli, tunnel, autostrada con celle deboli). Un feed che dice solo "Riprova" quando l'utente cerca di vedere il proprio profilo o un commento e' frustrante per il segmento target.

**Policy MVP "last-seen cache":**

L'ultima GET feed riuscita viene tenuta in memoria + persistenza leggera (`shared_preferences` con TTL 7 giorni). Quando l'utente apre il feed offline:

- **Mai seen prima**: stato empty con CTA "Serve connessione per vedere il feed. Torna quando hai rete."
- **Seen almeno una volta**: mostra lo snapshot cache con **banner in alto**: "Sei offline. Feed aggiornato alle {lastSeenAt}. Torna online per aggiornare."
  - Pull-to-refresh disabilitato con tooltip "Serve connessione".
  - Tap su item = apre detail da cache (se contenuto presente), altrimenti toast "Serve connessione per aprire".
  - Azioni "like" e "commento" vanno in `sync_queue_local` con optimistic update (coerente con Sezione 3.3 e 4 di questo doc).

**Fallback esteso:** lo screen "own content" (mie activity, miei PublishedRoute, mie moto) e' **sempre disponibile offline** (letto da drift). Banner globale "Sei offline" rimanda esplicitamente a "Vai ai miei contenuti" quando il feed e' inaccessibile.

**Error code:** `NetworkRequiredError` ritornato da `getPersonalFeed` solo se cache e' vuota o scaduta. Se cache disponibile: `Ok(cachedList)` con metadata `isFromCache: true, cachedAt: DateTime`.

**Cosa NON cachiamo offline MVP:**

- Profili altri utenti (troppo storage, troppa complessita').
- Commenti di PublishedRoute non proprie.
- Feed pubblico globale.

La cache implicita copre solo il **personal feed** e il **own content** -- il 80/20 dell'uso tipico.

**Decisione rispetto a B.3:** questa e' la variante "(c) via di mezzo" della proposta originaria B.3, resa concreta. Puo' essere archiviata o mantenuta a B.3 secondo preferenza.

### 2.3 Visibility mix nel feed personale

**Scenario:** utente segue Alice (public) e Bob (friends_only). Bob accetta me come follower.

**Atteso:** feed mostra sia Alice (public) sia Bob (friends_only visibile perche' accettato).

**Implementazione:** RLS policy su `published_routes` controlla:
- `visibility = 'public'` -> sempre visibile.
- `visibility = 'friends_only'` -> visibile se `is_following(auth.uid(), owner_id) AND is_following(owner_id, auth.uid())` (mutuo).
- `visibility = 'unlisted'` -> solo link diretto con `clientId`, non appare in feed.

### 2.4 Paginazione: ultima pagina vuota

**Scenario:** feed ha esattamente 40 item. Primi 20 + secondi 20. Terza richiesta ritorna vuoto.

**Atteso:** `Ok([])`. UI interpreta come "fine feed". Nessun errore.

### 2.5 Cursor-based: creato durante paginazione

**Scenario:** utente scrolla verso il basso. Un altro utente pubblica nel frattempo.

**Atteso:**
- La nuova PublishedRoute ha `createdAt > cursor`. Non appare nella paginazione in corso.
- L'utente la vedra' al prossimo refresh pull-to-refresh dall'alto.

**Accettabile.** Alternativa (real-time feed update) e' post-MVP.

---

## Sezione 3 -- Like

### 3.1 Double-tap rapido

**Atteso:**
- Service con mutex per (userId, routeId).
- Prima invocazione: add. Seconda: nota stato cambiato, toglie.
- Net effect: nessun like (doppio tap = toggle off).

### 3.2 Like su route soft-deleted

**Scenario:** utente ha la route in cache, la route e' stata unpublishata.

**Atteso:** API call server fallisce con 403 (RLS non consente su soft-deleted). Client riceve error, rollback optimistic UI, mostra "Questa route non e' piu' disponibile".

### 3.3 Like offline poi sync

**Atteso:**
- Optimistic update UI.
- Item in `sync_queue_local` con owner_id corrente.
- Al ritorno online, sync processa. Se server accepta: confermato. Se 403 (nel frattempo route unpublished): item va `failed`, UI mostra rollback.

### 3.4 Like da utente bannato

**Atteso:** server RLS rifiuta. Client fa rollback dell'optimistic.

---

## Sezione 4 -- Commenti

### 4.1 Commento vuoto / solo whitespace

**Atteso:** `ValidationError('text', 'Commento non puo' essere vuoto')`.

### 4.2 Commento lungo > 1000 caratteri

**Atteso:** `ValidationError('text', 'Massimo 1000 caratteri')`.

### 4.3 Cancellazione commento altrui

**Scenario:** utente A tenta cancellare commento di utente B.

**Atteso:**
- Regole (da B.1): proprietario commento OR proprietario della route possono cancellare.
- Se A non e' nessuno dei due: `NotOwnerError`.
- Check client + RLS server.

### 4.4 Cancellazione di proprio commento

**Atteso:** soft delete (`deleted_at = now()`). Sync enqueue UPDATE.

### 4.5 Stream comments in real-time

**Scenario:** utente sta vedendo route detail, qualcun altro commenta.

**Atteso MVP:**
- `watchComments` fa pull periodico (10s) oppure on-focus quando UI entra in foreground.
- Supabase Realtime non incluso in MVP per comments (coerente con D.6: realtime solo live tracking).

**Limite accettato:** delay di 10 secondi nel vedere commenti nuovi. UX acceptable per MVP.

---

## Sezione 5 -- Follow

### 5.1 Self-follow

**Atteso:** `SelfFollowError`. CHECK constraint DB + verifica client.

### 5.2 Double follow

**Scenario:** utente tap "Segui" due volte in sequenza.

**Atteso:**
- Mutex lato service. Seconda invocazione vede gia' follow in DB -> `AlreadyFollowingError` (o ritorno `Ok(())` silent, idempotente).
- UI non mostra errore visibile, il bottone e' gia' "Seguendo".

### 5.3 Unfollow di utente non seguito

**Atteso:** no-op silent, `Ok(())`. Non errore.

### 5.4 Follow di utente bannato

**Atteso:** consentito? Discussione prodotto. Per ora: si', l'utente bannato resta follow-able (ma non postera' contenuti visibili).

### 5.5 Follow di utente cancellato (soft-deleted)

**Atteso:** profilo anonimizzato visibile (vedi D.8 anonymize_profile_on_soft_delete). UI mostra "Utente eliminato", nessun bottone Follow.

---

## Sezione 6 -- RLS edge coperti da B.1

I seguenti scenari sono formalmente in B.1 aperto, con proposte gia' allineate:

### 6.1 Commenti di autore eliminato

- Proposta B.1: owner della route puo' cancellarli.
- Visualizzazione: UI mostra "Utente eliminato" al posto del nome.

### 6.2 Like di liker eliminato

- Proposta B.1: conteggio resta, nome "Utente eliminato" nella lista likers.

### 6.3 Activity di utente bannato

- Proposta B.1: auto-unpublish di tutte le PublishedRoute. Trigger server all'atto del ban.

---

## Sezione 7 -- Report

### 7.1 Report ripetuto della stessa entity

**Atteso:**
- Service verifica se utente ha gia' segnalato lo stesso (entityKind, entityClientId).
- Se si': ritorna silent `Ok(())` (no duplicate report).

### 7.2 Self-report

**Atteso:** `ValidationError('entity', 'Non puoi segnalare te stesso')`.

---

## Sezione 8 -- Storage / performance

### 8.1 Route con media associati ai commenti

**Non MVP.** Commenti sono solo testo. Post-MVP opzionale.

### 8.2 Feed con migliaia di like

**Performance:** `like_count` e' colonna cache (vedi `L0_architecture.md` Sezione 10). O(1) leggerlo dal feed, non serve JOIN.

### 8.3 Utente con migliaia di follower

**Performance:** query `getFollowers` paginata. Limit di 50 per pagina, cursor-based.

---

## Sezione 9 -- Checklist QA

- [ ] Publish da Activity + verifica snapshot.
- [ ] Publish da PlannedRoute.
- [ ] Unpublish soft delete.
- [ ] Resync da sorgente modificata.
- [ ] Feed personale con follow.
- [ ] Feed pubblico con filtri (tag, area geo, distanza).
- [ ] Feed pagination corretta (cursor).
- [ ] Like toggle + counter corretto.
- [ ] Commento + visualizza + cancella.
- [ ] Cancellazione commento altrui -> NotOwnerError.
- [ ] Cancellazione commento da owner route -> OK.
- [ ] Follow + unfollow toggle.
- [ ] Self-follow rifiutato.
- [ ] Offline: like e commento in pending.
- [ ] Utente eliminato visibile come "Utente eliminato" nei commenti/like.
- [ ] Utente bannato: PublishedRoute invisibili.
- [ ] Report base.

---

## Sezione 10 -- Open items specifici community

- Formalizzazione B.1 con decisioni chiuse.
- Definizione tabella `reports` per moderazione (parte di B.2 scope).
- Aggiornamento retroattivo `02_database_schema.md` Sezione 3.6: aggiungere `like_count INTEGER NOT NULL DEFAULT 0` + `comment_count INTEGER NOT NULL DEFAULT 0` a `published_routes` + trigger di aggiornamento.

---

**Fine 07_community/edge_cases.md**
