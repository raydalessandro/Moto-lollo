# 07 / Community -- L0.5 Interfaces

**Scopo:** firme Dart delle API pubbliche del modulo community.

**Riferimenti:**

- Architettura: `L0_architecture.md`.
- Convenzioni generali: `04_tracking/L05_interfaces.md` Sezione 1.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Types di dominio

### 1.1 `PublishedRouteSummary`

Versione leggera per feed.

```dart
@freezed
class PublishedRouteSummary with _$PublishedRouteSummary {
  const factory PublishedRouteSummary({
    required String clientId,
    required String ownerId,
    required String ownerUsername,
    required String? ownerAvatarPathThumb,
    required String title,
    required String? description,
    required List<String> tags,
    required double distanceKm,
    required Duration duration,
    required String polylineEncoded,
    required DateTime createdAt,
    required int likeCount,
    required int commentCount,
    required bool currentUserLiked,
    required RouteVisibility visibility,
    required PublishedRouteSourceType sourceType,
  }) = _PublishedRouteSummary;
}

enum RouteVisibility { public, friendsOnly, unlisted }
enum PublishedRouteSourceType { activity, plannedRoute }
```

### 1.2 `PublishedRouteDetail`

Versione completa per detail screen: aggiunge `trackPointsData` (lazy loadable), `bbox`, `sourceClientId`.

### 1.3 `RouteComment`

```dart
@freezed
class RouteComment with _$RouteComment {
  const factory RouteComment({
    required String clientId,
    required String publishedRouteClientId,
    required String authorId,
    required String authorUsername,
    required String? authorAvatarPathThumb,
    required String text,
    required DateTime createdAt,
    required DateTime? deletedAt,
  }) = _RouteComment;
}
```

### 1.4 `ProfileSummary`

```dart
@freezed
class ProfileSummary with _$ProfileSummary {
  const factory ProfileSummary({
    required String userId,
    required String username,
    required String displayName,
    required String? avatarStoragePathThumb,
    required int followerCount,
    required int followingCount,
    required int publishedRouteCount,
  }) = _ProfileSummary;
}
```

### 1.5 `PublishOptions`

```dart
@freezed
class PublishOptions with _$PublishOptions {
  const factory PublishOptions({
    required String title,
    String? description,
    @Default([]) List<String> tags,
    @Default(RouteVisibility.public) RouteVisibility visibility,
  }) = _PublishOptions;
}
```

### 1.6 `FeedFilters`

```dart
@freezed
class FeedFilters with _$FeedFilters {
  const factory FeedFilters({
    List<String>? tags,              // filtra per tag
    double? minDistanceKm,
    double? maxDistanceKm,
    BoundingBox? geoFilter,          // feed in area geografica
    DateTime? since,                 // ultime N giorni
    int limit,
    String? cursorCreatedAt,         // per paginazione
  }) = _FeedFilters;
}

@freezed
class BoundingBox with _$BoundingBox {
  const factory BoundingBox({
    required double minLat,
    required double minLon,
    required double maxLat,
    required double maxLon,
  }) = _BoundingBox;
}
```

### 1.7 `CommunityError`

```dart
sealed class CommunityError {
  const CommunityError();
}

final class ValidationError extends CommunityError {
  final String field;
  final String message;
  const ValidationError(this.field, this.message);
}

final class NotFoundError extends CommunityError {
  final String entityKind;
  final String clientId;
  const NotFoundError(this.entityKind, this.clientId);
}

final class NotOwnerError extends CommunityError {
  final String entityClientId;
  const NotOwnerError(this.entityClientId);
}

final class AlreadyLikedError extends CommunityError {
  const AlreadyLikedError();
}

final class AlreadyFollowingError extends CommunityError {
  const AlreadyFollowingError();
}

final class SelfFollowError extends CommunityError {
  // Tentativo di follow di se stessi (CHECK constraint)
  const SelfFollowError();
}

final class UnpublishedSourceError extends CommunityError {
  // Tentativo di publish di una Activity / PlannedRoute soft-deleted
  const UnpublishedSourceError();
}

final class BannedError extends CommunityError {
  // Utente bannato, non puo' pubblicare/commentare
  const BannedError();
}

final class NetworkRequiredError extends CommunityError {
  // Operazione che richiede online (feed, follow) fallita offline
  const NetworkRequiredError();
}

final class InternalFailureError extends CommunityError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

---

## Sezione 2 -- `CommunityApi` (contratto unificato)

```dart
abstract class CommunityApi {
  // ========== PUBLISHING ==========

  Future<Result<String, CommunityError>> publishFromActivity(
    String activityClientId,
    PublishOptions options,
  );

  Future<Result<String, CommunityError>> publishFromPlannedRoute(
    String plannedRouteClientId,
    PublishOptions options,
  );

  Future<Result<void, CommunityError>> updatePublishedRoute(
    String clientId, {
    String? title,
    String? description,
    List<String>? tags,
    RouteVisibility? visibility,
  });

  Future<Result<void, CommunityError>> unpublishRoute(String clientId);

  Future<Result<void, CommunityError>> resyncFromSource(String clientId);

  Future<PublishedRouteDetail?> getPublishedRoute(String clientId);

  // ========== FEED ==========

  /// Feed personale (utenti seguiti).
  /// Richiede connessione. Supporta paginazione via `cursorCreatedAt` nei FeedFilters.
  Future<Result<List<PublishedRouteSummary>, CommunityError>> getPersonalFeed(
    FeedFilters filters,
  );

  /// Feed pubblico globale filtrabile.
  Future<Result<List<PublishedRouteSummary>, CommunityError>> getPublicFeed(
    FeedFilters filters,
  );

  /// Publications di un profilo specifico.
  Future<Result<List<PublishedRouteSummary>, CommunityError>> getProfileRoutes(
    String userId,
    FeedFilters filters,
  );

  /// Profile + stats.
  Future<Result<ProfileSummary, CommunityError>> getProfile(String userId);

  // ========== COMMENTI ==========

  Future<Result<String, CommunityError>> addComment(
    String publishedRouteClientId,
    String text,
  );

  Future<Result<void, CommunityError>> deleteComment(String commentClientId);

  /// Stream commenti in tempo reale per una route.
  /// Include fetch iniziale dal server + realtime Supabase listen (optional MVP).
  Stream<List<RouteComment>> watchComments(String publishedRouteClientId);

  // ========== LIKE ==========

  /// Toggle like. Ritorna true se ha aggiunto, false se ha tolto.
  Future<Result<bool, CommunityError>> toggleLike(String publishedRouteClientId);

  Future<bool> hasLiked(String publishedRouteClientId);

  Future<int> getLikeCount(String publishedRouteClientId);

  Future<Result<List<ProfileSummary>, CommunityError>> getLikers(
    String publishedRouteClientId,
  );

  // ========== FOLLOW ==========

  Future<Result<void, CommunityError>> follow(String targetUserId);

  Future<Result<void, CommunityError>> unfollow(String targetUserId);

  Future<bool> isFollowing(String targetUserId);

  Future<Result<List<ProfileSummary>, CommunityError>> getFollowers(
    String userId,
  );

  Future<Result<List<ProfileSummary>, CommunityError>> getFollowing(
    String userId,
  );

  // ========== MODERATION / REPORT ==========

  /// Segnala contenuto. Notifica admin.
  Future<Result<void, CommunityError>> reportContent({
    required ReportableEntityKind kind,
    required String entityClientId,
    required ReportReason reason,
    String? notes,
  });
}

enum ReportableEntityKind { publishedRoute, routeComment, profile }
enum ReportReason { spam, inappropriate, harassment, other }
```

---

## Sezione 3 -- Eventi emessi

### 3.1 Publishing

```dart
@freezed
class RoutePublishedEvent with _$RoutePublishedEvent {
  const factory RoutePublishedEvent({
    required String clientId,
    required String ownerId,
    required PublishedRouteSourceType sourceType,
    required String? sourceClientId,
    required RouteVisibility visibility,
    required DateTime createdAt,
  }) = _RoutePublishedEvent;
}

@freezed
class RouteUnpublishedEvent with _$RouteUnpublishedEvent {
  const factory RouteUnpublishedEvent({
    required String clientId,
    required String ownerId,
    required DateTime unpublishedAt,
  }) = _RouteUnpublishedEvent;
}

@freezed
class PublishedRouteUpdatedEvent with _$PublishedRouteUpdatedEvent {
  const factory PublishedRouteUpdatedEvent({
    required String clientId,
    required String ownerId,
    required Set<String> changedFields,
    required DateTime updatedAt,
  }) = _PublishedRouteUpdatedEvent;
}
```

### 3.2 Interazioni

```dart
@freezed
class CommentAddedEvent with _$CommentAddedEvent {
  const factory CommentAddedEvent({
    required String commentClientId,
    required String publishedRouteClientId,
    required String authorId,
    required DateTime createdAt,
  }) = _CommentAddedEvent;
}

@freezed
class CommentDeletedEvent with _$CommentDeletedEvent {
  const factory CommentDeletedEvent({
    required String commentClientId,
    required String publishedRouteClientId,
    required String deletedBy,
  }) = _CommentDeletedEvent;
}

@freezed
class LikeAddedEvent with _$LikeAddedEvent {
  const factory LikeAddedEvent({
    required String likeClientId,
    required String publishedRouteClientId,
    required String likerId,
  }) = _LikeAddedEvent;
}

@freezed
class LikeRemovedEvent with _$LikeRemovedEvent {
  const factory LikeRemovedEvent({
    required String publishedRouteClientId,
    required String likerId,
  }) = _LikeRemovedEvent;
}
```

### 3.3 Follow

```dart
@freezed
class UserFollowedEvent with _$UserFollowedEvent {
  const factory UserFollowedEvent({
    required String followerId,
    required String followedId,
    required DateTime occurredAt,
  }) = _UserFollowedEvent;
}

@freezed
class UserUnfollowedEvent with _$UserUnfollowedEvent {
  const factory UserUnfollowedEvent({
    required String followerId,
    required String followedId,
  }) = _UserUnfollowedEvent;
}
```

---

## Sezione 4 -- `CommunityModule` (manifest)

```dart
class CommunityModule extends AppModule {
  @override
  String get name => 'community';

  @override
  List<String> get dependsOn => [
    'shared.db',
    'shared.event_bus',
    'shared.auth',
    'shared.supabase',
  ];

  @override
  List<Type> get provides => [CommunityApi];

  @override
  List<Type> get consumes => [MotorcycleApi]; // per ProfileScreen

  @override
  void register(ModuleRegistry r) {
    // instanziazione dei 4 service interni + aggregazione in CommunityApiImpl
    // ...
  }
}
```

---

## Sezione 5 -- Thread model

Tutte le operazioni sono su main isolate.

---

## Sezione 6 -- Test contracts

Vedi `L0_architecture.md` Sezione 11. Tutti i metodi `Result` richiedono test di happy path + ogni `CommunityError` applicabile.

---

**Fine 07_community/L05_interfaces.md**
