# 07 / Community -- L0 Architecture

**Scopo:** social layer dell'app. Pubblicazione di activity e percorsi, feed di scoperta, commenti, like, relazioni di follow tra utenti.

**Cosa NON e' qui:**

- Registrazione activity (tracking, modulo 04).
- Pianificazione percorsi (planning, modulo 10).
- Schema DB entita' sociali (in `02_database_schema.md` Sezioni 3.6-3.10).

**Riferimenti:**

- Entita' PublishedRoute, RouteComment, RouteLike, FollowRelationship: `01_data_model.md` Sezioni 8-11.
- RLS baseline: `00_overview.md` Sezione 6.
- Pattern snapshot: D.32.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Permettere agli utenti di condividere i propri giri e percorsi pianificati, scoprire contenuti di altri, interagire con like e commenti, seguire motociclisti interessanti. Il modulo e' **owner** di PublishedRoute, RouteComment, RouteLike, FollowRelationship.

**Principio di semplicita' MVP:** il feed e' online-first (vedi B.3). Caching locale minimale. Tutti i contenuti social richiedono connessione.

---

## Sezione 2 -- Sotto-moduli interni

Il community e' logicamente suddiviso in quattro aree. Tutte vivono in `modules/community/` come un unico package, ma in `src/` sono organizzate per responsabilita':

```
modules/community/
|-- lib/
|   |-- community.dart
|   |-- api.dart              (CommunityApi unificata)
|   +-- src/
|       |-- domain/
|       |   |-- published_route.dart
|       |   |-- comment.dart
|       |   |-- like.dart
|       |   |-- follow.dart
|       |   +-- community_error.dart
|       |-- application/
|       |   |-- publishing_service.dart     (publish / unpublish)
|       |   |-- feed_service.dart           (scoperta, profili)
|       |   |-- interaction_service.dart    (commenti + like)
|       |   |-- follow_service.dart         (follow / unfollow)
|       |   +-- report_service.dart         (segnalazioni, parte di B.2)
|       |-- persistence/
|       |   |-- published_routes_dao.dart
|       |   |-- route_comments_dao.dart
|       |   |-- route_likes_dao.dart
|       |   +-- follow_relationships_dao.dart
|       +-- ui/
|           |-- feed_screen.dart
|           |-- route_detail_screen.dart
|           |-- publish_form.dart
|           |-- profile_screen.dart
|           +-- widgets/
|-- test/
+-- pubspec.yaml
```

**Nota:** il singolo `CommunityApi` pubblico aggrega operazioni delle 4 aree. In futuro, se il modulo cresce, si puo' split in `PublishingApi`, `FeedApi`, `InteractionApi`, `FollowApi`. Per MVP l'aggregazione in una singola classe e' sostenibile.

---

## Sezione 3 -- API pubblica (sintesi)

Esportata da `modules/community/lib/api.dart`. Firme complete in `L05_interfaces.md`.

### 3.1 Publishing

- `publishFromActivity(activityClientId, PublishOptions)` -> crea PublishedRoute snapshot da Activity.
- `publishFromPlannedRoute(plannedRouteClientId, PublishOptions)` -> idem da PlannedRoute.
- `updatePublishedRoute(clientId, UpdatePublishedOptions)` -> modifica campi (titolo, descrizione, tags).
- `unpublishRoute(clientId)` -> soft delete PublishedRoute.
- `resyncFromSource(clientId)` -> aggiorna snapshot dalla sorgente attuale (UX "aggiorna pubblicazione").

### 3.2 Feed e scoperta

- `watchPersonalFeed(ownerId)` -> Stream, activity + PublishedRoute di utenti che owner segue.
- `watchPublicFeed(filters)` -> feed globale con filtri (tags, area geo, ecc.).
- `getProfile(userId)` -> profile stats aggregate (n PublishedRoute, n followers, n following).
- `getProfilePublishedRoutes(userId)` -> PublishedRoute dell'utente (rispettando visibility e RLS).

### 3.3 Interazioni

- `addComment(publishedRouteId, text)` -> Future<Result<String, E>>.
- `deleteComment(commentId)` -> soft delete (author + owner route).
- `watchComments(publishedRouteId)` -> Stream<List<RouteComment>>.
- `toggleLike(publishedRouteId)` -> add / remove.
- `getLikeCount(publishedRouteId)` -> int.
- `hasLiked(publishedRouteId)` -> bool.

### 3.4 Follow

- `follow(targetUserId)` / `unfollow(targetUserId)`.
- `getFollowers(userId)` -> List<ProfileSummary>.
- `getFollowing(userId)` -> List<ProfileSummary>.
- `isFollowing(targetUserId)` -> bool.

### 3.5 Report / moderazione

- `reportContent(entityKind, entityId, reason)` -> trigger per admin (vedi B.2).

---

## Sezione 4 -- Eventi emessi sul bus

### 4.1 Publishing

- `RoutePublishedEvent(clientId, ownerId, sourceType, sourceClientId, visibility)`.
- `RouteUnpublishedEvent(clientId, ownerId, unpublishedAt)`.
- `PublishedRouteUpdatedEvent(clientId, ownerId, changedFields)`.

### 4.2 Interactions

- `CommentAddedEvent(commentClientId, routeClientId, authorId)`.
- `CommentDeletedEvent(commentClientId, routeClientId, deletedBy)`.
- `LikeAddedEvent(likeClientId, routeClientId, likerId)`.
- `LikeRemovedEvent(routeClientId, likerId)`.

### 4.3 Follows

- `UserFollowedEvent(followerId, followedId)`.
- `UserUnfollowedEvent(followerId, followedId)`.

**Consumatori principali:**

- Modulo sync: enqueue operazioni sul server.
- Modulo notifications (futuro): inviera' push "X ha commentato il tuo giro", "Y ti segue".

---

## Sezione 5 -- Eventi consumati

### 5.1 `ActivityCompletedEvent` (dal tracking)

**Reazione community:** **non publica automaticamente**. Ma mostra in UI post-save una "call to action" suggerendo "Vuoi condividere questo giro?".

L'utente deve esplicitamente chiamare `publishFromActivity`. Niente auto-publishing.

### 5.2 `ActivityDeletedEvent` (dal tracking, futuro)

**Reazione:** se esistono PublishedRoute con `source_client_id` = Activity cancellata, server trigger `null_published_source_on_parent_delete` (vedi D.19) gia' gestisce. Community non deve fare nulla di speciale lato client -- al prossimo fetch server, `source_client_id` sara' null.

### 5.3 `UserLoggedOutEvent`

Nessuna reazione. Feed si svuota alla dashboard home, si ricarica al login.

---

## Sezione 6 -- Interazioni operative

### 6.1 Pubblicazione di Activity

1. Utente da activity detail screen tappa "Pubblica".
2. UI `publish_form` chiede: titolo (default = Activity.title), descrizione, tags, visibility (public | friends_only).
3. Tap Submit -> `CommunityApi.publishFromActivity(activityId, options)`.
4. Service:
   - Verifica `activity.ownerId == currentUserId`.
   - Crea PublishedRoute con **snapshot completo** (polyline, bbox, distance, ecc. copiati dall'Activity). Vedi D.32.
   - `source_type = 'activity'`, `source_client_id = activity.clientId`.
   - Insert drift, `sync_state = 'pending'`.
   - Emit `RoutePublishedEvent`.
5. Sync orchestrator enqueue upload.

### 6.2 Feed personale

1. UI `feed_screen` chiama `watchPersonalFeed(currentUserId)`.
2. Service fa:
   - Query server: `SELECT published_routes WHERE owner_id IN (followed_users) AND visibility IN ('public', 'friends_only') AND deleted_at IS NULL`.
   - Oppure (scelta MVP): pagina iniziale via Supabase direct query, successive via infinite scroll con cursor.
3. Feed piu' recente prima, cursor-based pagination `created_at DESC`.

### 6.3 Like

1. Utente tap cuore.
2. UI optimistic: mostra cuore pieno + incrementa counter visibile.
3. `CommunityApi.toggleLike(routeId)`.
4. Service:
   - Check se like esiste gia' in drift (cached).
   - Se no: insert `route_likes_local`, enqueue INSERT server.
   - Se si': delete locale, enqueue HARD DELETE server.
5. Emit evento corrispondente.
6. Se sync fallisce (es. rete assente persistente), il like resta in `pending`. Alla UI prossima apertura, lo stato e' comunque "liked" (fetch non sovrascrive pending ottimistico).

### 6.4 Commento

1. Utente scrive testo + tap Invia.
2. Service:
   - Valida testo (1-1000 caratteri).
   - Insert `route_comments_local`, `sync_state = 'pending'`.
   - Emit `CommentAddedEvent`.
3. UI ottimistica: commento appare subito con indicatore "invio...". Dopo sync OK: indicatore sparisce.

### 6.5 Follow

1. Utente da profilo altrui tap "Segui".
2. UI optimistic: bottone passa a "Seguendo".
3. Service: insert `follow_relationships_local`, enqueue INSERT server.
4. Emit `UserFollowedEvent`.

---

## Sezione 7 -- Cache e offline

**Policy MVP (coerente con B.3 proposta b):**

- Own PublishedRoute: cached in drift (rehydration).
- Own RouteComment e RouteLike (su proprie route): cached.
- PublishedRoute di utenti seguiti: NON cached offline. Feed richiede connessione.
- Azioni in offline (like, commento, follow) restano in `pending` nella `sync_queue_local` e vanno online al ritorno connessione.

**Eccezione pragmatica:** al primo render di una route pubblica, la cachiamo per 24h (cache HTTP-like) per ridurre chiamate ripetute. Non e' persistenza drift, e' in-memory + invalidation.

---

## Sezione 8 -- Moderazione

### 8.1 Report utenti

Utente tocca "Segnala" su PublishedRoute o RouteComment. Dialog chiede motivo (categoria fissa: spam, contenuto inappropriato, molestie, altro).

`report_service.createReport(entityKind, entityId, reason)`:

- Insert in tabella `reports` (non definita ancora nello schema DB, va aggiunta nel modulo moderazione futuro).
- Notifica admin via Slack/email (post-MVP).

**MVP minimale:** solo insert report. Admin apre dashboard e processa manualmente.

### 8.2 Admin actions

Vedi B.2. Include: warning utente, unpublish forzato, ban.

---

## Sezione 9 -- Dipendenze del modulo

### Consumes:

- `shared/db/AppDatabase` per le 4 tabelle community.
- `shared/event_bus/EventBus`.
- `shared/auth/AuthService`.
- `shared/supabase/SupabaseClient` (per feed online direct query).
- `MotorcycleApi` (visualizzare moto in ProfileScreen).

### Non consumes direct:

- `TrackingApi` (uso Activity via `shared/db/repositories/ActivitiesReadRepository`).

### Provides:

- `CommunityApi`.

---

## Sezione 10 -- Performance

**Feed:** paginato 20 item alla volta. Scroll infinito. Cursor-based su `created_at`.

**Thumbnail polyline:** rendering client-side via decode polyline + render su canvas Mapbox statico. Preserva server bandwidth.

**Counter aggregati** (n_likes, n_comments): query denormalizzata server side via view materializzata O colonne cache aggiornate da trigger. Per MVP: **colonne cache** `like_count`, `comment_count` su `published_routes`, aggiornate da trigger su INSERT/DELETE delle rispettive tabelle.

Schema DB aggiornamento necessario -> **modifica retroattiva a `02_database_schema.md` Sezione 3.6**. Nota: aggiungere `like_count INTEGER NOT NULL DEFAULT 0` e `comment_count INTEGER NOT NULL DEFAULT 0` a `published_routes` + trigger.

---

## Sezione 11 -- Testing

- Publishing happy path.
- Unpublish con soft delete.
- Resync da sorgente modificata.
- Feed pagination.
- Like optimistic poi rollback su error server (se 403 perche' bloccato).
- Commento lungo 1000 caratteri (boundary).
- Follow / unfollow toggle.
- Report flow minimale.

---

**Fine 07_community/L0_architecture.md**
