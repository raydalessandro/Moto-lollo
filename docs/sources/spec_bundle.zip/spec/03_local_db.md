# 03 -- Local Database (drift / SQLite)

**Scopo:** schema del database locale dell'app mobile. Tabelle drift, TypeConverter, organizzazione modulare, pattern di migrazione.

**Cosa NON e' in questo documento:**

- Lo schema server Postgres (vive in `02_database_schema.md`).
- La logica di sync tra locale e server (vive in `05_sync/`).
- Le interfacce pubbliche dei repository (vivono negli `L05_interfaces.md` di ciascun modulo).

**Riferimenti:**

- Entita' logiche: `01_data_model.md`.
- Schema Postgres per confronto: `02_database_schema.md`.
- Architettura modulare: `00_overview.md` Sezione 4.

**Principio di corrispondenza:** le tabelle drift che replicano entita' server hanno **la stessa shape** dello schema Postgres (stessi nomi di colonna, stessi tipi logici), con aggiunta dei campi di sync state (`sync_state`, `sync_retry_count`, `sync_last_error`). Divergenze sono documentate esplicitamente.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Convenzioni drift

### 1.1 Tipi SQLite vs Postgres

SQLite ha un sistema di tipi piu' limitato di Postgres. Mapping:

| Postgres | SQLite (drift) | Nota |
|---|---|---|
| `UUID` | `TEXT` | Serializzato come string. |
| `TEXT` / `VARCHAR` | `TEXT` | Identico. |
| `INTEGER` / `BIGINT` | `INTEGER` | Identico. |
| `NUMERIC(10,3)` | `REAL` | Potenziale perdita precisione su valori molto lunghi -- accettabile per distanze, velocita', km totali. |
| `BOOLEAN` | `INTEGER` (0/1) | Drift gestisce automaticamente via `BoolColumn`. |
| `TIMESTAMPTZ` | `TEXT` (ISO-8601 UTC) o `INTEGER` (millis) | Sceglieremo `TEXT` ISO-8601 per leggibilita' debug. Drift `DateTimeColumn` lo gestisce. |
| `JSONB` | `TEXT` | Serializzato come JSON string. TypeConverter dedicato. |
| `TEXT[]` | `TEXT` | Serializzato come JSON array string. TypeConverter dedicato. |
| `UUID[]` | `TEXT` | Come sopra. |
| `GEOMETRY(Polygon)` | 4 colonne REAL | `bbox_min_lat`, `bbox_min_lon`, `bbox_max_lat`, `bbox_max_lon`. SQLite non ha geometry types senza SpatiaLite (non disponibile su Flutter in modo semplice). |
| `ENUM` | `TEXT` con CHECK | Drift: `TextColumn` + TypeConverter Dart Enum <-> String. |

### 1.2 Timestamp

- Tutti i timestamp sono salvati in **UTC ISO-8601** come TEXT.
- La conversione a locale avviene sempre lato UI.
- `DateTime.toUtc().toIso8601String()` per salvare, `DateTime.parse(text).toUtc()` per rileggere (drift fa automaticamente con `DateTimeColumn`).

### 1.3 Bbox

- Polygon bbox diventa 4 colonne: `bbox_min_lat`, `bbox_min_lon`, `bbox_max_lat`, `bbox_max_lon`.
- Non sono permessi valori null -- ogni riga con bbox deve averli tutti e quattro.
- Conversione a/da Postgres Polygon avviene lato `upload_dispatcher` (modulo sync) al momento dell'upload: 4 scalari drift -> `ST_MakeEnvelope(min_lon, min_lat, max_lon, max_lat, 4326)` server-side.

### 1.4 Campi `sync_state` aggiunti

Ogni tabella replicata server-side ha **in aggiunta rispetto a Postgres** le seguenti colonne locali:

| Colonna | Tipo | Default | Note |
|---|---|---|---|
| `sync_state` | TEXT (enum) | `pending` | `pending \| syncing \| synced \| failed`. |
| `sync_retry_count` | INTEGER | 0 | |
| `sync_last_error` | TEXT | NULL | Ultimo errore se `failed`. |

Queste colonne NON esistono server-side. Non vengono mai sincronizzate.

**Nota su `id` server-side:** lato client si usa sempre `client_id` come PK logica. L'`id` generato da Postgres resta server-side (necessario per FK interne del DB) ma **non viene replicato nel drift**. Se un giorno servisse (debug cross-riferimento), puo' essere ricostruito via query server a partire da `client_id`. Decisione chiusa in D.37.

### 1.5 Primary key

Per tabelle replicate dal server la PK locale e' `client_id` (coerente con Postgres). Tabelle solo-locali possono usare `INTEGER PRIMARY KEY AUTOINCREMENT` quando e' piu' conveniente (es. `track_point_buffer`).

### 1.6 CHECK constraints

Drift supporta `customConstraint('CHECK (...)')`. Li useremo dove serve riflettere i vincoli Postgres per catch-errors-early lato client.

### 1.7 Soft delete

`deleted_at` colonna come Postgres (nullable DateTime). Niente trigger lato SQLite -- le politiche di anonimizzazione profile sono applicate solo server-side; lato client il record arriva gia' anonimizzato via rehydration/sync.

---

## Sezione 2 -- Organizzazione modulare

**Regola dall'overview Sezione 4.5:** i singoli moduli dichiarano le proprie tabelle, `shared/db/` le compone in un'unica istanza drift.

### 2.1 Dove vive ogni tabella

**Tabelle in `shared/db/`** (accessibili a piu' moduli):
- `profiles_local`
- `motorcycles_local`
- `activities_local`
- `activity_media_local`
- `planned_routes_local`
- `published_routes_local`
- `route_comments_local`
- `route_likes_local`
- `follow_relationships_local`
- `live_sessions_local` (il modulo live ne e' owner, ma altri la leggono per UI)
- `safety_contacts_local`
- `safety_events_local`
- `notifications_local`

Motivazione: tutte queste entita' sono **lette da piu' di un modulo** (tracking scrive Activity, community e garage la leggono; community crea Comment, notifications crea payload che referenzia il comment; ecc.). Vivere in `shared/db/` chiarisce che sono dominio comune.

**Tabelle in `modules/<modulo>/lib/src/persistence/`** (private al modulo):
- `recording_sessions_local` -> **modulo tracking**
- `track_point_buffer_local` -> **modulo tracking**
- `sync_queue_local` -> **modulo sync**
- `error_log_outbox_local` -> **modulo errors** (coda per upload error_logs)

Motivazione: sono stato interno del modulo. Nessun altro modulo le legge. Vivere dentro il modulo chiarisce il confine.

### 2.2 Composizione in `shared/db/`

Struttura:

```
shared/db/
|-- lib/
|   |-- db.dart                         (classe AppDatabase drift)
|   |-- tables/                         (dichiarazioni delle tabelle shared)
|   |   |-- profiles_local.dart
|   |   |-- motorcycles_local.dart
|   |   |-- activities_local.dart
|   |   |-- ... (una per tabella shared)
|   |-- converters/
|   |   |-- enum_converter.dart         (TypeConverter generico per enum)
|   |   |-- json_map_converter.dart
|   |   |-- json_list_converter.dart
|   |   +-- uuid_list_converter.dart
|   +-- migrations/
|       |-- v2_to_v3.dart
|       |-- v3_to_v4.dart
|       +-- ...
+-- pubspec.yaml
```

In `db.dart`:

```dart
@DriftDatabase(
  tables: [
    // Shared
    ProfilesLocal,
    MotorcyclesLocal,
    ActivitiesLocal,
    ActivityMediaLocal,
    PlannedRoutesLocal,
    PublishedRoutesLocal,
    RouteCommentsLocal,
    RouteLikesLocal,
    FollowRelationshipsLocal,
    LiveSessionsLocal,
    SafetyContactsLocal,
    SafetyEventsLocal,
    NotificationsLocal,
    // Modulo tracking
    RecordingSessionsLocal,
    TrackPointBufferLocal,
    // Modulo sync
    SyncQueueLocal,
    // Modulo errors
    ErrorLogOutboxLocal,
  ],
  daos: [
    // DAOs dichiarati nei rispettivi moduli, aggregati qui
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase(QueryExecutor e) : super(e);

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
    onCreate: (m) async => m.createAll(),
    onUpgrade: (m, from, to) async {
      // Vedi Sezione 7
    },
  );
}
```

**Nota architetturale:** la classe `AppDatabase` in `shared/db/` **aggrega** tabelle dichiarate in altri package. Drift richiede che le tabelle siano importate al momento della generazione del codice. Soluzione: i singoli moduli esportano le loro classi di tabella via la loro `lib/<modulo>.dart`, e `shared/db/` le importa.

Questo e' tecnicamente un "uso sotterraneo" della regola overview Sezione 4.5 (i moduli non si importano tra loro). La deroga e' giustificata perche' `shared/db/` e' **l'unico aggregatore permesso** di codice cross-modulo. E' il meta-livello del monorepo.

### 2.3 Accesso cross-modulo

Un modulo che vuole leggere la tabella di un altro modulo (es. community legge `activities_local` scritta da tracking) usa:

- `shared/db/AppDatabase.select(activitiesLocal)...` direttamente, oppure
- Un repository condiviso esposto in `shared/db/repositories/` (es. `ActivitiesReadRepository`).

**Un modulo NON accede alle tabelle private di un altro modulo.** `recording_sessions_local` e' leggibile solo dal modulo tracking, anche se tecnicamente la tabella e' visibile nell'AppDatabase aggregata.

Questa regola e' di convenzione + code review. Opzionalmente puo' essere enforced in futuro via linter custom.

---

## Sezione 3 -- TypeConverter comuni

File `shared/db/lib/converters/`.

### 3.1 Enum converter generico

```dart
class EnumConverter<T extends Enum> extends TypeConverter<T, String> {
  final List<T> values;
  const EnumConverter(this.values);

  @override
  T fromSql(String fromDb) =>
      values.firstWhere((e) => e.name == fromDb,
          orElse: () => throw StateError('unknown enum value: \$fromDb'));

  @override
  String toSql(T value) => value.name;
}
```

Usato per: `sync_state`, `visibility`, `point_state`, `role`, `source`, `state` varie, ecc.

### 3.2 JSON map converter

```dart
class JsonMapConverter extends TypeConverter<Map<String, dynamic>, String> {
  const JsonMapConverter();

  @override
  Map<String, dynamic> fromSql(String fromDb) =>
      json.decode(fromDb) as Map<String, dynamic>;

  @override
  String toSql(Map<String, dynamic> value) => json.encode(value);
}
```

Usato per: `feature_flags`, `payload` delle notification, `context` degli error_logs, `waypoints` delle planned_routes.

### 3.3 JSON list converter (per `tags: List<String>`, `track_points_data`)

```dart
class JsonListConverter<T> extends TypeConverter<List<T>, String> {
  final T Function(dynamic) fromJson;
  final dynamic Function(T) toJson;
  const JsonListConverter(this.fromJson, this.toJson);

  @override
  List<T> fromSql(String fromDb) {
    final raw = json.decode(fromDb) as List;
    return raw.map((e) => fromJson(e)).toList();
  }

  @override
  String toSql(List<T> value) =>
      json.encode(value.map((e) => toJson(e)).toList());
}
```

Istanze concrete:

```dart
final tagsConverter = JsonListConverter<String>(
  (e) => e as String,
  (s) => s,
);

final uuidListConverter = JsonListConverter<String>(
  (e) => e as String,
  (s) => s,
);
```

### 3.4 Track points converter

Il campo `track_points_data` nelle `activities_local` e' una lista di TrackPoint. Definiamo un converter dedicato:

```dart
class TrackPointsConverter
    extends TypeConverter<List<TrackPointRaw>, String> {
  const TrackPointsConverter();

  @override
  List<TrackPointRaw> fromSql(String fromDb) {
    final raw = json.decode(fromDb) as List;
    return raw.map((e) => TrackPointRaw.fromJson(e)).toList();
  }

  @override
  String toSql(List<TrackPointRaw> value) =>
      json.encode(value.map((p) => p.toJson()).toList());
}
```

`TrackPointRaw` e' un value object semplice (Dart `class`) con campi `t, lat, lon, speed, ele, point_state, acc`.

---

## Sezione 4 -- Tabelle replicate (shared)

Per brevita', mostrero' solo alcune tabelle per esteso e per le altre elenchero' le differenze salienti rispetto al Postgres equivalente (che e' sorgente di verita' per shape business).

### 4.1 `profiles_local`

```dart
class ProfilesLocal extends Table {
  TextColumn get id => text().customConstraint('NOT NULL UNIQUE')();
  TextColumn get username => text().withLength(min: 3, max: 30)();
  TextColumn get displayName => text().withLength(min: 1, max: 50)();
  TextColumn get bio => text().withLength(max: 500).nullable()();
  TextColumn get avatarStoragePath => text().nullable()();
  TextColumn get role => text().map(const EnumConverter(ProfileRole.values))();
  TextColumn get accountStatus =>
      text().withDefault(const Constant('active'))();
  BoolColumn get isPublic => boolean().withDefault(const Constant(true))();
  TextColumn get featureFlags =>
      text().map(const JsonMapConverter()).withDefault(const Constant('{}'))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  DateTimeColumn get deletedAt => dateTime().nullable()();
  IntColumn get version => integer().withDefault(const Constant(0))();

  // Campi di sync (ProfilesLocal NON e' sincronizzato in push attivo, ma tiene i campi per uniformita' -- valore default 'synced')
  TextColumn get syncState =>
      text().withDefault(const Constant('synced'))();
  IntColumn get syncRetryCount =>
      integer().withDefault(const Constant(0))();
  TextColumn get syncLastError => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
}
```

Nota: per `profiles` non esiste `client_id` (gestito da auth). L'`id` e' l'auth.users.id. Il `sync_state` e' presente per uniformita' ma tipicamente e' `synced` perche' il profilo arriva via rehydration.

### 4.2 `motorcycles_local`

```dart
class MotorcyclesLocal extends Table {
  TextColumn get clientId => text()();
  TextColumn get ownerId => text()();

  TextColumn get name => text().withLength(min: 1, max: 50)();
  TextColumn get brand => text().withLength(min: 1, max: 50)();
  TextColumn get model => text().withLength(min: 1, max: 100)();
  IntColumn get year => integer().nullable()();
  IntColumn get engineCc => integer().nullable()();
  TextColumn get color => text().nullable()();
  TextColumn get photoStoragePath => text().nullable()();
  RealColumn get odometerStartKm =>
      real().withDefault(const Constant(0))();
  RealColumn get totalKm => real().withDefault(const Constant(0))();
  BoolColumn get isPrimary => boolean().withDefault(const Constant(false))();

  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  DateTimeColumn get deletedAt => dateTime().nullable()();
  IntColumn get version => integer().withDefault(const Constant(0))();

  // Sync state
  TextColumn get syncState =>
      text().map(const EnumConverter(SyncState.values))();
  IntColumn get syncRetryCount =>
      integer().withDefault(const Constant(0))();
  TextColumn get syncLastError => text().nullable()();

  @override
  Set<Column> get primaryKey => {clientId};
}

// Index dichiarato separatamente
@DataClassName('MotorcycleLocal')
// dichiarazione indice
// CREATE UNIQUE INDEX idx_motorcycles_one_primary_local
//   ON motorcycles_local(owner_id) WHERE is_primary = 1 AND deleted_at IS NULL;
```

Note:
- Unique indice parziale "una sola primary" implementato nel `migrations/v1_schema.dart` come raw SQL.
- `totalKm` e' calcolato **client-side ottimisticamente** in MVP: quando una Activity completa viene aggiunta, il modulo garage ascolta `ActivityCompletedEvent` e aggiorna `totalKm` localmente. Al momento del sync, il valore server-side (calcolato dal trigger Postgres) riconciliera'.

### 4.3 `activities_local`

```dart
class ActivitiesLocal extends Table {
  TextColumn get clientId => text()();
  TextColumn get ownerId => text()();
  TextColumn get motorcycleId => text().nullable()();

  DateTimeColumn get startedAt => dateTime()();
  DateTimeColumn get endedAt => dateTime()();
  IntColumn get durationSeconds => integer()();
  IntColumn get durationTotalSeconds => integer()();

  RealColumn get distanceKm => real()();
  RealColumn get avgSpeedKmh => real()();
  RealColumn get maxSpeedKmh => real()();
  RealColumn get elevationGainM => real().nullable()();

  // bbox scomposta in 4 REAL
  RealColumn get bboxMinLat => real()();
  RealColumn get bboxMinLon => real()();
  RealColumn get bboxMaxLat => real()();
  RealColumn get bboxMaxLon => real()();

  TextColumn get polylineEncoded => text()();
  TextColumn get trackPointsData =>
      text().map(const TrackPointsConverter())();

  TextColumn get title => text().withLength(min: 1, max: 100)();
  TextColumn get notes => text().withLength(max: 2000).nullable()();
  TextColumn get tags => text().map(tagsConverter)
      .withDefault(const Constant('[]'))();
  TextColumn get visibility =>
      text().map(const EnumConverter(ActivityVisibility.values))();
  BoolColumn get wasRecovered =>
      boolean().withDefault(const Constant(false))();

  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  DateTimeColumn get deletedAt => dateTime().nullable()();
  IntColumn get version => integer().withDefault(const Constant(0))();

  TextColumn get syncState =>
      text().map(const EnumConverter(SyncState.values))();
  IntColumn get syncRetryCount =>
      integer().withDefault(const Constant(0))();
  TextColumn get syncLastError => text().nullable()();

  @override
  Set<Column> get primaryKey => {clientId};
}
```

**Indici** (creati in migration):
- `(owner_id, ended_at DESC) WHERE deleted_at IS NULL` -- feed personale.
- `(sync_state)` -- scan veloce per sync_orchestrator.
- `(motorcycle_id) WHERE motorcycle_id IS NOT NULL` -- query garage.

Niente indice bbox (SQLite senza SpatiaLite non supporta R-Tree out of box su geo-columns multi-col). Per ricerca bbox lato client useremo semplice `WHERE bbox_min_lat >= ... AND bbox_max_lat <= ...` con full scan o indice su `bbox_min_lat` per narrow. E' accettabile: query geo client-side sono rare (mostrano activity "vicine a te" solo in UI specifiche).

### 4.4 `activity_media_local`

Campi identici a `02_database_schema.md` Sezione 3.4. Aggiunta `sync_state`. PK `client_id`. Niente trigger di coerenza owner -- la coerenza e' garantita lato app, e se arriva desyncata dal server e' comunque valida.

**Campo locale aggiuntivo** (vedi D.40):

- **`local_cache_path`** (TEXT nullable): path **relativo** alla `ApplicationDocumentsDirectory` del file scaricato/caricato (es. `media_cache/{activity_id}/{media_id}_full.jpg`). Null se il file non e' presente localmente. Il repository espone `resolveLocalFullPath(relativePath)` che fa join con `getApplicationDocumentsDirectory()` runtime. Le UI non toccano mai path assoluti.

**Importante:** `local_cache_path` valorizzato NON garantisce che il file esista (l'utente puo' aver svuotato storage, l'OS puo' aver pulito cache). Prima di ogni uso verificare `File(absolutePath).exists()` e, in caso negativo, triggerare download da Supabase Storage usando `storage_path_full` o `storage_path_thumb`.

### 4.5 `planned_routes_local`

Come Postgres, ma `bbox` scomposto in 4 REAL. `waypoints` come TEXT+JsonMapConverter (o array di map). Aggiunta `sync_state`.

### 4.6 `published_routes_local`

Come Postgres. `bbox` in 4 REAL. `source_client_id` nullable. `tags` e `source_type` via EnumConverter. Include `is_flagged`, `flagged_reason`, `flagged_at` per coerenza con server (`02_database_schema.md` Sezione 4.8). Il client filtra `is_flagged = true` di solito (RLS server gia' filtra), ma possiede la colonna per coerenza schema. Owner vede proprie route flagged con banner "Sotto revisione".

### 4.7 `route_comments_local`

Come Postgres. `sync_state` aggiunto. Append-only tranne per `deleted_at`. Include `is_flagged`, `flagged_reason`, `flagged_at` per coerenza con server.

### 4.8 `route_likes_local`

Come Postgres. `sync_state` aggiunto. Niente `deleted_at` (hard delete).

### 4.9 `follow_relationships_local`

Come Postgres. `sync_state` aggiunto. CHECK `follower_id <> followed_id` replicato via `customConstraint`.

### 4.10 `live_sessions_local`

Come Postgres. `sync_state`. `invited_profile_ids` via uuidListConverter. Include `notify_contacts_on_gps_inactivity`, `viewer_safety_contact_ids` (uuidListConverter), `end_reason` (EnumConverter). Colonne predisposte per watchdog safety (B.7), utilizzate se/quando la feature sara' attivata.

**Nota:** `live_positions` NON esiste lato drift. Le posizioni ricevute in tempo reale via Realtime vivono in memoria RAM del modulo live (buffer scorrevole ultimi N minuti). Non c'e' bisogno di persistenza locale -- se l'utente chiude l'app, le posizioni storiche gia' viste si perdono; al riavvio ricomincia a consumare lo stream live.

### 4.11 `safety_contacts_local`

Come Postgres. `sync_state`. CHECK almeno uno tra phone/email replicato.

### 4.12 `safety_events_local`

Come Postgres. `sync_state`. `notified_contact_ids` via uuidListConverter. `notification_channels_used` via tagsConverter (e' una List<String>).

### 4.13 `notifications_local`

Differenza chiave rispetto a Postgres:

- Il client **non insert** mai notifications. Le riceve via push FCM + pull periodico.
- Pull: all'apertura app e ogni refresh, scarica notifiche nuove da server.
- Update client-side: solo `read_at` (coerente con overview Sezione 6).

Drift schema identico a Postgres con `sync_state` aggiunto. `sync_state` viene usato per il caso "utente marca come letta offline" -> `pending` -> sync invia UPDATE quando online.

### 4.14 Nessuna `error_logs_local`

Gli error_logs vengono messi in una coda separata `error_log_outbox_local` (Sezione 5.4) che viene uploadata, non conservata permanentemente lato client.

---

## Sezione 5 -- Tabelle solo-locali

Vivono nei rispettivi moduli.

### 5.1 `recording_sessions_local` (modulo tracking)

File: `modules/tracking/lib/src/persistence/recording_sessions_local.dart`.

```dart
class RecordingSessionsLocal extends Table {
  TextColumn get clientId => text()();
  TextColumn get ownerId => text()();
  TextColumn get motorcycleId => text().nullable()();

  TextColumn get state =>
      text().map(const EnumConverter(RecordingSessionState.values))();
  DateTimeColumn get startedAt => dateTime()();
  DateTimeColumn get endedAt => dateTime().nullable()();

  TextColumn get titleDraft => text().nullable()();
  TextColumn get notesDraft => text().nullable()();
  BoolColumn get wasRecovered =>
      boolean().withDefault(const Constant(false))();

  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {clientId};
}
```

**Indici:**
- Unique parziale `(owner_id) WHERE state = 'active'` -- invariante I.2 (max una session attiva).

**Niente `sync_state`** -- tabella puramente locale, mai spedita.

### 5.2 `track_point_buffer_local` (modulo tracking)

File: `modules/tracking/lib/src/persistence/track_point_buffer_local.dart`.

```dart
class TrackPointBufferLocal extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get recordingSessionId => text()();
  IntColumn get seq => integer()();
  DateTimeColumn get capturedAt => dateTime()();
  RealColumn get latitude => real()();
  RealColumn get longitude => real()();
  RealColumn get altitudeM => real().nullable()();
  RealColumn get speedMs => real().nullable()();
  RealColumn get headingDeg => real().nullable()();
  RealColumn get accuracyM => real().nullable()();
  TextColumn get pointState =>
      text().map(const EnumConverter(TrackPointState.values))
        .withDefault(const Constant('normal'))();
}
```

**Indici:**
- `(recording_session_id, seq)` -- lettura ordinata al momento di buffer_to_activity.

**PK** autoincrement (non UUID) -- e' ephemeral, performance-critical nelle insert 1/sec.

### 5.3 `sync_queue_local` (modulo sync)

File: `modules/sync/lib/src/persistence/sync_queue_local.dart`.

```dart
class SyncQueueLocal extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get ownerId => text()();                  // filtering per utente corrente
  TextColumn get entityKind =>
      text().map(const EnumConverter(EntityKind.values))();
  TextColumn get entityClientId => text()();
  TextColumn get operation =>
      text().map(const EnumConverter(SyncOperation.values))();
  IntColumn get priority => integer()();
  DateTimeColumn get enqueuedAt => dateTime()();
  IntColumn get retryCount => integer().withDefault(const Constant(0))();
  DateTimeColumn get nextRetryAt => dateTime()();
  TextColumn get lastErrorCode => text().nullable()();
  TextColumn get lastErrorMessage => text().nullable()();
  DateTimeColumn get lastAttemptAt => dateTime().nullable()();
  TextColumn get dependencyClientIds =>
      text().map(uuidListConverter).withDefault(const Constant('[]'))();
  TextColumn get state =>
      text().map(const EnumConverter(SyncQueueItemState.values))();
}
```

**Motivazione `owner_id`:** se utente A ha item pending e poi B fa login sullo stesso device, il worker di B deve ignorare gli item di A. La colonna permette dequeue filtrato per utente corrente. Coerente con `05_sync/edge_cases.md` Sezione 3.2.

**Indici:**
- `(owner_id, state, priority, next_retry_at)` -- dequeue query piu' frequente, con filter per utente corrente.
- `(entity_kind, entity_client_id)` -- lookup per coalescence.

**Popolamento:** `owner_id` viene valorizzato dal `queue_scheduler.enqueueWithAutoDeps(entity)` leggendo `entity.owner_id`. Per entita' che non hanno `owner_id` (raro -- attualmente nessuna, tutte user-generated hanno owner), si usa il `currentUserId` al momento dell'enqueue.

### 5.4 `error_log_outbox_local` (modulo errors)

Vive in `modules/errors/` (modulo leggero futuro, per ora inglobato in `shared/`).

```dart
class ErrorLogOutboxLocal extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get userId => text().nullable()();
  TextColumn get platform =>
      text().map(const EnumConverter(Platform.values))();
  TextColumn get appVersion => text()();
  TextColumn get module => text()();
  TextColumn get level =>
      text().map(const EnumConverter(ErrorLogLevel.values))();
  TextColumn get message => text()();
  TextColumn get stackTrace => text().nullable()();
  TextColumn get context =>
      text().map(const JsonMapConverter())
        .withDefault(const Constant('{}'))();
  DateTimeColumn get createdAt => dateTime()();

  // Stato di upload
  TextColumn get uploadState =>
      text().withDefault(const Constant('pending'))();
  IntColumn get uploadRetryCount =>
      integer().withDefault(const Constant(0))();
}
```

Purga: dopo upload riuscito (`uploadState = 'uploaded'`) il record viene cancellato. Maintenance locale: hard delete anche `uploaded` vecchi di 7 giorni come sanity.

---

## Sezione 6 -- DAO e repository

### 6.1 Pattern generale

Per ogni tabella:
- Una classe DAO in `modules/<proprietario>/lib/src/persistence/<tabella>_dao.dart` (o in `shared/db/` se tabella shared).
- La DAO espone metodi CRUD di basso livello.
- Un `Repository` in `modules/<modulo>/lib/src/application/` usa la DAO per esporre operazioni di piu' alto livello al resto del modulo.

Esempio per `activities`:

```dart
// shared/db/lib/activities_dao.dart
@DriftAccessor(tables: [ActivitiesLocal])
class ActivitiesDao extends DatabaseAccessor<AppDatabase>
    with _$ActivitiesDaoMixin {
  ActivitiesDao(AppDatabase db) : super(db);

  Future<int> insert(ActivitiesLocalCompanion entry) =>
    into(activitiesLocal).insert(entry);

  Future<ActivityLocal?> getByClientId(String id) =>
    (select(activitiesLocal)..where((t) => t.clientId.equals(id))).getSingleOrNull();

  Stream<List<ActivityLocal>> watchOwnerActivities(String ownerId) =>
    (select(activitiesLocal)
      ..where((t) => t.ownerId.equals(ownerId) & t.deletedAt.isNull())
      ..orderBy([(t) => OrderingTerm.desc(t.endedAt)]))
      .watch();

  Stream<List<ActivityLocal>> watchPendingSync() =>
    (select(activitiesLocal)
      ..where((t) => t.syncState.equals('pending')))
      .watch();
}
```

### 6.2 Scrittura cross-modulo proibita

Rispettando la regola dell'overview 4.5, **solo il modulo owner della tabella puo' scrivere** su di essa (tramite la sua DAO).

**Owner delle tabelle:**

| Tabella | Owner (writer) | Readers |
|---|---|---|
| `profiles_local` | auth | tutti |
| `motorcycles_local` | garage | tracking, activities UI, sync |
| `activities_local` | tracking (insert su close) | community, garage, sync, UI |
| `activity_media_local` | community (UI upload foto) | UI |
| `planned_routes_local` | planning | navigation, community |
| `published_routes_local` | community | UI feed |
| `route_comments_local` | community | UI |
| `route_likes_local` | community | UI |
| `follow_relationships_local` | community | UI profilo |
| `live_sessions_local` | safety (submodulo live) | UI |
| `safety_contacts_local` | safety | UI |
| `safety_events_local` | safety | UI, sync |
| `notifications_local` | sync (pull server) | UI |

**Sync** e' un caso speciale: scrive `sync_state` / `sync_retry_count` / `sync_last_error` su tutte le tabelle sincronizzate. Questo e' un'eccezione documentata alla regola "un writer per tabella". Motivazione: sync non modifica il dominio, solo i suoi metadati. Coerente con regola overview Sezione 2 del documento `05_sync/L0_architecture.md`.

---

## Sezione 7 -- Migrazioni drift

Drift usa `schemaVersion` intero + `MigrationStrategy`.

### 7.1 Schema v1 (initial)

Prima release dell'app: tutte le tabelle create in `onCreate`. `schemaVersion = 1`.

### 7.2 Upgrade a versioni future

Quando serve aggiungere una tabella / colonna:

1. Incrementa `schemaVersion` a `N+1`.
2. Aggiorna la definizione della tabella in Dart.
3. In `onUpgrade`:
   ```dart
   if (from < 2 && to >= 2) {
     await m.addColumn(activitiesLocal, activitiesLocal.newColumn);
   }
   ```
4. Testa la migration su device con dati reali (simulabile esportando un DB snapshot).

### 7.3 Generazione code

Drift richiede `build_runner` per generare `*.g.dart`. Pattern:
- CI lancia `dart run build_runner build --delete-conflicting-outputs`.
- `*.g.dart` checked in Git (non gitignorato) per evitare drift tra env.

### 7.4 Drift schema dump per backward compat

Drift supporta `drift_dev`'s `schema-export`: salva snapshot JSON di ogni schema version. Permette test automatici di migration.

Pattern:
- Ogni incremento `schemaVersion`, comando: `dart run drift_dev schema dump lib/db.dart shared/db/drift_schemas/`.
- Test CI: ogni migration e' applicata a partire da ogni snapshot storico e verifica risultato.

---

## Sezione 8 -- Pattern di lettura / scrittura

### 8.1 Lettura "live" via Stream

Le UI reactive (feed, profilo, garage) usano `DAO.watch*()` che restituisce `Stream<List<Row>>`. Drift notifica cambiamenti automaticamente.

```dart
class ActivityFeedScreen extends StatelessWidget {
  @override
  Widget build(ctx) {
    return StreamBuilder(
      stream: ctx.read<ActivitiesDao>().watchOwnerActivities(currentUserId),
      builder: (ctx, snapshot) { ... },
    );
  }
}
```

### 8.2 Scrittura idempotente via `client_id`

Entita' con `client_id`: usiamo `INSERT ... ON CONFLICT(client_id) DO UPDATE SET ...`, equivalente in drift:

```dart
await into(activitiesLocal).insertOnConflictUpdate(entry);
```

Questo replica il pattern server-side (`ON CONFLICT DO NOTHING`) ma client-side consente update (il client e' source of truth locale).

### 8.3 Transazioni per operazioni composite

Scritture che toccano piu' tabelle insieme (es. closing: insert Activity + update RecordingSession) usano `db.transaction(() async { ... })`.

Esempio buffer_to_activity:

```dart
await db.transaction(() async {
  final points = await trackPointBufferDao.readForSession(sessionId);
  final activity = ActivitiesLocalCompanion(...);
  await activitiesDao.insert(activity);
  await recordingSessionsDao.updateState(sessionId, 'closed_unsynced');
});
```

### 8.4 Scritture in background isolate

`flutter_background_service` gira in un isolate separato dal main UI. Drift supporta multi-isolate via `NativeDatabase.createInBackground()` + `QueryExecutor` shared.

Pattern: il background isolate ha il suo `AppDatabase` instance che punta allo **stesso file SQLite** del main. SQLite gestisce locking; drift serializza scritture.

Impatto: scritture GPS durante registrazione avvengono nel background isolate; lettura UI dal main isolate vede i dati in tempo reale via stream drift (il cross-isolate update lo gestisce drift nativamente da v2).

---

## Sezione 9 -- Dimensionamento e performance

### 9.1 Stima dimensione DB

- 1 Activity tipica (2h, 1Hz): `track_points_data` ~ 20-50KB jsonb -> drift come TEXT ~ 40-100KB.
- 1000 Activity utente: 40-100 MB. Ragionevole su mobile storage moderno.
- Foto media NON in drift (su filesystem + storage path).

### 9.2 Query hot-path

Le query con stream (feed, sync-pending scan) devono essere veloci. Indici dichiarati in Sezione 4 coprono i casi principali.

Per debug, Flutter ha `drift_dev`'s visualizer + logging SQL. Abilitare in dev env.

### 9.3 Pulizia

`TrackPointBuffer` viene pulito quando la RecordingSession passa a `closed_synced` + grace period 7 giorni (proposta A.6 in open questions).

Periodicamente (al bootstrap) eseguire:
```sql
DELETE FROM track_point_buffer_local
  WHERE recording_session_id IN (
    SELECT client_id FROM recording_sessions_local
      WHERE state = 'closed_synced'
        AND ended_at < datetime('now', '-7 days')
  );
DELETE FROM recording_sessions_local
  WHERE state = 'closed_synced'
    AND ended_at < datetime('now', '-7 days');
```

Implementato come `MaintenanceService` nel modulo tracking, invocato al bootstrap.

### 9.4 Backup

Il database SQLite e' parte del app sandbox Android. NON viene backuppato su Google Drive by-default (policy Android). Questo e' intenzionale:
- Coerente con "single-device" (overview Sezione 5.2).
- Rehydration dal server e' il backup: l'utente perde dispositivo, ne installa uno nuovo, sync recupera tutto.
- `recording_sessions`, `track_point_buffer`, `sync_queue` sono stato transient, nessun valore di backup.

Se in futuro si volesse backup locale (feature post-MVP), si userebbe Android Auto Backup configurando il manifest con backup rules.

---

## Sezione 10 -- Open items

Gli item originali sono stati chiusi e archiviati in `99_open_questions.md` Sezione D:

- Rimozione `server_id` dalle tabelle drift -> **D.37**.
- Grace period dopo `closed_synced` = 7 giorni -> **D.34**.
- Pattern drift multi-isolate `NativeDatabase.createInBackground()` -> **D.38**.
- Schema v1 pre-dichiara tutte le tabelle -> **D.39**.
- Path media relativi via `local_cache_path` -> **D.40**.
- Lazy load `track_points_data` + compute isolate -> **D.41**.

Nessun item aperto residuo specifico a questo documento.

---

**Fine 03_local_db.md**
