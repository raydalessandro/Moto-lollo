# 12 / Settings & Profile -- L0.5 Interfaces

**Scopo:** firme Dart modulo settings & profile.

**Riferimenti:** `L0_architecture.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Types di dominio

### 1.1 `OwnProfile`

Profilo dell'utente corrente, con tutti i campi.

```dart
@freezed
class OwnProfile with _$OwnProfile {
  const factory OwnProfile({
    required String userId,
    required String username,
    required String displayName,
    required String? bio,
    required String? avatarStoragePath,
    required String? avatarStoragePathThumb,
    required bool isPublic,
    required ProfileRole role,
    required DateTime createdAt,
    required DateTime updatedAt,
    required bool canChangeUsername,    // derivato da createdAt + 7d
    required DateTime? usernameChangeDeadline,
  }) = _OwnProfile;
}

enum ProfileRole { user, admin }
```

### 1.2 `PublicProfile`

Profilo di altro utente, solo campi pubblici.

```dart
@freezed
class PublicProfile with _$PublicProfile {
  const factory PublicProfile({
    required String userId,
    required String username,
    required String displayName,
    required String? bio,
    required String? avatarStoragePathThumb,
    required bool isPublic,
    required int followerCount,
    required int followingCount,
    required int publishedRouteCount,
    required bool currentUserFollows,
  }) = _PublicProfile;
}
```

### 1.3 `AppSettings`

```dart
@freezed
class AppSettings with _$AppSettings {
  const factory AppSettings({
    required AppThemeMode themeMode,
    required String languageCode,
    required UnitSystem unitSystem,
    required bool isPublic,
    required bool showActivityInFeed,
    required bool pushNotificationsEnabled,
    required bool notifyOnLike,
    required bool notifyOnComment,
    required bool notifyOnFollow,
    required bool notifyOnSafetyEventEcho,
    required bool autoSyncEnabled,
    required bool syncOnlyOnWifi,
    required bool autoPauseEnabled,
    required bool voiceGuidanceEnabled,
  }) = _AppSettings;
}

enum UnitSystem { metric, imperial }
```

### 1.4 `SettingsError`

```dart
sealed class SettingsError {
  const SettingsError();
}

final class ValidationError extends SettingsError {
  final String field;
  final String message;
  const ValidationError(this.field, this.message);
}

final class UsernameUnavailableError extends SettingsError {
  final String attemptedUsername;
  const UsernameUnavailableError(this.attemptedUsername);
}

final class UsernameChangeWindowClosedError extends SettingsError {
  // Piu' di 7 giorni dalla creazione account
  final DateTime accountCreatedAt;
  const UsernameChangeWindowClosedError(this.accountCreatedAt);
}

final class InvalidConfirmationError extends SettingsError {
  // Cancellazione account senza aver digitato "ELIMINA"
  const InvalidConfirmationError();
}

final class AvatarTooLargeError extends SettingsError {
  final int sizeBytes;
  final int maxBytes;
  const AvatarTooLargeError(this.sizeBytes, this.maxBytes);
}

final class InternalFailureError extends SettingsError {
  final String details;
  final Object? underlying;
  const InternalFailureError(this.details, [this.underlying]);
}
```

---

## Sezione 2 -- `ProfileApi`

```dart
abstract class ProfileApi {
  // ---------- OWN PROFILE ----------

  Future<OwnProfile> getOwnProfile();

  Stream<OwnProfile> watchOwnProfile();

  Future<Result<void, SettingsError>> updateDisplayName(String displayName);

  Future<Result<void, SettingsError>> updateBio(String? bio);

  /// Cambio username. Fallisce se:
  /// - Fuori dalla finestra di 7 giorni -> UsernameChangeWindowClosedError.
  /// - Username gia' preso da altro utente -> UsernameUnavailableError.
  /// - Formato invalido -> ValidationError.
  Future<Result<void, SettingsError>> updateUsername(String newUsername);

  Future<Result<void, SettingsError>> setIsPublic(bool isPublic);

  // ---------- AVATAR ----------

  Future<Result<void, SettingsError>> uploadAvatar({
    required Uint8List fullBytes,
    required Uint8List thumbBytes,
  });

  Future<Result<void, SettingsError>> removeAvatar();

  // ---------- ALTRI PROFILI ----------

  /// Profilo pubblico di altro utente.
  /// Rispetta is_public e RLS: se chiuso o l'altro utente non consente, filtrato.
  Future<Result<PublicProfile, SettingsError>> getPublicProfile(String userId);

  // ---------- ACCOUNT ----------

  /// Richiede cancellazione account. Richiede conferma testuale esatta "ELIMINA".
  /// Se confirmationText != "ELIMINA" -> InvalidConfirmationError.
  /// Esegue soft delete server-side e logout.
  Future<Result<void, SettingsError>> requestAccountDeletion(String confirmationText);
}
```

---

## Sezione 3 -- `SettingsApi`

```dart
abstract class SettingsApi {
  /// Stato corrente settings (device + feature_flags combinati).
  AppSettings get current;

  Stream<AppSettings> watch();

  // ---------- SET INDIVIDUALI ----------

  Future<void> setThemeMode(AppThemeMode mode);

  Future<void> setLanguageCode(String code);      // 'it' | 'en'

  Future<void> setUnitSystem(UnitSystem system);

  Future<void> setShowActivityInFeed(bool value);

  Future<void> setPushNotificationsEnabled(bool value);
  Future<void> setNotifyOnLike(bool value);
  Future<void> setNotifyOnComment(bool value);
  Future<void> setNotifyOnFollow(bool value);
  Future<void> setNotifyOnSafetyEventEcho(bool value);

  Future<void> setAutoSyncEnabled(bool value);
  Future<void> setSyncOnlyOnWifi(bool value);

  Future<void> setAutoPauseEnabled(bool value);
  Future<void> setVoiceGuidanceEnabled(bool value);

  // ---------- RESET ----------

  Future<void> resetAllSettings();
}
```

---

## Sezione 4 -- Eventi emessi

```dart
@freezed
class ProfileUpdatedEvent with _$ProfileUpdatedEvent {
  const factory ProfileUpdatedEvent({
    required String userId,
    required Set<String> changedFields,
    required DateTime updatedAt,
  }) = _ProfileUpdatedEvent;
}

@freezed
class SettingsChangedEvent with _$SettingsChangedEvent {
  const factory SettingsChangedEvent({
    required String key,
    required Object? oldValue,
    required Object? newValue,
  }) = _SettingsChangedEvent;
}

@freezed
class AccountDeletionRequestedEvent with _$AccountDeletionRequestedEvent {
  const factory AccountDeletionRequestedEvent({
    required String userId,
    required DateTime occurredAt,
  }) = _AccountDeletionRequestedEvent;
}
```

---

## Sezione 5 -- `SettingsProfileModule` (manifest)

```dart
class SettingsProfileModule extends AppModule {
  @override
  String get name => 'settings_profile';

  @override
  List<String> get dependsOn => [
    'shared.db',
    'shared.event_bus',
    'shared.auth',
    'shared.supabase',
    'shared.preferences',
  ];

  @override
  List<Type> get provides => [ProfileApi, SettingsApi];

  @override
  List<Type> get consumes => [];

  @override
  void register(ModuleRegistry r) {
    // instanziazione di ProfileService + SettingsService + AvatarService
    // registrazione API
  }
}
```

---

## Sezione 6 -- Test contracts

- getOwnProfile happy.
- updateUsername dentro / fuori finestra 7 giorni.
- updateUsername con username gia' preso.
- uploadAvatar + removeAvatar.
- Each setting set + verifica propagazione (SharedPreferences o DB).
- requestAccountDeletion con "ELIMINA" / altro testo.
- SettingsChangedEvent emit su ogni cambio.

---

**Fine 12_settings_profile/L05_interfaces.md**
