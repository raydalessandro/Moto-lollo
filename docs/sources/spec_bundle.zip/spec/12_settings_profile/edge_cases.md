# 12 / Settings & Profile -- Edge Cases

**Scopo:** casi limite modulo settings & profile.

**Riferimenti:** `L0_architecture.md`, `L05_interfaces.md`.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Profile update

### 1.1 Display name vuoto / solo whitespace

**Atteso:** `ValidationError('displayName', 'Nome obbligatorio')`.

### 1.2 Bio > 500 caratteri

**Atteso:** `ValidationError('bio', 'Massimo 500 caratteri')`.

### 1.3 Username con caratteri speciali non ammessi

**Atteso:** `ValidationError('username', 'Solo lettere, numeri e underscore')`. Regex: `^[a-zA-Z0-9_]{3,30}$`.

### 1.4 Username maiuscolo vs minuscolo

**Atteso:** normalizzare a lowercase prima del check di uniqueness. Utente che inserisce "MarioRossi" salva "mariorossi".

### 1.5 Username gia' esistente

**Atteso:**
- Check pre-submit: service invoca Supabase query "SELECT 1 FROM profiles WHERE lower(username) = ?".
- Se esiste: `UsernameUnavailableError`.
- UI mostra errore in-form.

**Race condition:** due utenti tentano stesso username nello stesso secondo. Uno vince (INSERT OK), l'altro riceve `23505` su UPDATE. Mappato a `UsernameUnavailableError`.

### 1.6 Username tentato fuori finestra 7 giorni

**Atteso:** `UsernameChangeWindowClosedError(accountCreatedAt)`. UI mostra "Puoi modificare il nome utente solo nei primi 7 giorni dalla creazione account. Sono passati X giorni."

### 1.7 Server non raggiungibile durante update

**Atteso:** operazione va in `sync_queue_local` con `sync_state = pending`. UI vede aggiornamento ottimistico. Al ritorno online, sync confermera' o ritornera' error (es. username occupato nel frattempo -- rollback locale + notifica).

---

## Sezione 2 -- Avatar

### 2.1 File troppo grande

**Atteso:** `AvatarTooLargeError(sizeBytes, maxBytes=2_000_000)`. UI: "Foto troppo grande. Verra' compressa."

**Scelta:** UI comprime automaticamente prima di submit. L'errore e' fallback se compressione non raggiunge limite (edge raro).

### 2.2 Upload fallisce a meta'

**Atteso:** come per `garage/edge_cases.md` Sezione 5.2. Avatar resta precedente valore, UI offre retry.

### 2.3 Formato non supportato (es. HEIC su Android?)

**Atteso:** conversione client-side a JPEG prima dell'upload. Se conversione fallisce: `ValidationError('avatar', 'Formato non supportato')`.

### 2.4 Rimozione avatar lascia utente "senza faccia"

**Atteso:** consentito. UI mostra avatar default (initials display_name).

---

## Sezione 3 -- Settings

### 3.1 Cambio theme mode immediato

**Atteso:**
- `setThemeMode(dark)` scrive in SharedPreferences + emette `SettingsChangedEvent(key: 'theme_mode')`.
- `ThemeModeNotifier` ascolta e rebuilda MaterialApp.
- Transizione smooth animata (fade 300ms).

### 3.2 Cambio language_code

**Atteso:**
- Scrive in `profiles.feature_flags.language_code`.
- Emit event.
- Root MaterialApp ricarica localizzazioni.
- Strings visibili istantaneamente nella nuova lingua.

**Edge:** se utente passa a una lingua non supportata a runtime (bug), fallback a inglese. UI bottone lingua non lascia selezionare non supportate.

### 3.3 Cambio unit_system

**Atteso:**
- Scrive in feature_flags.
- Emit event.
- StatBadge e altri widget che ascoltano rebuild con nuova unita'.
- Valori in DB restano metrici.

**Conversioni standard:**
- 1 km = 0.621371 miglia.
- 1 km/h = 0.621371 mph.
- Altitudine: 1 m = 3.28084 ft.

### 3.4 Disable auto_sync_enabled

**Atteso:**
- Scrive in SharedPreferences.
- Emit event.
- Sync orchestrator ascolta, pausa.
- UI settings mostra warning: "Auto-sync disattivato. Ricorda di sincronizzare manualmente prima di disinstallare l'app."

### 3.5 Toggle sync_only_on_wifi

**Scenario:** utente attiva. Ha 50 item in coda. E' su cellular.

**Atteso:**
- Sync orchestrator ascolta `connectivity_plus`, vede "mobile" + flag "only wifi" -> pausa.
- Al passaggio a wifi: riprende.

### 3.6 Toggle notify_* flags

**Atteso:** propaga al modulo notifications (post-MVP). In MVP solo scrittura del flag, effetto reale quando notifications module esistera'.

### 3.7 resetAllSettings

**Atteso:**
- Conferma UI "Ripristinare tutte le impostazioni ai valori predefiniti?".
- Se si': scrive default in SharedPreferences + feature_flags.
- Emette N `SettingsChangedEvent`.
- UI ricarica.

---

## Sezione 4 -- Account deletion

### 4.1 Conferma errata

**Scenario:** utente digita "elimina" (minuscolo) o "DELETE".

**Atteso:** `InvalidConfirmationError`. UI evidenzia input: "Digita esattamente ELIMINA in maiuscolo."

### 4.2 Cancellazione durante tracking attivo

**Scenario:** tracking in corso quando utente conferma cancellazione.

**Atteso:**
- UI dialog warning: "Hai una registrazione in corso. Verra' persa. Continuare?".
- Se si':
  - `tracking.discardRecording()`.
  - Quindi `profileApi.requestAccountDeletion`.

### 4.3 Cancellazione con coda sync non vuota

**Scenario:** 20 item ancora da sincronizzare.

**Atteso:**
- UI warning: "Hai N elementi non sincronizzati. Verranno persi. Continuare?".
- Se si': procedi.

### 4.4 Cancellazione offline

**Atteso:**
- Cancellazione server-side richiede chiamata Edge Function -> richiede online.
- Se offline: `InternalFailureError('offline')`. UI "Serve connessione per eliminare l'account."

### 4.5 Dopo cancellazione, utente tenta login

**Scenario:** soft-deleted profile. Utente tenta login con stesse credenziali.

**Atteso:**
- Supabase Auth consente login (auth.users non e' cancellato, solo il profile.deleted_at).
- Nostro flow post-login verifica `profile.deleted_at IS NOT NULL` -> logout forzato + messaggio "Questo account e' stato eliminato. Contatta il supporto."

**Post-MVP:** hard delete via admin tool dopo 30 giorni.

---

## Sezione 5 -- Integrazione modulo

### 5.1 `is_public` toggle da settings vs da profile

**Atteso:** entrambi operano sullo stesso campo. UI mostra lo stesso valore coerente via `watchOwnProfile()`.

### 5.2 Logout vs delete account

**Distinti:**
- Logout: sessione termina, dati locali restano (per prossimo login).
- Delete: hard richiesta server + logout.

### 5.3 Feature flags in feature_flags jsonb

**Scenario:** server aggiunge nuova feature flag post-release.

**Atteso:**
- Client legge `feature_flags` come Map<String, dynamic>.
- Flag sconosciute ignorate silenziosamente.
- Piu' flag aggiunte nel tempo: nessuna migration schema necessaria.

---

## Sezione 6 -- Checklist QA

- [ ] Display name update.
- [ ] Bio update + validazione 500 chars.
- [ ] Username update dentro 7gg.
- [ ] Username update fuori 7gg -> error.
- [ ] Username gia' preso -> error.
- [ ] is_public toggle + effetto su RLS visibility.
- [ ] Upload avatar + remove avatar.
- [ ] Avatar troppo grande -> compressione + eventuale error.
- [ ] Tutti i toggle settings funzionano.
- [ ] Theme mode cambio immediato.
- [ ] Language cambio immediato.
- [ ] Unit system cambio propaga a widget.
- [ ] Reset all settings con conferma.
- [ ] Account deletion con "ELIMINA" esatto.
- [ ] Account deletion con altro testo -> error.
- [ ] Deletion con tracking in corso -> warning + flow.
- [ ] Login su account deleted -> blocco con messaggio.

---

## Sezione 7 -- Open items specifici settings

- A.12 username enforcement (a/b/c) -- riferito qui, Ray decide.
- Post-MVP: feature flag UI per power user ("mostra flag sperimentali").
- Post-MVP: localizzazioni aggiuntive oltre it/en.
- Post-MVP: backup / export dei propri dati (GDPR data portability).

---

**Fine 12_settings_profile/edge_cases.md**
