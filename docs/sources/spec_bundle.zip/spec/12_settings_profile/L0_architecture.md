# 12 / Settings & Profile -- L0 Architecture

**Scopo:** gestione del profilo utente (dati personali, avatar, username) e delle preferenze applicative (lingua, tema, notifiche, privacy, unita' di misura).

**Cosa NON e' qui:**

- Autenticazione (modulo auth in `shared/`).
- SafetyContacts -- sono nel modulo 09.
- Gestione moto -- modulo 06.

**Riferimenti:**

- Entita' Profile: `01_data_model.md` Sezione 1.
- Schema: `02_database_schema.md` Sezione 3.1.
- Feature flags: D.12.

**Ultimo aggiornamento:** 18 aprile 2026

---

## Sezione 1 -- Missione

Due aree funzionali integrate in un unico modulo:

1. **Profile management**: CRUD del proprio profilo (display_name, bio, avatar, username con limite temporale).
2. **Settings**: preferenze applicative (tema, lingua, unita' di misura, privacy dell'account, preferenze notifiche).

Settings sono conservate in parte nel profilo server (`profiles.feature_flags` jsonb, vedi D.12) e in parte localmente (preferenze che hanno senso solo sul device corrente, es. auto-sync enabled).

---

## Sezione 2 -- Struttura interna

```
modules/settings_profile/
|-- lib/
|   |-- settings_profile.dart
|   |-- api.dart
|   +-- src/
|       |-- domain/
|       |   |-- profile.dart
|       |   |-- app_settings.dart
|       |   +-- settings_error.dart
|       |-- application/
|       |   |-- profile_service.dart
|       |   |-- settings_service.dart
|       |   +-- avatar_service.dart
|       |-- persistence/
|       |   |-- profiles_dao.dart             (gia' in shared/db/)
|       |   +-- device_preferences_store.dart (SharedPreferences wrapper)
|       +-- ui/
|           |-- profile_screen.dart           (view/edit proprio profilo)
|           |-- settings_screen.dart
|           +-- widgets/
|-- test/
+-- pubspec.yaml
```

---

## Sezione 3 -- Profile

### 3.1 Campi gestiti

- `username`: obbligatorio, unique. Modificabile solo entro 7 giorni dalla creazione dell'account (policy A.12).
- `display_name`: obbligatorio, liberamente modificabile.
- `bio`: opzionale, max 500 caratteri.
- `avatar_storage_path`: opzionale, foto profilo.
- `is_public`: boolean. Se false, profilo privato (vedi `00_overview.md` Sezione 6 RLS).

### 3.2 Operazioni

- `getOwnProfile()` -> Future<OwnProfile>.
- `watchOwnProfile()` -> Stream<OwnProfile>.
- `updateDisplayName(String)`.
- `updateBio(String?)`.
- `updateUsername(String)` -- verifica eta' account (A.12).
- `setIsPublic(bool)`.
- `uploadAvatar(bytes)` / `removeAvatar()`.
- `getPublicProfile(userId)` -- visto da altri utenti (filtra campi privati).

### 3.3 Cancellazione account

**Operazione distinta, richiede conferma esplicita:**

- `requestAccountDeletion(confirmationText)` -- utente deve digitare esattamente "ELIMINA" (policy UX anti-errore).
- Service invoca Edge Function server-side `delete-account` che:
  - Esegue soft delete profile.
  - Trigger `anonymize_profile_on_soft_delete` (D.8) agisce automaticamente.
  - Logout utente.
- Ritorno: `AccountDeletionRequestedEvent` e conferma UI.
- Non reversibile (lato utente). Admin puo' teoricamente ripristinare entro N giorni prima di hard delete batch.

---

## Sezione 4 -- App Settings

### 4.1 Categorie

**Aspetto:**
- `theme_mode`: system | light | dark | high_visibility (default system).

**Localizzazione:**
- `language_code`: it | en (default device locale).
- `unit_system`: metric | imperial (default metric).

**Privacy:**
- `is_public` (duplicato da profile, UI unified).
- `show_activity_in_feed`: boolean (se false, proprie activity publicate non appaiono a followers in feed).

**Notifiche:**
- `push_notifications_enabled`: boolean master.
- `notify_on_like`: boolean.
- `notify_on_comment`: boolean.
- `notify_on_follow`: boolean.
- `notify_on_safety_event_echo`: boolean.

**Sync:**
- `auto_sync_enabled`: boolean (default true).
- `sync_only_on_wifi`: boolean (default false).

**Tracking:**
- `auto_pause_enabled`: boolean (default true).
- `voice_guidance_enabled`: boolean (default true).

### 4.2 Storage

Preferenze **device-local** (non sincronizzate):
- `auto_sync_enabled`, `sync_only_on_wifi`, `theme_mode` -> `SharedPreferences`.

Preferenze **user-global** (sincronizzate in `profiles.feature_flags`):
- `language_code`, `unit_system`, `is_public`, notifications flags, `show_activity_in_feed`.

Motivazione divisione:
- Theme e' device-locale perche' dipende dal device (oled dark, amoled, ecc.).
- Sync preferences sono device-locali (il device ha diversa connettivita').
- Notification flags e privacy sono cross-device (il comportamento deve essere coerente).

### 4.3 Operazioni

- `watchSettings()` -> Stream<AppSettings>.
- `updateSetting<T>(key, value)` -- dispatcher che scrive in SharedPreferences o feature_flags.
- `resetAllSettings()` -- torna ai default.

---

## Sezione 5 -- Interazione con altri moduli

### 5.1 Consumers di theme_mode

- `ui_components`: ThemeModeNotifier ascolta `watchSettings()` e ricostruisce MaterialApp.

### 5.2 Consumers di `language_code`

- Tutti i moduli via localizzazione Flutter standard (`Intl`). Cambio lingua triggera rebuild.

### 5.3 Consumers di `unit_system`

- `ui_components.StatBadge` converte km->miglia e km/h->mph quando unit_system=imperial.
- Valori sempre salvati in metrico in DB. Conversione avviene solo al display.

### 5.4 Consumers di `auto_sync_enabled`

- Modulo sync: se false, orchestrator resta idle. Utente deve ri-abilitare o triggerare manual sync dall'UI.

### 5.5 Consumers di notification flags

- Modulo notifications (futuro): filtra push notifications in base ai flag.

### 5.6 Consumers di `auto_pause_enabled`, `voice_guidance_enabled`

- Tracking: `GpsFilterPipeline` disabilita auto-pause detection se flag false.
- Navigation: `tts_speaker` muto se flag false.

---

## Sezione 6 -- Eventi emessi

- `ProfileUpdatedEvent(userId, changedFields)`.
- `SettingsChangedEvent(key, oldValue, newValue)`.
- `AccountDeletionRequestedEvent(userId, occurredAt)`.

Consumatori: vari moduli via subscribers specifici su `SettingsChangedEvent` filtrato per key.

---

## Sezione 7 -- Eventi consumati

### 7.1 `UserLoggedInEvent`

Al login: carica profilo da server (rehydration gia' fa parte del generale, qui il settings module si assicura di avere `feature_flags` letto).

---

## Sezione 8 -- Dipendenze

### Consumes:

- `shared/db/AppDatabase` per `profiles_local`.
- `shared/event_bus/EventBus`.
- `shared/auth/AuthService`.
- `shared/supabase/SupabaseClient` per avatar upload.
- `shared/preferences/SharedPreferencesStore` (wrapper shared di `shared_preferences`).

### Provides:

- `ProfileApi`.
- `SettingsApi`.

### Aggregazione:

Esposto come `SettingsProfileModule` che registra entrambi gli `Api`.

---

## Sezione 9 -- Policy speciali

### 9.1 Username modifica entro 7 giorni

In linea con A.12 / D.x (decisione finale utente-prodotto).

**Opzione (a) UI-only enforcement (raccomandata MVP):**
- Service verifica `currentUser.createdAt + 7d > now()`.
- Se no: UI disabilita input username. Niente chiamata server.

**Opzione (b) o (c):** vedi A.12 quando Ray decide.

### 9.2 `is_public` toggle effetti

Quando `is_public` passa da true a false:
- RLS server-side filtra automaticamente le letture altrui (vedi `00_overview.md` Sezione 6).
- Le PublishedRoute non sono impattate (hanno visibility propria).
- Il profilo non compare piu' in ricerche pubbliche.

### 9.3 Cancellazione account con dati in corso

**Scenario:** utente in tracking attivo chiede delete account.

**Atteso:**
- UI warning: "Hai una registrazione in corso. Verra' persa. Continuare?".
- Se conferma: stop tracking (discard), poi delete account.
- Se annulla: account non eliminato.

### 9.4 Convenzione namespace onboarding in `feature_flags`

**Scopo:** avere uno spazio riservato per tracciare lo stato di onboarding dell'utente senza modifiche di schema quando il flow verra' finalizzato (B.8).

**Convenzione:** `profile.feature_flags.onboarding` = oggetto JSON.

Shape attesa:

```json
{
  "onboarding": {
    "completed_steps": ["welcome", "profile", "first_motorcycle", "safety_contacts"],
    "started_at": "2026-04-20T14:00:00Z",
    "completed_at": "2026-04-20T14:05:00Z",
    "skipped_steps": ["safety_contacts"],
    "version": 1
  }
}
```

**Campi della convenzione:**

- `completed_steps`: array di stringhe. Step che l'utente ha completato. Nomi liberi ma stabili (es. `welcome`, `profile`, `first_motorcycle`, `safety_contacts`, `notifications_permission`, `tour_completed`).
- `started_at`: quando l'utente ha aperto il primo step.
- `completed_at`: quando ha finito il flow. Null se ancora in corso.
- `skipped_steps`: step esplicitamente skippati (vs mai visti). Per capire chi ha evitato per scelta vs chi si e' perso.
- `version`: versione del flow di onboarding. Se il team cambia il flow (es. aggiunge uno step), incrementa. Permette di ri-innescare onboarding solo per chi non l'ha fatto in v_nuova.

**API utilizzo (interno):**

Settings module espone helper:

```dart
// SettingsApi interna al modulo
Future<void> markOnboardingStepCompleted(String stepName);
Future<void> markOnboardingCompleted();
Future<void> markOnboardingStepSkipped(String stepName);
bool get isOnboardingComplete;   // derived da feature_flags.onboarding.completed_at != null
Set<String> get completedOnboardingSteps;
```

**Decisione ancora aperta (B.8):**

- Quali step concreti?
- Quali obbligatori?
- UX screens?
- Cosa fare per utenti pre-onboarding-system (pre-flight se l'app era gia' in beta)?

La **convenzione e' pronta** anche se il flow non lo e'. Quando B.8 verra' chiuso, serve solo popolare i nomi step -- zero schema change.

**Default per utenti senza `feature_flags.onboarding`:**

Se l'oggetto manca nel jsonb (utente creato prima della feature, o bug), Settings module tratta come "onboarding mai iniziato". UI mostra onboarding al prossimo login.

---

## Sezione 10 -- Testing

- CRUD profile: update display_name, bio, is_public.
- Update username dentro / fuori finestra 7 giorni.
- Upload avatar.
- Set each setting flag.
- Change theme_mode + propagazione a ui_components.
- Change language_code + rebuild localizzato.
- Change unit_system + conversione in StatBadge.
- Cancellazione account con conferma.
- Onboarding steps: mark completed, mark skipped, isOnboardingComplete corretto.
- Onboarding version bump ri-innesca UI (quando B.8 implementato).

---

**Fine 12_settings_profile/L0_architecture.md**
